import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

/// Danh sách mẫu phiếu: TNMaker có sẵn + mẫu tự tạo (Azota…).
struct TemplateListView: View {
    @EnvironmentObject var store: Store
    @State private var showBuilder = false
    @State private var renaming: TemplateSpec?
    @State private var newName = ""

    var body: some View {
        List {
            Section {
                LabeledContent("Phiếu chuẩn của Bộ GD&ĐT", value: "40 – 8 – 6")
                LabeledContent("Phiếu in từ app (1 hoặc 2 phiếu/A4)", value: "tối đa 100 – 10 – 12")
            } header: { Text("1. Phiếu chuẩn của Bộ GD&ĐT") }

            Section {
                let letters = Array("abcdefghijklmnopqrstuvwxyz")
                ForEach(Array(BuiltinTemplates.tnmaker.enumerated()), id: \.element.id) { idx, t in
                    VStack(alignment: .leading, spacing: 2) {
                        Text("\(String(letters[idx])). \(t.name)")
                        Text(t.summary).font(.caption).foregroundStyle(.secondary)
                    }
                }
                Link(destination: BuiltinTemplates.tnmakerPage) {
                    Label("Tải phiếu gốc tại tnmaker.net", systemImage: "arrow.down.doc")
                }
            } header: { Text("2. Phiếu TNMaker (\(BuiltinTemplates.tnmaker.count) mẫu)") }

            Section {
                let letters = Array("abcdefghijklmnopqrstuvwxyz")
                ForEach(Array(BuiltinTemplates.qm.enumerated()), id: \.element.id) { idx, t in
                    VStack(alignment: .leading, spacing: 2) {
                        Text("\(String(letters[idx])). \(t.name)")
                        Text(t.summary).font(.caption).foregroundStyle(.secondary)
                    }
                }
                Link(destination: BuiltinTemplates.qmPage) {
                    Label("Tải phiếu QM 2025 tại chamthi2025.com", systemImage: "arrow.down.doc")
                }
                Link(destination: BuiltinTemplates.chamthiPage) {
                    Label("Xem mẫu phiếu tại chamthi.com", systemImage: "globe")
                }
            } header: { Text("3. Phiếu QM (\(BuiltinTemplates.qm.count) mẫu)") } footer: {
                Text("In đúng khổ A4 và tỉ lệ 100%. Nếu phiếu in thực tế có sai lệch tọa độ, dùng “Tạo mẫu từ phiếu trắng” để hiệu chỉnh 1 lần.")
            }

            Section {
                ForEach(store.templates) { t in
                    VStack(alignment: .leading, spacing: 2) {
                        Text(t.name)
                        Text(t.summary).font(.caption).foregroundStyle(.secondary)
                    }
                    .contextMenu {
                        Button("Đổi tên") { newName = t.name; renaming = t }
                    }
                }
                .onDelete { idx in store.templates.remove(atOffsets: idx) }
                Button { showBuilder = true } label: {
                    Label("Tạo mẫu từ phiếu trắng (Azota…)", systemImage: "plus.viewfinder")
                }
                Link(destination: BuiltinTemplates.azotaGuide) {
                    Label("Cách tải phiếu trả lời từ Azota", systemImage: "questionmark.circle")
                }
            } header: { Text("Mẫu tự tạo") } footer: {
                Text("Azota tạo phiếu riêng theo từng đề (mã mẫu ghi ở cuối phiếu, ví dụ v15.0). Tải file PDF phiếu trả lời của đề từ Azota, rồi tạo mẫu ở đây một lần cho mỗi loại phiếu. Cách này dùng được cho mọi phiếu có ô vuông đen định vị.")
            }
        }
        .navigationTitle("Mẫu phiếu")
        .fullScreenCover(isPresented: $showBuilder) { NavigationStack { TemplateBuilderView() } }
        .alert("Đổi tên mẫu", isPresented: Binding(get: { renaming != nil }, set: { if !$0 { renaming = nil } })) {
            TextField("Tên mẫu", text: $newName)
            Button("Huỷ", role: .cancel) { renaming = nil }
            Button("Lưu") {
                if var t = renaming, !newName.trimmingCharacters(in: .whitespaces).isEmpty {
                    t.name = newName; store.saveTemplate(t)
                }
                renaming = nil
            }
        }
    }
}

/// Tạo mẫu phiếu từ PDF/ảnh phiếu trắng.
struct TemplateBuilderView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss

    @State private var detection: TemplateBuilder.Detection?
    @State private var uiImage: UIImage?
    @State private var blocks: [TemplateBuilder.PixelBlock] = []
    @State private var name = "Phiếu Azota"
    @State private var zoom: CGFloat = 1
    @State private var busy = false
    @State private var message: String?
    @State private var showFile = false
    @State private var photo: PhotosPickerItem?

    // Thêm vùng
    @State private var showAdd = false
    @State private var newKind: TemplateSpec.BlockKind = .p1
    @State private var newCount = 10
    @State private var newFirst = 1
    @State private var drawing = false
    @State private var dragStart: CGPoint?
    @State private var dragNow: CGPoint?

    var body: some View {
        Group {
            if let detection, let uiImage {
                editor(detection, uiImage)
            } else {
                start
            }
        }
        .navigationTitle("Tạo mẫu phiếu")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Huỷ") { dismiss() } }
            if detection != nil {
                ToolbarItem(placement: .confirmationAction) { Button("Lưu") { save() }.disabled(!canSave) }
            }
        }
        .fileImporter(isPresented: $showFile, allowedContentTypes: [.pdf, .image]) { result in
            guard case let .success(url) = result else { return }
            load { () -> GrayImage? in
                if url.pathExtension.lowercased() == "pdf" { return TemplateBuilder.image(fromPDF: url) }
                let access = url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }
                guard let data = try? Data(contentsOf: url), let ui = UIImage(data: data) else { return nil }
                return GrayImage(uiImage: ui, maxSide: 2400)
            }
        }
        .onChange(of: photo) { _, item in
            guard let item else { return }
            Task {
                let data = try? await item.loadTransferable(type: Data.self)
                photo = nil
                load { data.flatMap { UIImage(data: $0) }.flatMap { GrayImage(uiImage: $0, maxSide: 2400) } }
            }
        }
        .sheet(isPresented: $showAdd) { addSheet }
        .alert("Thông báo", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    // MARK: Bước 1

    private var start: some View {
        Form {
            Section {
                Button { showFile = true } label: { Label("Chọn file PDF hoặc ảnh phiếu trắng", systemImage: "doc") }
                PhotosPicker(selection: $photo, matching: .images) { Label("Chọn ảnh trong Thư viện", systemImage: "photo") }
                if busy { HStack { ProgressView(); Text("Đang tìm ô định vị và ô tròn…") } }
            } footer: {
                Text("""
                Dùng file PDF phiếu trả lời CHƯA TÔ (tốt nhất), hoặc ảnh scan/chụp thẳng.
                • Azota: mở đề thi → In đề – có phiếu trả lời riêng → Tải về “File phiếu trả lời”.
                • Phiếu khác: miễn có ô vuông đen ở 4 góc.
                Sau đó bạn khoanh từng vùng (SBD, mã đề, các cột câu hỏi), app tự khớp vào các ô tròn.
                """)
            }
        }
    }

    private func load(_ make: @escaping () -> GrayImage?) {
        busy = true
        Task.detached(priority: .userInitiated) {
            let img = make()
            let det = img.map { TemplateBuilder.detect($0) }
            await MainActor.run {
                busy = false
                guard let det, let cg = det.image.cgImage() else { message = "Không mở được file."; return }
                guard det.corners != nil else {
                    message = "Không tìm thấy đủ 4 ô vuông đen ở 4 góc phiếu. Hãy dùng file PDF gốc hoặc ảnh rõ, thẳng."
                    return
                }
                detection = det
                uiImage = UIImage(cgImage: cg)
                blocks = []
            }
        }
    }

    // MARK: Bước 2

    private func editor(_ d: TemplateBuilder.Detection, _ img: UIImage) -> some View {
        VStack(spacing: 0) {
            GeometryReader { geo in
                let baseW = geo.size.width
                let dispW = baseW * zoom
                let s = dispW / CGFloat(d.image.width)
                let dispH = CGFloat(d.image.height) * s
                ScrollView([.horizontal, .vertical]) {
                    ZStack(alignment: .topLeading) {
                        Image(uiImage: img).resizable().frame(width: dispW, height: dispH)
                        Canvas { ctx, _ in drawOverlay(ctx, d, s) }
                            .frame(width: dispW, height: dispH)
                            .contentShape(Rectangle())
                            .gesture(DragGesture(minimumDistance: 4)
                                .onChanged { v in
                                    guard drawing else { return }
                                    dragStart = CGPoint(x: v.startLocation.x / s, y: v.startLocation.y / s)
                                    dragNow = CGPoint(x: v.location.x / s, y: v.location.y / s)
                                }
                                .onEnded { _ in if drawing { finishDrag(d) } },
                                including: drawing ? .gesture : .subviews)
                    }
                }
                .scrollDisabled(drawing)
            }
            Divider()
            panel(d)
        }
    }

    private func drawOverlay(_ ctx: GraphicsContext, _ d: TemplateBuilder.Detection, _ s: CGFloat) {
        for m in d.markers {
            let r = CGFloat(m.size) * s / 2
            ctx.stroke(Path(CGRect(x: CGFloat(m.x) * s - r, y: CGFloat(m.y) * s - r, width: 2 * r, height: 2 * r)), with: .color(.blue), lineWidth: 1.5)
        }
        if let c = d.corners {
            for (i, m) in c.enumerated() {
                let p = CGPoint(x: CGFloat(m.x) * s, y: CGFloat(m.y) * s)
                ctx.stroke(Path(ellipseIn: CGRect(x: p.x - 12, y: p.y - 12, width: 24, height: 24)), with: .color(.red), lineWidth: 2.5)
                ctx.draw(Text("\(i + 1)").font(.caption.bold()).foregroundColor(.red), at: CGPoint(x: p.x + 18, y: p.y))
            }
        }
        for b in d.bubbles {
            ctx.fill(Path(ellipseIn: CGRect(x: CGFloat(b.x) * s - 1.5, y: CGFloat(b.y) * s - 1.5, width: 3, height: 3)), with: .color(.green))
        }
        let r = max(3, CGFloat(d.bubbleSize) * s / 2)
        for b in blocks {
            let rect = CGRect(x: b.rect.minX * s, y: b.rect.minY * s, width: b.rect.width * s, height: b.rect.height * s).insetBy(dx: -r * 1.6, dy: -r * 1.6)
            ctx.stroke(Path(rect), with: .color(.orange), lineWidth: 1.5)
            ctx.draw(Text(shortLabel(b)).font(.caption2.bold()).foregroundColor(.orange), at: CGPoint(x: rect.minX + 4, y: rect.minY - 8), anchor: .leading)
            for (row, y) in b.ys.enumerated() {
                for (col, x) in b.xs.enumerated() where cellExists(b.kind, row, col) {
                    ctx.stroke(Path(ellipseIn: CGRect(x: CGFloat(x) * s - r, y: CGFloat(y) * s - r, width: 2 * r, height: 2 * r)), with: .color(.orange), lineWidth: 1.2)
                }
            }
        }
        if let a = dragStart, let b = dragNow {
            let rect = CGRect(x: min(a.x, b.x) * s, y: min(a.y, b.y) * s, width: abs(a.x - b.x) * s, height: abs(a.y - b.y) * s)
            ctx.stroke(Path(rect), with: .color(.purple), style: StrokeStyle(lineWidth: 2, dash: [6, 4]))
        }
    }

    private func cellExists(_ k: TemplateSpec.BlockKind, _ row: Int, _ col: Int) -> Bool {
        guard k == .p3 else { return true }
        return SheetTemplate.p3Cells.contains { $0.row == row && $0.col == col }
    }

    private func shortLabel(_ b: TemplateBuilder.PixelBlock) -> String {
        switch b.kind {
        case .p1: return "I: \(b.first)–\(b.first + b.count - 1)"
        case .p2: return b.count > 1 ? "II: \(b.first)–\(b.first + b.count - 1)" : "II: \(b.first)"
        case .p3: return "III: \(b.first)"
        case .sbd: return "SBD"
        case .code: return "Mã đề"
        }
    }

    private func panel(_ d: TemplateBuilder.Detection) -> some View {
        VStack(spacing: 8) {
            if drawing {
                HStack {
                    Image(systemName: "hand.draw").foregroundStyle(.purple)
                    Text("Kéo từ TÂM ô tròn đầu tiên (trên–trái) tới TÂM ô tròn cuối cùng (dưới–phải) của vùng. Phóng to để kéo cho chính xác.")
                        .font(.footnote)
                    Button("Huỷ") { drawing = false; dragStart = nil; dragNow = nil }
                }
                .padding(.horizontal)
            }
            HStack {
                Button { zoom = max(1, zoom - 0.5) } label: { Image(systemName: "minus.magnifyingglass") }
                Text("\(Int(zoom * 100))%").font(.caption.monospacedDigit()).frame(width: 48)
                Button { zoom = min(5, zoom + 0.5) } label: { Image(systemName: "plus.magnifyingglass") }
                Spacer()
                Button { prepareAdd(); showAdd = true } label: { Label("Thêm vùng", systemImage: "plus.rectangle.on.rectangle") }
                    .buttonStyle(.borderedProminent)
                    .disabled(drawing)
            }
            .padding(.horizontal)
            List {
                Section {
                    TextField("Tên mẫu (ví dụ: Azota v15 – 40 câu)", text: $name)
                    Text("\(d.markers.count) ô vuông định vị · \(d.bubbles.count) ô tròn tìm thấy · 4 góc đánh số đỏ 1–4")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("Các vùng (\(blocks.count))") {
                    if blocks.isEmpty {
                        Text("Chưa có vùng nào. Bấm “Thêm vùng” rồi khoanh SBD, mã đề và từng cột câu hỏi.").font(.footnote).foregroundStyle(.secondary)
                    }
                    ForEach($blocks) { $b in
                        HStack {
                            VStack(alignment: .leading) {
                                Text(longLabel(b)).font(.subheadline)
                                Toggle("Bám ô tròn tìm thấy", isOn: Binding(get: { b.snap }, set: { b.snap = $0; refit(&b, d) }))
                                    .font(.caption)
                            }
                            Spacer()
                            Stepper("", value: Binding(get: { b.first }, set: { b.first = max(1, $0) }), in: 1...200).labelsHidden()
                        }
                    }
                    .onDelete { blocks.remove(atOffsets: $0) }
                }
            }
            .listStyle(.insetGrouped)
            .frame(maxHeight: 260)
        }
        .padding(.top, 8)
        .background(Color(.systemGroupedBackground))
    }

    private func longLabel(_ b: TemplateBuilder.PixelBlock) -> String {
        switch b.kind {
        case .p1: return "Phần I – câu \(b.first) đến \(b.first + b.count - 1)"
        case .p2: return "Phần II – câu \(b.first)" + (b.count > 1 ? " đến \(b.first + b.count - 1)" : "")
        case .p3: return "Phần III – câu \(b.first)"
        case .sbd: return "Số báo danh – \(b.count) chữ số"
        case .code: return "Mã đề – \(b.count) chữ số"
        }
    }

    private var addSheet: some View {
        NavigationStack {
            Form {
                Picker("Loại vùng", selection: $newKind) {
                    ForEach(TemplateSpec.BlockKind.allCases) { Text($0.title).tag($0) }
                }
                .onChange(of: newKind) { _, _ in prepareAdd(keepKind: true) }
                switch newKind {
                case .p1: Stepper("Số câu trong cột: \(newCount)", value: $newCount, in: 1...60)
                case .p2: Stepper("Số câu nằm ngang: \(newCount)", value: $newCount, in: 1...8)
                case .p3: EmptyView()
                case .sbd, .code: Stepper("Số chữ số: \(newCount)", value: $newCount, in: 1...10)
                }
                if newKind != .sbd && newKind != .code {
                    Stepper("Câu bắt đầu: \(newFirst)", value: $newFirst, in: 1...200)
                }
                Section {
                    Text(hint(newKind)).font(.footnote)
                }
            }
            .navigationTitle("Thêm vùng")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Huỷ") { showAdd = false } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Khoanh vùng") { showAdd = false; drawing = true; dragStart = nil; dragNow = nil }
                }
            }
        }
        .presentationDetents([.medium])
    }

    private func hint(_ k: TemplateSpec.BlockKind) -> String {
        switch k {
        case .p1: return "Một cột câu hỏi: mỗi hàng một câu, 4 ô A B C D. Ô đầu = ô A của câu đầu, ô cuối = ô D của câu cuối."
        case .p2: return "4 hàng ý a, b, c, d; mỗi câu 2 cột Đúng, Sai. Nếu nhiều câu nằm ngang cạnh nhau với khoảng cách đều, khoanh một lần."
        case .p3: return "Một câu trả lời ngắn: 12 hàng (dấu “–”, dấu phẩy, chữ số 0–9) × 4 cột. Ô đầu = ô dấu “–”, ô cuối = ô số 9 ở cột thứ 4."
        case .sbd, .code: return "Mỗi cột một chữ số, 10 hàng 0–9. Ô đầu = ô 0 cột đầu, ô cuối = ô 9 cột cuối."
        }
    }

    private func prepareAdd(keepKind: Bool = false) {
        if !keepKind {
            let hasSBD = blocks.contains { $0.kind == .sbd }, hasCode = blocks.contains { $0.kind == .code }
            newKind = !hasSBD ? .sbd : (!hasCode ? .code : .p1)
        }
        switch newKind {
        case .sbd: newCount = 6; newFirst = 1
        case .code: newCount = 3; newFirst = 1
        case .p1: newCount = 10; newFirst = (blocks.filter { $0.kind == .p1 }.map { $0.first + $0.count }.max() ?? 1)
        case .p2: newCount = 1; newFirst = (blocks.filter { $0.kind == .p2 }.map { $0.first + $0.count }.max() ?? 1)
        case .p3: newCount = 1; newFirst = (blocks.filter { $0.kind == .p3 }.map { $0.first + 1 }.max() ?? 1)
        }
    }

    private func finishDrag(_ d: TemplateBuilder.Detection) {
        defer { dragStart = nil; dragNow = nil; drawing = false }
        guard let a = dragStart, let b = dragNow else { return }
        let rect = CGRect(x: min(a.x, b.x), y: min(a.y, b.y), width: abs(a.x - b.x), height: abs(a.y - b.y))
        guard rect.width > 2 || rect.height > 2 else { return }
        var blk = TemplateBuilder.PixelBlock(kind: newKind, first: (newKind == .sbd || newKind == .code) ? 1 : newFirst,
                                             count: newKind == .p3 ? 1 : newCount, rect: rect)
        refit(&blk, d)
        blocks.append(blk)
    }

    private func refit(_ b: inout TemplateBuilder.PixelBlock, _ d: TemplateBuilder.Detection) {
        let shape = TemplateSpec.Block.shape(b.kind, count: b.count)
        let g = TemplateBuilder.fitGrid(d.bubbles, rect: b.rect, rows: shape.rows, cols: shape.cols, snap: b.snap)
        b.xs = g.xs; b.ys = g.ys
    }

    private var canSave: Bool {
        !name.trimmingCharacters(in: .whitespaces).isEmpty && blocks.contains { [.p1, .p2, .p3].contains($0.kind) }
    }

    private func save() {
        guard let d = detection, let spec = TemplateBuilder.makeSpec(name: name.trimmingCharacters(in: .whitespaces), detection: d, blocks: blocks) else {
            message = "Không tạo được mẫu."; return
        }
        // Kiểm tra trùng số câu
        var seen = Set<String>()
        for c in spec.cells() {
            let key = "\(c.kind.rawValue)-\(c.question)-\(c.item)"
            if seen.contains(key) { message = "Có hai vùng trùng số câu (\(c.kind.title), câu \(c.question)). Sửa “câu bắt đầu” rồi lưu lại."; return }
            seen.insert(key)
        }
        store.saveTemplate(spec)
        dismiss()
    }
}

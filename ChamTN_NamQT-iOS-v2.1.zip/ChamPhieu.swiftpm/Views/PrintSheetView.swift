import SwiftUI
import PDFKit

/// Xem trước, in hoặc chia sẻ phiếu trả lời của app.
struct PrintSheetView: View {
    @Environment(\.dismiss) var dismiss
    let exam: Exam
    @State private var copies = 1
    @State private var showName = true
    @State private var twoPerPage = false
    @State private var pdfURL: URL?
    @State private var pdfData: Data?

    var body: some View {
        VStack(spacing: 0) {
            if let pdfData {
                PDFPreview(data: pdfData)
            } else {
                ProgressView().frame(maxHeight: .infinity)
            }
            Form {
                Stepper("Số bản: \(copies)", value: $copies, in: 1...200)
                Toggle("In tên bài chấm trên phiếu", isOn: $showName)
                Toggle("In 2 phiếu / 1 trang A4 (khổ ngang tiết kiệm giấy)", isOn: $twoPerPage)
                Button { printPDF() } label: { Label("In", systemImage: "printer") }
                    .disabled(pdfData == nil)
                if let pdfURL {
                    ShareLink(item: pdfURL) { Label("Lưu / gửi file PDF", systemImage: "square.and.arrow.up") }
                }
            }
            .frame(maxHeight: 280)
        }
        .navigationTitle("In phiếu trả lời")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Xong") { dismiss() } } }
        .onAppear(perform: build)
        .onChange(of: copies) { _, _ in build() }
        .onChange(of: showName) { _, _ in build() }
        .onChange(of: twoPerPage) { _, _ in build() }
    }

    private func build() {
        let c = exam.config
        var opt = SheetPrinter.Options()
        opt.examName = showName ? exam.name : ""
        opt.subtitle = "\(c.p1Count) câu trắc nghiệm" + (c.p2Count > 0 ? " · \(c.p2Count) câu Đúng/Sai" : "") + (c.p3Count > 0 ? " · \(c.p3Count) câu trả lời ngắn" : "")
        opt.copies = copies
        opt.twoPerPage = twoPerPage
        let data = SheetPrinter.pdf(p1: c.p1Count, p2: c.p2Count, p3: c.p3Count, options: opt)
        let safe = exam.name.replacingOccurrences(of: "/", with: "-")
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Phieu tra loi - \(safe).pdf")
        try? data.write(to: url)
        pdfData = data
        pdfURL = url
    }

    private func printPDF() {
        guard let pdfData else { return }
        let info = UIPrintInfo(dictionary: nil)
        info.outputType = .grayscale
        info.jobName = "Phiếu trả lời – \(exam.name)"
        let pc = UIPrintInteractionController.shared
        pc.printInfo = info
        pc.printingItem = pdfData
        pc.present(animated: true)
    }
}

struct PDFPreview: UIViewRepresentable {
    let data: Data
    func makeUIView(context: Context) -> PDFView {
        let v = PDFView()
        v.autoScales = true
        v.displayMode = .singlePageContinuous
        v.backgroundColor = .secondarySystemBackground
        return v
    }
    func updateUIView(_ v: PDFView, context: Context) {
        v.document = PDFDocument(data: data)
    }
}

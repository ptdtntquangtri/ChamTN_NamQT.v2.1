import SwiftUI

struct AnswerKeyEditorView: View {
    @Binding var key: AnswerKey
    let config: ExamConfig
    let existingCodes: [String]

    var body: some View {
        AnswerKeyForm(key: $key, config: config, existingCodes: existingCodes)
            .navigationTitle("Mã đề \(key.code)")
            .navigationBarTitleDisplayMode(.inline)
    }
}

struct AnswerKeyForm: View {
    @Binding var key: AnswerKey
    let config: ExamConfig
    let existingCodes: [String]

    var body: some View {
        Form {
            Section {
                TextField("Mã đề (ví dụ 0101)", text: $key.code)
                    .keyboardType(.numberPad)
                    .font(.title3.monospacedDigit())
                    .onChange(of: key.code) { _, v in
                        let f = String(v.filter(\.isNumber).prefix(4))
                        if f != v { key.code = f }
                    }
                if existingCodes.contains(key.code) {
                    Text("Mã đề này đã có.").foregroundStyle(.red).font(.footnote)
                }
            } header: { Text("Mã đề") }
            AnswerSections(p1: $key.p1, p2: $key.p2, p3: $key.p3, config: config, status: nil)
        }
    }
}

/// Lưới nhập đáp án 3 phần — dùng cho cả đáp án và sửa bài làm của học sinh.
struct AnswerSections: View {
    @Binding var p1: [String]
    @Binding var p2: [String]
    @Binding var p3: [String]
    let config: ExamConfig
    /// Nếu có: tô màu đúng/sai theo kết quả chấm
    let status: GradeResult?

    var body: some View {
        if config.p1Count > 0 {
            let opts = config.p1Choices == 5 ? ["A", "B", "C", "D", "E"] : ["A", "B", "C", "D"]
            Section("Phần I – chọn 1 trong \(opts.count)") {
                ForEach(0..<min(config.p1Count, p1.count), id: \.self) { i in
                    HStack {
                        QuestionLabel(n: i + 1, ok: status?.p1Status[safe: i] ?? nil)
                        ForEach(opts, id: \.self) { l in
                            ChoiceButton(title: l, selected: p1[i] == l, warn: p1[i] == "*") {
                                p1[i] = p1[i] == l ? "" : l
                            }
                        }
                    }
                }
            }
        }
        if config.p2Count > 0 {
            Section("Phần II – Đúng / Sai") {
                ForEach(0..<min(config.p2Count, p2.count), id: \.self) { q in
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Câu \(q + 1)").font(.subheadline.bold())
                        ForEach(0..<4, id: \.self) { i in
                            HStack {
                                let ok: Bool? = status?.p2Status[safe: q]?[safe: i] ?? nil
                                QuestionLabel(text: ["a)", "b)", "c)", "d)"][i], ok: ok)
                                ChoiceButton(title: "Đúng", selected: char(q, i) == "D", warn: char(q, i) == "*") { set(q, i, "D") }
                                ChoiceButton(title: "Sai", selected: char(q, i) == "S", warn: char(q, i) == "*") { set(q, i, "S") }
                            }
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
        }
        if config.p3Count > 0 {
            Section {
                ForEach(0..<min(config.p3Count, p3.count), id: \.self) { i in
                    HStack {
                        QuestionLabel(n: i + 1, ok: status?.p3Status[safe: i] ?? nil)
                        TextField("ví dụ -1,5", text: Binding(
                            get: { p3[i] },
                            set: { p3[i] = String(Grader.normalizeShort($0).filter { "-,0123456789*".contains($0) }.prefix(4)) }))
                            .keyboardType(.numbersAndPunctuation)
                            .font(.body.monospacedDigit())
                    }
                }
            } header: { Text("Phần III – trả lời ngắn") } footer: {
                Text("Tối đa 4 ký tự: dấu trừ, dấu phẩy, chữ số (giống ô tô trên phiếu).")
            }
        }
    }

    private func char(_ q: Int, _ i: Int) -> Character {
        let a = Array(p2[q]); return i < a.count ? a[i] : "_"
    }
    private func set(_ q: Int, _ i: Int, _ c: Character) {
        var a = Array(p2[q].padding(toLength: 4, withPad: "_", startingAt: 0))
        a[i] = a[i] == c ? "_" : c
        p2[q] = String(a)
    }
}

struct QuestionLabel: View {
    var n: Int? = nil
    var text: String? = nil
    var ok: Bool?
    var body: some View {
        HStack(spacing: 2) {
            Text(text ?? "\(n ?? 0).").font(.body.monospacedDigit()).frame(width: 34, alignment: .leading)
            if let ok {
                Image(systemName: ok ? "checkmark.circle.fill" : "xmark.circle.fill")
                    .foregroundStyle(ok ? .green : .red).font(.caption)
            }
        }
        .frame(width: 50, alignment: .leading)
    }
}

struct ChoiceButton: View {
    let title: String
    let selected: Bool
    var warn = false
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.callout.bold())
                .frame(maxWidth: .infinity, minHeight: 34)
                .background(selected ? Color.accentColor : (warn ? Color.orange.opacity(0.25) : Color.secondary.opacity(0.12)))
                .foregroundStyle(selected ? .white : .primary)
                .clipShape(RoundedRectangle(cornerRadius: 8))
        }
        .buttonStyle(.plain)
    }
}

extension Array {
    subscript(safe i: Int) -> Element? { indices.contains(i) ? self[i] : nil }
}

import SwiftUI
import AVFoundation
import UniformTypeIdentifiers

// MARK: - Quét mã QR đáp án

final class QRScannerController: NSObject, AVCaptureMetadataOutputObjectsDelegate {
    let session = AVCaptureSession()
    var onCode: ((String) -> Void)?
    private var done = false

    func configure() -> Bool {
        guard let dev = AVCaptureDevice.default(for: .video),
              let input = try? AVCaptureDeviceInput(device: dev), session.canAddInput(input) else { return false }
        session.addInput(input)
        let out = AVCaptureMetadataOutput()
        guard session.canAddOutput(out) else { return false }
        session.addOutput(out)
        out.setMetadataObjectsDelegate(self, queue: .main)
        out.metadataObjectTypes = [.qr]
        return true
    }

    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput objects: [AVMetadataObject], from connection: AVCaptureConnection) {
        guard !done, let s = (objects.first as? AVMetadataMachineReadableCodeObject)?.stringValue else { return }
        done = true
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        onCode?(s)
    }
}

struct QRPreview: UIViewRepresentable {
    let session: AVCaptureSession
    func makeUIView(context: Context) -> PreviewView {
        let v = PreviewView()
        v.previewLayer.session = session
        return v
    }
    func updateUIView(_ uiView: PreviewView, context: Context) {}
}

struct QRScanSheet: View {
    @Environment(\.dismiss) var dismiss
    var onCode: (String) -> Void
    @State private var controller = QRScannerController()
    @State private var failed = false

    var body: some View {
        ZStack(alignment: .top) {
            Color.black.ignoresSafeArea()
            if failed {
                ContentUnavailableView("Không mở được camera", systemImage: "camera.fill",
                                       description: Text("Kiểm tra quyền camera trong Cài đặt iPhone."))
                    .foregroundStyle(.white)
            } else {
                QRPreview(session: controller.session).ignoresSafeArea()
                RoundedRectangle(cornerRadius: 16).stroke(.white, lineWidth: 3)
                    .frame(width: 260, height: 260)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            HStack {
                Text("Quét mã QR đáp án").font(.headline)
                Spacer()
                Button("Đóng") { dismiss() }
            }
            .foregroundStyle(.white)
            .padding()
            .background(.ultraThinMaterial)
        }
        .task {
            let ok = await AVCaptureDevice.requestAccess(for: .video)
            guard ok, controller.configure() else { failed = true; return }
            controller.onCode = { code in
                let s = controller.session
                DispatchQueue.global().async { s.stopRunning() }
                dismiss()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { onCode(code) }
            }
            let s = controller.session
            DispatchQueue.global(qos: .userInitiated).async { s.startRunning() }
        }
        .onDisappear { let s = controller.session; DispatchQueue.global().async { s.stopRunning() } }
    }
}

// MARK: - Lớp học

struct ClassListView: View {
    @EnvironmentObject var store: Store
    @State private var newName = ""
    @State private var showNew = false

    var body: some View {
        List {
            ForEach(store.classes) { c in
                NavigationLink {
                    if let b = store.classBinding(c.id) { ClassDetailView(classRoom: b) }
                } label: {
                    HStack {
                        Text(c.name)
                        Spacer()
                        Text("\(c.students.count) HS").foregroundStyle(.secondary)
                    }
                }
            }
            .onDelete { store.classes.remove(atOffsets: $0) }
        }
        .overlay {
            if store.classes.isEmpty {
                ContentUnavailableView("Chưa có lớp", systemImage: "person.3",
                                       description: Text("Thêm lớp và danh sách học sinh để bảng điểm hiện họ tên theo số báo danh."))
            }
        }
        .navigationTitle("Lớp học")
        .toolbar { Button { showNew = true } label: { Image(systemName: "plus") } }
        .alert("Lớp mới", isPresented: $showNew) {
            TextField("Tên lớp, ví dụ 12A1", text: $newName)
            Button("Huỷ", role: .cancel) { newName = "" }
            Button("Thêm") {
                let n = newName.trimmingCharacters(in: .whitespaces)
                if !n.isEmpty { store.classes.append(ClassRoom(name: n)) }
                newName = ""
            }
        }
    }
}

struct ClassDetailView: View {
    @Binding var classRoom: ClassRoom
    @State private var showPaste = false
    @State private var showFile = false
    @State private var editing: Student?
    @State private var message: String?

    var body: some View {
        List {
            Section {
                ForEach(classRoom.students.sorted { $0.sbd < $1.sbd }) { s in
                    Button { editing = s } label: {
                        HStack {
                            Text(s.sbd).font(.body.monospacedDigit()).frame(width: 90, alignment: .leading)
                            Text(s.name)
                        }
                    }
                    .foregroundStyle(.primary)
                }
                .onDelete { idx in
                    let sorted = classRoom.students.sorted { $0.sbd < $1.sbd }
                    let ids = idx.map { sorted[$0].id }
                    classRoom.students.removeAll { ids.contains($0.id) }
                }
            } header: {
                Text("\(classRoom.students.count) học sinh")
            } footer: {
                Text("Số báo danh trên danh sách phải trùng với số học sinh tô trên phiếu.")
            }
        }
        .navigationTitle(classRoom.name)
        .toolbar {
            Menu {
                Button { editing = Student(sbd: "", name: "") } label: { Label("Thêm học sinh", systemImage: "person.badge.plus") }
                Button { showPaste = true } label: { Label("Dán danh sách từ Excel", systemImage: "doc.on.clipboard") }
                Button { showFile = true } label: { Label("Mở file Excel (.xlsx) / CSV", systemImage: "tablecells") }
            } label: { Image(systemName: "plus") }
        }
        .sheet(item: $editing) { s in
            NavigationStack { StudentEditView(student: s) { new in
                if let i = classRoom.students.firstIndex(where: { $0.id == new.id }) { classRoom.students[i] = new }
                else { classRoom.students.append(new) }
            } }
        }
        .sheet(isPresented: $showPaste) {
            NavigationStack { PasteStudentsView { merge($0) } }
        }
        .fileImporter(isPresented: $showFile, allowedContentTypes: UTType.tableFiles) { result in
            guard case let .success(url) = result else { return }
            do {
                let list = PasteStudentsView.parse(try AnswerKeyIO.textOfTable(url))
                merge(list)
                message = "Đã nhập \(list.count) học sinh."
            } catch { message = error.localizedDescription }
        }
        .alert("Thông báo", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    private func merge(_ list: [Student]) {
        for st in list {
            if let i = classRoom.students.firstIndex(where: { $0.sbd == st.sbd }) { classRoom.students[i].name = st.name }
            else { classRoom.students.append(st) }
        }
    }
}

struct StudentEditView: View {
    @Environment(\.dismiss) var dismiss
    @State var student: Student
    var onSave: (Student) -> Void
    var body: some View {
        Form {
            TextField("Số báo danh", text: $student.sbd).keyboardType(.numberPad)
            TextField("Họ và tên", text: $student.name)
        }
        .navigationTitle("Học sinh")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Huỷ") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("Lưu") { onSave(student); dismiss() }.disabled(student.sbd.isEmpty)
            }
        }
    }
}

struct PasteStudentsView: View {
    @Environment(\.dismiss) var dismiss
    var onImport: ([Student]) -> Void
    @State private var text = ""

    var body: some View {
        Form {
            Section {
                TextEditor(text: $text).frame(minHeight: 240).font(.system(.footnote, design: .monospaced))
                Button("Dán từ bộ nhớ tạm") { text = UIPasteboard.general.string ?? "" }
            } footer: {
                Text("Copy 2 cột trong Excel: Số báo danh | Họ và tên. Mỗi dòng một học sinh.")
            }
        }
        .navigationTitle("Dán danh sách")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Huỷ") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("Nhập") { onImport(Self.parse(text)); dismiss() }
            }
        }
    }

    static func parse(_ text: String) -> [Student] {
        text.split(whereSeparator: \.isNewline).compactMap { line in
            let cells = line.split(whereSeparator: { $0 == "\t" || $0 == ";" || $0 == "," }).map { $0.trimmingCharacters(in: .whitespaces) }
            guard cells.count >= 2 else { return nil }
            // Chấp nhận cả thứ tự "Họ tên | SBD"
            if !cells[0].isEmpty, cells[0].allSatisfy(\.isNumber) {
                return Student(sbd: cells[0], name: cells[1])
            } else if cells[1].allSatisfy(\.isNumber), !cells[1].isEmpty {
                return Student(sbd: cells[1], name: cells[0])
            }
            return nil
        }
    }
}

// MARK: - Cài đặt

struct SettingsView: View {
    @AppStorage(SettingKey.autoMode) private var autoMode = true
    @AppStorage(SettingKey.stableFrames) private var stableFrames = 3
    @AppStorage(SettingKey.sound) private var sound = true
    @AppStorage(SettingKey.saveImages) private var saveImages = true
    @State private var testResult: String?
    @EnvironmentObject var store: Store
    @ObservedObject private var sync = SyncManager.shared
    @State private var pickFolder = false

    var body: some View {
        Form {
            Section {
                if let name = sync.folderName {
                    LabeledContent("Thư mục", value: name)
                    Toggle("Tự đồng bộ khi mở / thoát app", isOn: $sync.auto)
                    Button {
                        sync.sync(store)
                    } label: {
                        HStack {
                            Label("Đồng bộ ngay", systemImage: "arrow.triangle.2.circlepath.icloud")
                            if sync.busy { Spacer(); ProgressView() }
                        }
                    }
                    .disabled(sync.busy)
                    Button("Đổi thư mục") { pickFolder = true }
                    Button("Ngắt đồng bộ", role: .destructive) { sync.disconnect() }
                } else {
                    Button { pickFolder = true } label: { Label("Chọn thư mục đám mây", systemImage: "icloud") }
                }
                Text(sync.status + (sync.lastSync.map { " · lần cuối \($0.formatted(date: .abbreviated, time: .shortened))" } ?? ""))
                    .font(.footnote).foregroundStyle(.secondary)
            } header: { Text("Đồng bộ đám mây") } footer: {
                Text("Chọn một thư mục trong iCloud Drive, Google Drive, OneDrive hoặc Dropbox (qua app Tệp). App lưu bài chấm, đáp án, lớp học và ảnh phiếu vào thư mục con “ChamTN_NamQT”. Trên iPhone/iPad khác, cài app và chọn cùng thư mục đó để dùng chung dữ liệu. Nếu hai máy cùng sửa một bài, bản sửa sau cùng được giữ.")
            }
            .fileImporter(isPresented: $pickFolder, allowedContentTypes: [.folder]) { result in
                if case let .success(url) = result {
                    sync.setFolder(url)
                    sync.sync(store)
                }
            }

            Section {
                NavigationLink { TemplateListView() } label: {
                    Label("Mẫu phiếu (TNMaker, Azota…)", systemImage: "doc.viewfinder")
                }
            }
            Section {
                Toggle("Tự động chấm phiếu tiếp theo", isOn: $autoMode)
                Picker("Tốc độ chấm", selection: $stableFrames) {
                    Text("Nhanh").tag(2)
                    Text("Chuẩn").tag(3)
                    Text("Chắc chắn").tag(5)
                }
                Toggle("Âm báo khi chấm xong", isOn: $sound)
                Toggle("Lưu ảnh phiếu đã chấm", isOn: $saveImages)
            } header: { Text("Chấm bài") } footer: {
                Text("“Chắc chắn” đợi nhiều khung hình giống hệt nhau hơn trước khi nhận phiếu, ít nhầm hơn nhưng chậm hơn. Tắt “Tự động” để xem và xác nhận từng phiếu.")
            }
            Section("Hướng dẫn nhanh") {
                Text("""
                1. Tạo bài chấm, chọn môn (số câu và biểu điểm theo QĐ 764).
                2. Nhập đáp án cho từng mã đề (nhập tay, dán từ Excel, file CSV hoặc mã QR).
                3. Đặt phiếu trên mặt phẳng, đủ sáng. Bấm “Chấm bằng camera”, đưa máy sao cho thấy đủ 6 ô vuông đen ở hai bên Phần I, II, III. Khung xanh hiện ra là máy đã nhận phiếu.
                4. Giữ yên 1 giây — máy kêu “tít” và hiện điểm. Đưa phiếu tiếp theo.
                5. Xem bảng điểm, sửa bài nhận nhầm, xuất file CSV mở bằng Excel.
                """).font(.footnote)
            }
            Section {
                Button("Chạy kiểm tra chấm điểm") { testResult = SelfTest.run() }
                if let testResult { Text(testResult).font(.footnote.monospaced()) }
            } header: { Text("Kiểm tra") }
            Section {
                Text("Dữ liệu chỉ lưu trên máy này. Ứng dụng không cần tài khoản và không gửi dữ liệu ra ngoài.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Cài đặt")
    }
}

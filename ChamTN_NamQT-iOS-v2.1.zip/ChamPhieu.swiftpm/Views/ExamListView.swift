import SwiftUI

struct ExamListView: View {
    @EnvironmentObject var store: Store
    @State private var showNew = false
    @State private var copySource: Exam?

    var body: some View {
        List {
            ForEach(store.exams) { exam in
                NavigationLink(value: exam.id) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(exam.name).font(.headline)
                        HStack(spacing: 12) {
                            Label(exam.config.subject.title, systemImage: "book")
                            Label("\(exam.keys.count) mã đề", systemImage: "key")
                            Label("\(exam.records.count) bài", systemImage: "checkmark.circle")
                        }
                        .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        if let c = store.classRoom(exam.classId) {
                            Text("Lớp \(c.name)").font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                .contextMenu {
                    Button { copySource = exam } label: { Label("Sao chép bài chấm", systemImage: "doc.on.doc") }
                }
                .swipeActions(edge: .leading) {
                    Button { copySource = exam } label: { Label("Sao chép", systemImage: "doc.on.doc") }.tint(.indigo)
                }
            }
            .onDelete { idx in store.delete(examIDs: idx.map { store.exams[$0].id }) }
        }
        .overlay {
            if store.exams.isEmpty {
                ContentUnavailableView {
                    Label("Chưa có bài chấm", systemImage: "doc.text.viewfinder")
                } description: {
                    Text("Tạo bài chấm, nhập đáp án theo mã đề rồi đưa camera lên phiếu trả lời của Bộ GD&ĐT.")
                } actions: {
                    Button("Tạo bài chấm") { showNew = true }.buttonStyle(.borderedProminent)
                }
            }
        }
        .navigationTitle("Bài chấm")
        .navigationDestination(for: UUID.self) { id in
            if let b = store.examBinding(id) { ExamDetailView(exam: b) }
        }
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button { showNew = true } label: { Image(systemName: "plus") }
            }
        }
        .sheet(isPresented: $showNew) {
            NavigationStack {
                ExamEditorView(exam: Exam(name: defaultName(), config: Subject.toan.preset), isNew: true) { e in
                    store.exams.insert(e, at: 0)
                }
            }
        }
        .sheet(item: $copySource) { src in
            NavigationStack { CopyExamView(source: src) }
        }
    }

    private func defaultName() -> String {
        let f = DateFormatter(); f.dateFormat = "dd/MM"
        return "Kiểm tra \(f.string(from: Date()))"
    }
}

/// Sao chép bài chấm (cùng đáp án) cho lớp/phòng khác.
struct CopyExamView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    let source: Exam
    @State private var name = ""
    @State private var classId: UUID?

    var body: some View {
        Form {
            TextField("Tên bài chấm mới", text: $name)
            Picker("Lớp", selection: $classId) {
                Text("Không chọn").tag(UUID?.none)
                ForEach(store.classes) { c in Text(c.name).tag(UUID?.some(c.id)) }
            }
            Section { Text("Bài mới giữ nguyên cấu hình và \(source.keys.count) mã đề, không gồm bài đã chấm.").font(.footnote) }
        }
        .navigationTitle("Sao chép bài chấm")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { name = source.name + " (bản sao)"; classId = source.classId }
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Huỷ") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("Tạo") { store.duplicate(source, name: name, classId: classId); dismiss() }
                    .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
    }
}

/// Tạo / sửa cấu hình bài chấm.
struct ExamEditorView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    @State var exam: Exam
    var isNew: Bool
    var onSave: (Exam) -> Void

    private var isAppSheet: Bool { if case .app = exam.config.sheet { return true } else { return false } }

    private var sheetChoice: String {
        switch exam.config.sheet {
        case .official2025: return "official"
        case .app: return "app"
        case let .spec(id): return id
        }
    }

    private var limits: (p1: Int, p2: Int, p3: Int) {
        switch exam.config.sheet {
        case .official2025: return (40, 8, 6)
        case .app: return (AppSheetLayout.maxP1, AppSheetLayout.maxP2, AppSheetLayout.maxP3)
        case let .spec(id):
            let c = TemplateRegistry.shared.spec(id)?.caps ?? TemplateSpec.Caps()
            return (c.p1, c.p2, c.p3)
        }
    }

    private func clampToSheet() {
        let l = limits
        exam.config.p1Count = min(exam.config.p1Count, l.p1)
        exam.config.p2Count = min(exam.config.p2Count, l.p2)
        exam.config.p3Count = min(exam.config.p3Count, l.p3)
        if exam.config.p1Count == 0 && exam.config.p2Count == 0 && exam.config.p3Count == 0 { exam.config.p1Count = l.p1 }
    }

    private var sheetFooter: String {
        switch exam.config.sheet {
        case .official2025: return "Phiếu của Bộ có tối đa 40 – 8 – 6 câu. Môn chỉ có 1 hoặc 2 phần thì đặt số câu phần còn lại bằng 0."
        case .app: return "Phiếu in từ app (A4) có đúng số câu trên, SBD 6 số, mã đề 3 số. Phiếu 1 phần: đặt Phần II và III bằng 0. In phiếu trong màn hình bài chấm. Đổi số câu thì phải in lại phiếu."
        case let .spec(id):
            guard let sp = TemplateRegistry.shared.spec(id) else { return "Mẫu phiếu đã bị xoá." }
            return "\(sp.name): \(sp.summary). Số câu của bài có thể ít hơn số câu trên phiếu. Thêm mẫu Azota trong Cài đặt → Mẫu phiếu."
        }
    }

    var body: some View {
        Form {
            Section("Thông tin") {
                TextField("Tên bài chấm", text: $exam.name)
                Picker("Lớp", selection: $exam.classId) {
                    Text("Không chọn").tag(UUID?.none)
                    ForEach(store.classes) { c in Text(c.name).tag(UUID?.some(c.id)) }
                }
            }
            Section {
                Picker("Môn / cấu trúc", selection: Binding(
                    get: { exam.config.subject },
                    set: {
                        let sheet = exam.config.sheet
                        let em = exam.config.essayMaxScore
                        let rm = exam.config.roundMode
                        exam.config = $0.preset
                        exam.config.sheet = sheet
                        exam.config.essayMaxScore = em
                        exam.config.roundMode = rm
                    })) {
                    ForEach(Subject.allCases) { s in Text(s.title).tag(s) }
                }
                NavigationLink {
                    SheetPickerView(selectedKey: sheetChoice) { choice in
                        switch choice {
                        case "official": exam.config.sheet = .official2025
                        case "app": exam.config.sheet = .app(p1: exam.config.p1Count, p2: exam.config.p2Count, p3: exam.config.p3Count)
                        default:
                            exam.config.sheet = .spec(id: choice)
                            if choice.hasPrefix("qm-2025-"), let c = TemplateRegistry.shared.spec(choice)?.caps {
                                exam.config.p1Count = c.p1; exam.config.p2Count = c.p2; exam.config.p3Count = c.p3
                                if choice == "qm-2025-azota-tntl" && exam.config.essayMax <= 0 { exam.config.essayMaxScore = 3.0 }
                            } else {
                                clampToSheet()
                            }
                        }
                    }
                } label: {
                    LabeledContent("Mẫu phiếu", value: exam.config.sheet.title)
                }
                Stepper("Phần I: \(exam.config.p1Count) câu", value: $exam.config.p1Count, in: 0...limits.p1)
                Stepper("Phần II: \(exam.config.p2Count) câu", value: $exam.config.p2Count, in: 0...limits.p2)
                Stepper("Phần III: \(exam.config.p3Count) câu", value: $exam.config.p3Count, in: 0...limits.p3)
                if let problem = exam.config.sheetProblem {
                    Text(problem).font(.footnote).foregroundStyle(.red)
                }
            } header: { Text("Cấu trúc đề") } footer: {
                Text(sheetFooter)
            }
            Section {
                PointField(title: "Mỗi câu Phần I", value: $exam.config.p1Point)
                ForEach(0..<4, id: \.self) { i in
                    PointField(title: "Phần II đúng \(i + 1) ý", value: $exam.config.p2Scale[i])
                }
                PointField(title: "Mỗi câu Phần III", value: $exam.config.p3Point)
                PointField(title: "Điểm Tự luận tối đa (0 = không có)", value: Binding(
                    get: { exam.config.essayMax },
                    set: { exam.config.essayMaxScore = $0 > 0 ? $0 : nil }))
                Picker("Làm tròn điểm", selection: Binding(
                    get: { exam.config.effectiveRoundMode },
                    set: { exam.config.roundMode = $0 })) {
                    ForEach(RoundMode.allCases) { m in Text(m.title).tag(m) }
                }
                Toggle("Quy về thang điểm 10", isOn: $exam.config.scaleTo10)
            } header: { Text("Biểu điểm") } footer: {
                Text("Tổng điểm tối đa: \(Grader.format(exam.config.totalMaxScore))" + (exam.config.essayMax > 0 ? " (gồm \(Grader.format(exam.config.essayMax))đ tự luận)" : "") + ". Mặc định theo QĐ 764/QĐ-BGDĐT: Phần II đúng 1/2/3/4 ý được 0,1/0,25/0,5/1 điểm.")
            }
        }
        .navigationTitle(isNew ? "Bài chấm mới" : "Sửa bài chấm")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Huỷ") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("Lưu") {
                    exam.config.syncSheet()
                    exam.keys = exam.keys.map { $0.resized(to: exam.config) }
                    onSave(exam); dismiss()
                }.disabled(exam.name.trimmingCharacters(in: .whitespaces).isEmpty || exam.config.sheetProblem != nil)
            }
        }
    }
}

struct PointField: View {
    let title: String
    @Binding var value: Double
    var body: some View {
        HStack {
            Text(title)
            Spacer()
            TextField("0", value: $value, format: .number.precision(.fractionLength(0...3)))
                .keyboardType(.decimalPad)
                .multilineTextAlignment(.trailing)
                .frame(width: 80)
        }
    }
}

/// Danh sách chọn phiếu chấm phân nhóm: 1. Bộ GD&ĐT · 2. TNMaker (a..l) · 3. QM (a..j) · 4. Mẫu tự tạo.
struct SheetPickerView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    let selectedKey: String
    var onSelect: (String) -> Void

    private let letters = Array("abcdefghijklmnopqrstuvwxyz")

    var body: some View {
        List {
            Section("1. Phiếu chuẩn của Bộ GD&ĐT") {
                row("Phiếu chuẩn của Bộ GD&ĐT (CV 1239 / 2025)", sub: "40 – 8 – 6 · SBD 8 số, mã đề 4 số", key: "official")
                row("Phiếu in từ app (1 hoặc 2 phiếu/A4)", sub: "Tự sinh đúng số câu bài chấm", key: "app")
            }
            Section("2. Phiếu TNMaker") {
                ForEach(Array(BuiltinTemplates.tnmaker.enumerated()), id: \.element.id) { i, t in
                    row("\(String(letters[i])). \(t.name)", sub: t.summary, key: t.id)
                }
            }
            Section("3. Phiếu QM") {
                ForEach(Array(BuiltinTemplates.qm.enumerated()), id: \.element.id) { i, t in
                    row("\(String(letters[i])). \(t.name)", sub: t.summary, key: t.id)
                }
            }
            if !store.templates.isEmpty {
                Section("4. Mẫu tự tạo") {
                    ForEach(store.templates) { t in
                        row(t.name, sub: t.summary, key: t.id)
                    }
                }
            }
        }
        .navigationTitle("Chọn mẫu phiếu")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func row(_ title: String, sub: String, key: String) -> some View {
        Button {
            onSelect(key)
            dismiss()
        } label: {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).foregroundStyle(.primary)
                    Text(sub).font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                if selectedKey == key {
                    Image(systemName: "checkmark").foregroundStyle(.blue).fontWeight(.semibold)
                }
            }
        }
    }
}

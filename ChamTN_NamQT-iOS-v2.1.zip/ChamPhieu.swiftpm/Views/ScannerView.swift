import SwiftUI
import AVFoundation
import AudioToolbox

/// Phiếu vừa đọc, chờ giáo viên xác nhận (chế độ thủ công hoặc chấm từ ảnh).
struct PendingScan: Identifiable {
    let id = UUID()
    let reading: SheetReading
    let rectified: GrayImage
    let sheet: SheetKind
}

// MARK: - Camera

final class CameraController: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    let session = AVCaptureSession()
    private let queue = DispatchQueue(label: "champhieu.camera", qos: .userInitiated)
    private var device: AVCaptureDevice?
    /// Gọi trên hàng đợi camera với mỗi khung hình (khung đến trễ bị bỏ qua).
    var onFrame: ((GrayImage) -> Void)?
    var paused = false

    func configure() -> Bool {
        session.beginConfiguration()
        session.sessionPreset = .hd1920x1080
        guard let dev = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let input = try? AVCaptureDeviceInput(device: dev), session.canAddInput(input) else {
            session.commitConfiguration(); return false
        }
        session.addInput(input)
        device = dev
        let out = AVCaptureVideoDataOutput()
        out.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_420YpCbCr8BiPlanarFullRange]
        out.alwaysDiscardsLateVideoFrames = true
        out.setSampleBufferDelegate(self, queue: queue)
        if session.canAddOutput(out) { session.addOutput(out) }
        session.commitConfiguration()
        if (try? dev.lockForConfiguration()) != nil {
            if dev.isFocusModeSupported(.continuousAutoFocus) { dev.focusMode = .continuousAutoFocus }
            if dev.isAutoFocusRangeRestrictionSupported { dev.autoFocusRangeRestriction = .near }
            dev.unlockForConfiguration()
        }
        return true
    }

    func start() { queue.async { if !self.session.isRunning { self.session.startRunning() } } }
    func stop() { queue.async { if self.session.isRunning { self.session.stopRunning() } } }

    func setTorch(_ on: Bool) {
        guard let d = device, d.hasTorch, (try? d.lockForConfiguration()) != nil else { return }
        d.torchMode = on ? .on : .off
        d.unlockForConfiguration()
    }

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard !paused, let pb = CMSampleBufferGetImageBuffer(sampleBuffer), let img = GrayImage(pixelBuffer: pb) else { return }
        onFrame?(img)
    }
}

/// Lớp xem trước camera + khung xanh đánh dấu phiếu đã nhận.
final class PreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var previewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
    let quadLayer = CAShapeLayer()

    override init(frame: CGRect) {
        super.init(frame: frame)
        previewLayer.videoGravity = .resizeAspectFill
        quadLayer.strokeColor = UIColor.systemGreen.cgColor
        quadLayer.fillColor = UIColor.systemGreen.withAlphaComponent(0.12).cgColor
        quadLayer.lineWidth = 3
        layer.addSublayer(quadLayer)
    }
    required init?(coder: NSCoder) { fatalError() }

    override func layoutSubviews() {
        super.layoutSubviews()
        quadLayer.frame = bounds
        if let c = previewLayer.connection {
            if c.isVideoRotationAngleSupported(90) { c.videoRotationAngle = 90 }
        }
    }

    /// corners: toạ độ khung hình gốc (cảm biến nằm ngang).
    func showQuad(_ corners: [CGPoint]?, frameSize: CGSize) {
        guard let corners, corners.count == 4 else { quadLayer.path = nil; return }
        let path = UIBezierPath()
        for (i, p) in corners.enumerated() {
            let dp = CGPoint(x: p.x / frameSize.width, y: p.y / frameSize.height)
            let lp = previewLayer.layerPointConverted(fromCaptureDevicePoint: dp)
            if i == 0 { path.move(to: lp) } else { path.addLine(to: lp) }
        }
        path.close()
        quadLayer.path = path.cgPath
    }
}

struct CameraPreview: UIViewRepresentable {
    let controller: CameraController
    let model: ScannerModel
    func makeUIView(context: Context) -> PreviewView {
        let v = PreviewView()
        v.previewLayer.session = controller.session
        model.previewView = v
        return v
    }
    func updateUIView(_ uiView: PreviewView, context: Context) {}
}

// MARK: - Model

/// Điều phối camera → bộ nhận dạng → lưu kết quả. `process` chạy trên hàng đợi camera, phần còn lại trên luồng chính.
final class ScannerModel: ObservableObject {
    struct Banner: Equatable { var title: String; var detail: String; var color: Color }

    @Published var banner: Banner?
    @Published var hint = "Đưa phiếu vào khung, thấy rõ các ô vuông đen định vị"
    @Published var sessionCount = 0
    @Published var pending: PendingScan?
    @Published var torch = false
    @Published var denied = false

    let camera = CameraController()
    weak var previewView: PreviewView?
    let examID: UUID
    weak var store: Store?

    /// Trạng thái chỉ dùng trên hàng đợi camera.
    final class FrameState {
        var lastSig = ""
        var stable = 0
        var acceptedSig = ""
        var missing = 0
        var autoMode = true
        var needStable = 3
        var saveImages = true
        var acceptedSBD = ""
        var template = SheetTemplate(kind: .official2025)
    }
    let state = FrameState()

    init(examID: UUID) { self.examID = examID }

    @MainActor func start() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: setup()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { ok in
                Task { @MainActor in if ok { self.setup() } else { self.denied = true } }
            }
        default: denied = true
        }
    }

    @MainActor private func setup() {
        guard camera.configure() else { denied = true; return }
        camera.onFrame = { [weak self] img in self?.process(img) }
        camera.start()
    }

    func stop() { camera.stop(); camera.setTorch(false) }

    @MainActor func toggleTorch() { torch.toggle(); camera.setTorch(torch) }

    private func process(_ img: GrayImage) {
        let size = CGSize(width: img.width, height: img.height)
        let st = state
        guard let reading = OMREngine.read(img, template: st.template) else {
            st.missing += 1
            if st.missing >= 6 { st.acceptedSig = ""; st.acceptedSBD = ""; st.stable = 0; st.lastSig = "" }
            Task { @MainActor in
                self.previewView?.showQuad(nil, frameSize: size)
                self.hint = "Đưa phiếu vào khung, thấy rõ các ô vuông đen định vị"
            }
            return
        }
        st.missing = 0
        let sig = reading.signature
        st.stable = sig == st.lastSig ? st.stable + 1 : 1
        st.lastSig = sig
        // Cùng SBD với phiếu vừa chấm (phiếu chưa rời khung) → không chấm lại
        let sameSheet = !st.acceptedSBD.isEmpty && reading.sbd == st.acceptedSBD
        let ready = st.stable >= st.needStable && sig != st.acceptedSig && !sameSheet
        let already = sig == st.acceptedSig || sameSheet
        Task { @MainActor in
            self.previewView?.showQuad(reading.corners, frameSize: size)
            self.hint = already ? "Đã chấm phiếu này – đưa phiếu tiếp theo" : "Giữ yên…"
        }
        guard ready else { return }
        st.acceptedSig = sig
        st.acceptedSBD = reading.sbd.contains("?") ? "" : reading.sbd
        let used = reading.template(fallback: st.template)
        let rect = OMREngine.rectify(img, sheetToImage: reading.sheetToImage, template: used)
        let p = PendingScan(reading: reading, rectified: rect, sheet: used.kind)
        if st.autoMode {
            let imageName = st.saveImages ? Files.saveImage(rect) : nil
            Task { @MainActor in self.commit(p, imageName: imageName) }
        } else {
            camera.paused = true
            Task { @MainActor in self.pending = p }
        }
    }

    /// Lưu kết quả và hiện thông báo điểm.
    @MainActor func commit(_ p: PendingScan, imageName: String?) {
        guard let store, let exam = store.exams.first(where: { $0.id == examID }) else { return }
        let r = p.reading
        let rec = ScanRecord(sbd: r.sbd, code: r.code, p1: r.p1, p2: r.p2, p3: r.p3, imageName: imageName, cells: r.cells.filter(\.filled), sheet: p.sheet)
        let replaced = store.upsert(record: rec, in: examID)
        sessionCount += 1
        let cls = store.classRoom(exam.classId)
        let name = cls?.student(sbd: r.sbd)?.name
        let unknownInClass = cls != nil && name == nil
        let who = name.map { "\($0) – SBD \(r.sbd)" } ?? "SBD \(r.sbd.isEmpty ? "(trống)" : r.sbd)"
        if let g = Grader.grade(rec, exam: exam) {
            var detail = "Mã đề \(r.code) · P.I đúng \(g.p1Correct) · P.II \(Grader.format(g.p2Score))đ · P.III đúng \(g.p3Correct)"
            if g.invalid > 0 { detail += " · \(g.invalid) phạm quy" }
            if replaced { detail += " · ⚠️ TRÙNG SBD (đã thay bài cũ)" }
            if unknownInClass { detail += " · ⚠️ SBD ngoài lớp" }
            let warn = g.invalid > 0 || r.sbd.contains("?") || replaced || unknownInClass
            banner = Banner(title: "\(Grader.format(g.score10)) điểm – \(who)", detail: detail, color: warn ? .orange : .green)
            UINotificationFeedbackGenerator().notificationOccurred(warn ? .warning : .success)
        } else {
            banner = Banner(title: "Chưa có đáp án mã đề \(r.code.isEmpty ? "(trống)" : r.code)",
                            detail: "\(who). Đã lưu bài, điểm sẽ tính khi nhập đáp án.", color: .red)
            UINotificationFeedbackGenerator().notificationOccurred(.error)
        }
        if UserDefaults.standard.object(forKey: SettingKey.sound) as? Bool ?? true { AudioServicesPlaySystemSound(1057) }
    }

    func resume() { camera.paused = false }
}

// MARK: - View

struct ScannerView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    @AppStorage(SettingKey.autoMode) private var autoMode = true
    @AppStorage(SettingKey.stableFrames) private var stableFrames = 3
    @AppStorage(SettingKey.saveImages) private var saveImages = true
    @StateObject private var model: ScannerModel

    init(examID: UUID) { _model = StateObject(wrappedValue: ScannerModel(examID: examID)) }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            if model.denied {
                ContentUnavailableView("Chưa cho phép dùng camera", systemImage: "camera.fill",
                                       description: Text("Vào Cài đặt iPhone → Quyền riêng tư → Camera để bật cho ứng dụng."))
                    .foregroundStyle(.white)
            } else {
                CameraPreview(controller: model.camera, model: model).ignoresSafeArea()
            }
            VStack {
                HStack {
                    Button { model.stop(); dismiss() } label: {
                        Image(systemName: "xmark").font(.title2.bold()).padding(12).background(.ultraThinMaterial, in: Circle())
                    }
                    Spacer()
                    Text("Đã chấm: \(model.sessionCount)")
                        .font(.headline).padding(.horizontal, 12).padding(.vertical, 8)
                        .background(.ultraThinMaterial, in: Capsule())
                    Spacer()
                    Button { model.toggleTorch() } label: {
                        Image(systemName: model.torch ? "flashlight.on.fill" : "flashlight.off.fill")
                            .font(.title2).padding(12).background(.ultraThinMaterial, in: Circle())
                    }
                }
                .foregroundStyle(.white)
                .padding()
                Spacer()
                if let b = model.banner {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(b.title).font(.title3.bold())
                        Text(b.detail).font(.footnote)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(b.color.opacity(0.9), in: RoundedRectangle(cornerRadius: 14))
                    .foregroundStyle(.white)
                    .padding(.horizontal)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                }
                HStack {
                    Text(model.hint).font(.footnote)
                    Spacer()
                    Toggle("Tự động", isOn: $autoMode).fixedSize()
                }
                .padding()
                .background(.ultraThinMaterial)
                .foregroundStyle(.white)
            }
        }
        .animation(.easeInOut, value: model.banner)
        .onAppear {
            model.store = store
            model.state.autoMode = autoMode
            model.state.needStable = stableFrames
            model.state.saveImages = saveImages
            if let e = store.exams.first(where: { $0.id == model.examID }) { model.state.template = e.config.template }
            model.start()
        }
        .onDisappear { model.stop() }
        .onChange(of: autoMode) { _, v in model.state.autoMode = v }
        .sheet(item: $model.pending, onDismiss: { model.resume() }) { p in
            NavigationStack { PendingScanView(examID: model.examID, pending: p) { edited, name in model.commit(edited, imageName: name) } }
        }
        .statusBarHidden()
    }
}

/// Xác nhận một phiếu (chế độ thủ công / ảnh): xem điểm, sửa SBD, mã đề rồi lưu.
struct PendingScanView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    @AppStorage(SettingKey.saveImages) private var saveImages = true
    let examID: UUID
    let pending: PendingScan
    var onCommit: ((PendingScan, String?) -> Void)? = nil
    @State private var sbd = ""
    @State private var code = ""

    var body: some View {
        let exam = store.exams.first { $0.id == examID }
        Form {
            Section {
                if let cg = pending.rectified.cgImage() {
                    SheetOverlayImage(image: UIImage(cgImage: cg), cells: pending.reading.cells, status: grade(exam), exam: exam, sheet: pending.sheet)
                        .frame(maxHeight: 360)
                }
            }
            Section("Thông tin") {
                TextField("Số báo danh", text: $sbd).keyboardType(.numberPad)
                TextField("Mã đề", text: $code).keyboardType(.numberPad)
                if let exam, exam.key(for: code) == nil {
                    Text("Chưa có đáp án cho mã đề này.").foregroundStyle(.red).font(.footnote)
                }
            }
            if let g = grade(exam) {
                Section("Điểm") { ScoreSummary(g: g) }
            }
        }
        .navigationTitle("Kết quả phiếu")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { sbd = pending.reading.sbd; code = pending.reading.code }
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Bỏ qua") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("Lưu") { save() } }
        }
    }

    private func grade(_ exam: Exam?) -> GradeResult? {
        guard let exam, let key = exam.key(for: code) else { return nil }
        let r = pending.reading
        return Grader.grade(p1: r.p1, p2: r.p2, p3: r.p3, key: key, config: exam.config)
    }

    private func save() {
        let name = saveImages ? Files.saveImage(pending.rectified) : nil
        var reading = pending.reading
        reading.sbd = sbd; reading.code = code
        let p = PendingScan(reading: reading, rectified: pending.rectified, sheet: pending.sheet)
        if let onCommit { onCommit(p, name) } else {
            let r = p.reading
            store.upsert(record: ScanRecord(sbd: r.sbd, code: r.code, p1: r.p1, p2: r.p2, p3: r.p3, imageName: name,
                                            cells: r.cells.filter(\.filled), sheet: p.sheet, edited: sbd != pending.reading.sbd || code != pending.reading.code),
                         in: examID)
        }
        dismiss()
    }
}

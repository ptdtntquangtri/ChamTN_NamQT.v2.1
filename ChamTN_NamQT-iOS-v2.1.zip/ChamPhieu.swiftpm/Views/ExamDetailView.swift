import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

struct ExamDetailView: View {
    @EnvironmentObject var store: Store
    @Binding var exam: Exam

    @State private var showScanner = false
    @State private var showEdit = false
    @State private var newKey: AnswerKey?
    @State private var showPaste = false
    @State private var showFileImporter = false
    @State private var showQRScan = false
    @State private var showQRShare = false
    @State private var qrPhoto: PhotosPickerItem?
    @State private var sheetPhoto: PhotosPickerItem?
    @State private var batchPhotos: [PhotosPickerItem] = []
    @State private var masterKeyPhoto: PhotosPickerItem?
    @State private var batchProgress: String?
    @State private var exportBusy = false
    @State private var pending: PendingScan?
    @State private var message: String?
    @State private var exportURL: URL?
    @State private var pdfExportURL: URL?
    @State private var templateURL: URL?
    @State private var csvURL: URL?
    @State private var showPrint = false

    var body: some View {
        List {
            Section {
                Button { showScanner = true } label: {
                    Label("Chấm bằng camera", systemImage: "camera.viewfinder").font(.headline)
                }
                .disabled(exam.keys.isEmpty)
                PhotosPicker(selection: $sheetPhoto, matching: .images) {
                    Label("Chấm 1 ảnh đã chụp", systemImage: "photo")
                }
                PhotosPicker(selection: $batchPhotos, maxSelectionCount: 50, matching: .images) {
                    Label(batchProgress ?? "Chấm hàng loạt nhiều ảnh (tối đa 50)", systemImage: "photo.on.rectangle.angled")
                }
                .disabled(exam.keys.isEmpty || batchProgress != nil)
                if exam.keys.isEmpty {
                    Text("Nhập đáp án ít nhất một mã đề trước khi chấm.").font(.footnote).foregroundStyle(.orange)
                }
            } footer: {
                Text("Mẫu phiếu: \(exam.config.sheet.title)")
            }

            Section {
                switch exam.config.sheet {
                case .app:
                    Button { showPrint = true } label: { Label("In phiếu trả lời (PDF)", systemImage: "printer") }
                case .official2025:
                    Button { convertToAppSheet() } label: { Label("Dùng phiếu in từ app thay phiếu của Bộ", systemImage: "printer") }
                case let .spec(id):
                    if id.hasPrefix("tnmaker-") {
                        Link(destination: BuiltinTemplates.tnmakerPage) { Label("Tải phiếu gốc từ TNMaker để in", systemImage: "arrow.down.doc") }
                    } else {
                        Link(destination: BuiltinTemplates.azotaGuide) { Label("In phiếu gốc từ Azota", systemImage: "arrow.down.doc") }
                    }
                }
            } footer: {
                switch exam.config.sheet {
                case .official2025: Text("Phiếu của Bộ dùng bản in sẵn. Chuyển sang phiếu của app để in phiếu có đúng số câu (cả phiếu 1 phần).")
                case .spec: Text("In phiếu gốc đúng khổ A4, tỉ lệ 100%, không co giãn.")
                case .app: EmptyView()
                }
            }

            Section {
                ForEach($exam.keys) { $key in
                    NavigationLink {
                        AnswerKeyEditorView(key: $key, config: exam.config, existingCodes: exam.keys.filter { $0.id != key.id }.map(\.code))
                    } label: {
                        HStack {
                            Text("Mã đề \(key.code)").font(.body.monospacedDigit())
                            Spacer()
                            if !key.isComplete {
                                Text("Chưa đủ").font(.caption).foregroundStyle(.orange)
                            }
                        }
                    }
                }
                .onDelete { exam.keys.remove(atOffsets: $0) }
                Menu {
                    Button { newKey = AnswerKey.empty(code: "", config: exam.config) } label: { Label("Nhập tay", systemImage: "hand.tap") }
                    Button { showPaste = true } label: { Label("Dán từ Excel", systemImage: "doc.on.clipboard") }
                    Button { showFileImporter = true } label: { Label("Mở file Excel (.xlsx) / CSV", systemImage: "tablecells") }
                    Button { showQRScan = true } label: { Label("Quét mã QR đáp án", systemImage: "qrcode.viewfinder") }
                    PhotosPicker(selection: $qrPhoto, matching: .images) { Label("Chọn ảnh mã QR", systemImage: "qrcode") }
                    PhotosPicker(selection: $masterKeyPhoto, matching: .images) { Label("Quét ảnh phiếu đáp án chuẩn", systemImage: "doc.text.viewfinder") }
                } label: {
                    Label("Thêm đáp án", systemImage: "plus.circle")
                }
            } header: {
                Text("Đáp án (\(exam.keys.count) mã đề)")
            } footer: {
                HStack(spacing: 16) {
                    if !exam.keys.isEmpty {
                        Button("Chia sẻ đáp án bằng QR") { showQRShare = true }
                    }
                    if let templateURL {
                        ShareLink("File đáp án Excel mẫu", item: templateURL)
                    }
                }
                .font(.footnote)
            }

            Section("Kết quả") {
                NavigationLink {
                    ResultListView(exam: $exam)
                } label: {
                    HStack {
                        Label("Bảng điểm", systemImage: "list.number")
                        Spacer()
                        Text("\(exam.records.count) bài").foregroundStyle(.secondary)
                    }
                }
                if !exam.records.isEmpty {
                    NavigationLink {
                        AnalyticsView(exam: exam)
                    } label: {
                        Label("Thống kê & Phân tích đề", systemImage: "chart.bar.xaxis")
                    }
                    StatsRow(exam: exam)
                    if let exportURL {
                        ShareLink(item: exportURL) { Label("Chia sẻ Excel 3 sheet (.xlsx)", systemImage: "tablecells") }
                    } else {
                        Button { prepareExport(.xlsx) } label: { Label("Tạo & xuất Excel 3 sheet (.xlsx)", systemImage: "tablecells") }
                            .disabled(exportBusy)
                    }
                    if let pdfExportURL {
                        ShareLink(item: pdfExportURL) { Label("Chia sẻ PDF ảnh bài chấm cả lớp", systemImage: "doc.richtext") }
                    } else {
                        Button { prepareExport(.pdf) } label: { Label("Tạo & xuất PDF ảnh bài chấm cả lớp", systemImage: "doc.richtext") }
                            .disabled(exportBusy)
                    }
                    if let csvURL {
                        ShareLink(item: csvURL) { Label("Chia sẻ CSV", systemImage: "square.and.arrow.up") }
                    } else {
                        Button { prepareExport(.csv) } label: { Label("Tạo & xuất CSV", systemImage: "square.and.arrow.up") }
                            .disabled(exportBusy)
                    }
                }
            }

            Section("Cấu hình") {
                LabeledContent("Môn", value: exam.config.subject.title)
                LabeledContent("Số câu", value: "\(exam.config.p1Count) – \(exam.config.p2Count) – \(exam.config.p3Count)")
                LabeledContent("Điểm tối đa", value: Grader.format(exam.config.scaleTo10 ? 10 : exam.config.maxScore))
                if let c = store.classRoom(exam.classId) { LabeledContent("Lớp", value: c.name) }
            }
        }
        .navigationTitle(exam.name)
        .toolbar {
            ToolbarItem(placement: .primaryAction) { Button("Sửa") { showEdit = true } }
        }
        .onAppear(perform: refreshFiles)
        .onChange(of: exam) { _, _ in refreshFiles() }
        .sheet(isPresented: $showEdit) {
            NavigationStack { ExamEditorView(exam: exam, isNew: false) { exam = $0 } }
        }
        .sheet(item: $newKey) { key in
            NavigationStack {
                NewKeyView(key: key, config: exam.config, existingCodes: exam.keys.map(\.code)) { k in
                    exam.keys.append(k)
                    exam.keys.sort { $0.code < $1.code }
                }
            }
        }
        .sheet(isPresented: $showPaste) {
            NavigationStack { PasteKeysView(config: exam.config) { addKeys($0) } }
        }
        .sheet(isPresented: $showPrint) {
            NavigationStack { PrintSheetView(exam: exam) }
        }
        .sheet(isPresented: $showQRShare) {
            NavigationStack { QRShareView(exam: exam) }
        }
        .fullScreenCover(isPresented: $showQRScan) {
            QRScanSheet { text in handleQR(text) }
        }
        .fullScreenCover(isPresented: $showScanner, onDismiss: { SyncManager.shared.syncIfAuto(store) }) {
            ScannerView(examID: exam.id)
        }
        .sheet(item: $pending) { p in
            NavigationStack { PendingScanView(examID: exam.id, pending: p) }
        }
        .fileImporter(isPresented: $showFileImporter, allowedContentTypes: UTType.tableFiles) { result in
            guard case let .success(url) = result else { return }
            do { addKeys(try AnswerKeyIO.parseFile(url, config: exam.config)) } catch { message = error.localizedDescription }
        }
        .onChange(of: qrPhoto) { _, item in
            guard let item else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self), let img = UIImage(data: data),
                   let text = AnswerKeyIO.readQR(from: img) {
                    handleQR(text)
                } else { message = "Không tìm thấy mã QR trong ảnh." }
                qrPhoto = nil
            }
        }
        .onChange(of: sheetPhoto) { _, item in
            guard let item else { return }
            Task {
                defer { sheetPhoto = nil }
                guard let data = try? await item.loadTransferable(type: Data.self), let img = UIImage(data: data),
                      let gray = GrayImage(uiImage: img) else { message = "Không mở được ảnh."; return }
                let t = exam.config.template
                let result = await Task.detached(priority: .userInitiated) { () -> PendingScan? in
                    guard let r = OMREngine.read(gray, template: t) else { return nil }
                    let used = r.template(fallback: t)
                    let rect = OMREngine.rectify(gray, sheetToImage: r.sheetToImage, template: used)
                    return PendingScan(reading: r, rectified: rect, sheet: used.kind)
                }.value
                if let result { pending = result } else {
                    message = "Không nhận ra phiếu. Ảnh cần thấy rõ các ô vuông đen định vị của phiếu đã chọn."
                }
            }
        }
        .onChange(of: batchPhotos) { _, items in
            guard !items.isEmpty else { return }
            Task {
                defer { batchPhotos = []; batchProgress = nil }
                let t = exam.config.template
                let saveImg = UserDefaults.standard.object(forKey: SettingKey.saveImages) as? Bool ?? true
                var ok = 0, fail = 0
                for (idx, item) in items.enumerated() {
                    batchProgress = "Đang chấm \(idx + 1)/\(items.count)..."
                    guard let data = try? await item.loadTransferable(type: Data.self),
                          let img = UIImage(data: data),
                          let gray = GrayImage(uiImage: img) else { fail += 1; continue }
                    let readResult = await Task.detached(priority: .userInitiated) { () -> (SheetReading, GrayImage, SheetKind)? in
                        guard let r = OMREngine.read(gray, template: t) else { return nil }
                        let used = r.template(fallback: t)
                        let rect = OMREngine.rectify(gray, sheetToImage: r.sheetToImage, template: used)
                        return (r, rect, used.kind)
                    }.value
                    if let (r, rect, sk) = readResult {
                        let imgName = saveImg ? Files.saveImage(rect) : nil
                        let rec = ScanRecord(sbd: r.sbd, code: r.code, p1: r.p1, p2: r.p2, p3: r.p3,
                                             imageName: imgName, cells: r.cells.filter(\.filled), sheet: sk)
                        store.upsert(record: rec, in: exam.id)
                        ok += 1
                    } else { fail += 1 }
                }
                SyncManager.shared.syncIfAuto(store)
                message = "Chấm hàng loạt xong: thành công \(ok) bài" + (fail > 0 ? ", không nhận ra \(fail) ảnh." : ".")
            }
        }
        .onChange(of: masterKeyPhoto) { _, item in
            guard let item else { return }
            Task {
                defer { masterKeyPhoto = nil }
                guard let data = try? await item.loadTransferable(type: Data.self),
                      let img = UIImage(data: data),
                      let gray = GrayImage(uiImage: img) else { message = "Không mở được ảnh phiếu đáp án."; return }
                let t = exam.config.template
                let reading = await Task.detached(priority: .userInitiated) { OMREngine.read(gray, template: t) }.value
                if let r = reading {
                    let k = AnswerKey(code: r.code.filter(\.isNumber),
                                      p1: r.p1.map { $0 == "*" ? "" : $0 },
                                      p2: r.p2.map { $0.replacingOccurrences(of: "*", with: "_") },
                                      p3: r.p3.map { $0.contains("*") ? "" : $0 }).resized(to: exam.config)
                    newKey = k
                } else {
                    message = "Không nhận ra phiếu đáp án chuẩn. Hãy chụp rõ các ô vuông đen định vị."
                }
            }
        }
        .alert("Thông báo", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    private func convertToAppSheet() {
        var c = exam.config
        c.sheet = .app(p1: c.p1Count, p2: c.p2Count, p3: c.p3Count)
        if let problem = c.sheetProblem { message = problem; return }
        exam.config = c
        showPrint = true
    }

    private enum ExportKind { case xlsx, pdf, csv }

    private func prepareExport(_ kind: ExportKind) {
        exportBusy = true
        let ex = exam
        let cls = store.classRoom(exam.classId)
        Task.detached(priority: .userInitiated) {
            let url: URL?
            switch kind {
            case .xlsx: url = ExportService.xlsx(exam: ex, classRoom: cls)
            case .pdf: url = AnnotatedExport.saveClassPDF(exam: ex, classRoom: cls)
            case .csv: url = ExportService.csv(exam: ex, classRoom: cls)
            }
            await MainActor.run {
                exportBusy = false
                switch kind {
                case .xlsx: exportURL = url
                case .pdf:
                    pdfExportURL = url
                    if url == nil { message = "Chưa có ảnh bài chấm để xuất PDF (kiểm tra Lưu ảnh phiếu trong Cài đặt)." }
                case .csv: csvURL = url
                }
            }
        }
    }

    private func refreshFiles() {
        exportURL = nil; pdfExportURL = nil; csvURL = nil
        let cfg = exam.config, keys = exam.keys, name = exam.name
        Task.detached(priority: .utility) {
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("Dap an - \(ExportService.safeName(name)).xlsx")
            try? AnswerKeyIO.templateXLSX(config: cfg, keys: keys).write(to: url)
            await MainActor.run { templateURL = url }
        }
    }

    private func addKeys(_ keys: [AnswerKey]) {
        var added = 0, replaced = 0
        for k in keys {
            let k = k.resized(to: exam.config)
            if let i = exam.keys.firstIndex(where: { $0.code == k.code }) { exam.keys[i] = k; replaced += 1 }
            else { exam.keys.append(k); added += 1 }
        }
        exam.keys.sort { $0.code < $1.code }
        message = "Đã thêm \(added) mã đề" + (replaced > 0 ? ", cập nhật \(replaced) mã đề." : ".")
    }

    private func handleQR(_ text: String) {
        guard let d = AnswerKeyIO.decodeQR(text) else { message = "Mã QR không phải đáp án của ứng dụng này."; return }
        if d.config.p1Count != exam.config.p1Count || d.config.p2Count != exam.config.p2Count || d.config.p3Count != exam.config.p3Count {
            exam.config = d.config
            exam.keys = exam.keys.map { $0.resized(to: d.config) }
        }
        addKeys(d.keys)
    }
}

struct StatsRow: View {
    let exam: Exam
    var body: some View {
        let scores = exam.records.compactMap { Grader.grade($0, exam: exam)?.score10 }
        let avg = scores.isEmpty ? 0 : scores.reduce(0, +) / Double(scores.count)
        HStack {
            stat("Trung bình", Grader.format(Grader.round2(avg)))
            Divider()
            stat("Cao nhất", Grader.format(scores.max() ?? 0))
            Divider()
            stat("Thấp nhất", Grader.format(scores.min() ?? 0))
            Divider()
            stat("≥ 5 điểm", "\(scores.filter { $0 >= 5 }.count)")
        }
    }
    private func stat(_ t: String, _ v: String) -> some View {
        VStack { Text(v).font(.headline.monospacedDigit()); Text(t).font(.caption2).foregroundStyle(.secondary) }
            .frame(maxWidth: .infinity)
    }
}

/// Thêm một mã đề mới bằng tay.
struct NewKeyView: View {
    @Environment(\.dismiss) var dismiss
    @State var key: AnswerKey
    let config: ExamConfig
    let existingCodes: [String]
    var onSave: (AnswerKey) -> Void

    var body: some View {
        AnswerKeyForm(key: $key, config: config, existingCodes: existingCodes)
            .navigationTitle("Mã đề mới")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Huỷ") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Lưu") { onSave(key); dismiss() }
                        .disabled(key.code.isEmpty || existingCodes.contains(key.code))
                }
            }
    }
}

struct PasteKeysView: View {
    @Environment(\.dismiss) var dismiss
    let config: ExamConfig
    var onImport: ([AnswerKey]) -> Void
    @State private var text = ""
    @State private var error: String?

    var body: some View {
        Form {
            Section {
                TextEditor(text: $text).frame(minHeight: 220).font(.system(.footnote, design: .monospaced))
                Button("Dán từ bộ nhớ tạm") { text = UIPasteboard.general.string ?? "" }
            } footer: {
                Text("""
                Mỗi dòng một mã đề. Cách 1 (copy từ Excel): cột đầu là mã đề, sau đó mỗi câu một ô theo thứ tự Phần I (A/B/C/D), Phần II (ĐSĐS), Phần III (-1,5).
                Cách 2: 0101<Tab>ABCDABCD…<Tab>ĐSĐS ĐSSĐ…<Tab>-1,5|12|…
                """)
            }
            if let error { Text(error).foregroundStyle(.red) }
        }
        .navigationTitle("Dán đáp án")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Huỷ") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("Nhập") {
                    do { onImport(try AnswerKeyIO.parse(text, config: config)); dismiss() }
                    catch { self.error = error.localizedDescription }
                }
            }
        }
    }
}

struct QRShareView: View {
    @Environment(\.dismiss) var dismiss
    let exam: Exam
    var body: some View {
        let s = AnswerKeyIO.qrString(exam: exam)
        let img = s.flatMap { AnswerKeyIO.qrImage($0) }
        VStack(spacing: 16) {
            if let img {
                Image(uiImage: img).interpolation(.none).resizable().scaledToFit().padding()
                Text("\(exam.keys.count) mã đề – \(exam.name)").font(.headline)
                ShareLink(item: Image(uiImage: img), preview: SharePreview("Đáp án \(exam.name)", image: Image(uiImage: img))) {
                    Label("Lưu / gửi ảnh QR", systemImage: "square.and.arrow.up")
                }
                .buttonStyle(.borderedProminent)
                Text("Giáo viên khác mở bài chấm → Thêm đáp án → Quét mã QR (hoặc chọn ảnh QR).")
                    .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center).padding(.horizontal)
            } else {
                ContentUnavailableView("Quá nhiều dữ liệu cho một mã QR", systemImage: "qrcode",
                                       description: Text("Hãy chia sẻ bằng file CSV đáp án."))
            }
        }
        .navigationTitle("Chia sẻ đáp án")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Xong") { dismiss() } } }
    }
}

extension UTType {
    /// Excel .xlsx, CSV, văn bản.
    static var tableFiles: [UTType] {
        var t: [UTType] = [.commaSeparatedText, .tabSeparatedText, .plainText, .spreadsheet]
        if let x = UTType("org.openxmlformats.spreadsheetml.sheet") { t.insert(x, at: 0) }
        if let x = UTType(filenameExtension: "xlsx"), !t.contains(x) { t.insert(x, at: 0) }
        return t
    }
}

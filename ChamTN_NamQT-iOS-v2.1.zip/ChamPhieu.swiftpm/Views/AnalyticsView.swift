import SwiftUI

/// Màn hình Thống kê & Phân tích đề thi: phổ điểm, phân loại, phân tích từng câu hỏi.
struct AnalyticsView: View {
    @EnvironmentObject var store: Store
    let exam: Exam
    @State private var hardestFirst = true

    var body: some View {
        let cls = store.classRoom(exam.classId)
        let a = ExamAnalytics.compute(exam: exam, classRoom: cls)
        let shown = hardestFirst ? a.hardestItems : a.items

        Group {
            if a.gradedCount == 0 {
                ContentUnavailableView("Chưa có dữ liệu thống kê", systemImage: "chart.bar",
                                       description: Text("Chấm ít nhất một bài hợp lệ để xem phổ điểm và phân tích câu hỏi."))
            } else {
                List {
                    Section("Tổng quan (\(a.gradedCount) bài)") {
                        HStack {
                            miniStat("Trung bình", Grader.format(a.avg))
                            Divider()
                            miniStat("Cao nhất", Grader.format(a.max))
                            Divider()
                            miniStat("Thấp nhất", Grader.format(a.min))
                            Divider()
                            miniStat("≥ 5 điểm", "\(a.passCount) (\(a.passCount * 100 / max(1, a.gradedCount))%)")
                        }
                        if let cls {
                            let done = cls.students.count - a.missingStudents.count
                            Text("Lớp \(cls.name): đã chấm \(done)/\(cls.students.count) HS"
                                 + (a.missingStudents.isEmpty ? " · đủ 100%" : " · còn thiếu \(a.missingStudents.count) HS")
                                 + (a.unknownRecords.isEmpty ? "" : " · \(a.unknownRecords.count) SBD ngoài lớp"))
                                .font(.footnote)
                                .foregroundStyle(a.missingStudents.isEmpty && a.unknownRecords.isEmpty ? .green : .orange)
                        }
                    }

                    Section("Phổ điểm (0 – 10)") {
                        let maxBin = max(1, a.histogram.max() ?? 1)
                        HStack(alignment: .bottom, spacing: 4) {
                            ForEach(0..<10, id: \.self) { i in
                                let cnt = a.histogram[i]
                                let h = max(cnt > 0 ? 4 : 1, CGFloat(cnt) / CGFloat(maxBin) * 100)
                                VStack(spacing: 2) {
                                    if cnt > 0 { Text("\(cnt)").font(.caption2.monospacedDigit()) }
                                    RoundedRectangle(cornerRadius: 3)
                                        .fill(i < 5 ? Color.red.opacity(0.8) : Color.blue)
                                        .frame(height: h)
                                    Text(i == 9 ? "9-10" : "\(i)-\(i+1)")
                                        .font(.system(size: 9))
                                        .foregroundStyle(.secondary)
                                }
                                .frame(maxWidth: .infinity)
                            }
                        }
                        .frame(height: 135, alignment: .bottom)
                        .padding(.vertical, 4)
                    }

                    Section("Phân loại học lực") {
                        ForEach(a.tiers) { t in
                            let pct = a.gradedCount == 0 ? 0 : t.count * 100 / a.gradedCount
                            HStack {
                                Text("\(t.label) (\(t.range))").font(.subheadline).frame(width: 150, alignment: .leading)
                                ProgressView(value: Double(t.count), total: Double(max(1, a.gradedCount)))
                                Text("\(t.count) (\(pct)%)").font(.caption.monospacedDigit()).frame(width: 68, alignment: .trailing)
                            }
                        }
                    }

                    Section {
                        Picker("Sắp xếp", selection: $hardestFirst) {
                            Text("Sai nhiều nhất trước").tag(true)
                            Text("Theo thứ tự câu").tag(false)
                        }
                        .pickerStyle(.segmented)
                        ForEach(shown) { st in
                            let pct = Int((st.correctRate * 100).rounded())
                            let distStr = st.distribution.keys.sorted().map { "\($0):\(st.distribution[$0] ?? 0)" }.joined(separator: "  ")
                            VStack(alignment: .leading, spacing: 3) {
                                HStack {
                                    Text("Câu \(st.label)").font(.subheadline.bold())
                                    Spacer()
                                    Text("Đúng \(pct)% (\(st.correct)/\(st.total))")
                                        .font(.subheadline.monospacedDigit())
                                        .foregroundStyle(pct < 50 ? .red : .green)
                                }
                                Text("Sai: \(st.wrong) · Trống: \(st.blank)" + (distStr.isEmpty ? "" : " · \(distStr)"))
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    } header: {
                        Text("Phân tích từng câu")
                    }
                }
            }
        }
        .navigationTitle("Thống kê & Phân tích")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func miniStat(_ title: String, _ value: String) -> some View {
        VStack(spacing: 2) {
            Text(value).font(.headline.monospacedDigit())
            Text(title).font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}

import SwiftUI

private struct Row: Identifiable {
    let rec: ScanRecord
    let g: GradeResult?
    var id: UUID { rec.id }
}

struct ResultListView: View {
    @EnvironmentObject var store: Store
    @Binding var exam: Exam
    @State private var sortByScore = false
    @State private var onlyIssues = false
    @State private var tab = 0 // 0: Đã chấm, 1: Chưa chấm
    @State private var search = ""

    var body: some View {
        let classRoom = store.classRoom(exam.classId)
        let analytics = ExamAnalytics.compute(exam: exam, classRoom: classRoom)
        let rows: [Row] = exam.records.map { Row(rec: $0, g: Grader.grade($0, exam: exam)) }
        let filtered = rows.filter { r in
            let matchSearch = search.isEmpty || r.rec.sbd.contains(search) || (classRoom?.student(sbd: r.rec.sbd)?.name.localizedCaseInsensitiveContains(search) ?? false)
            let isIssue = r.g == nil || (r.g?.invalid ?? 0) > 0 || r.rec.sbd.isEmpty || r.rec.sbd.contains("?") || (classRoom != nil && classRoom?.student(sbd: r.rec.sbd) == nil)
            return matchSearch && (!onlyIssues || isIssue)
        }
        let sorted = filtered.sorted { a, b in
            sortByScore ? (a.g?.score10 ?? -1) > (b.g?.score10 ?? -1) : a.rec.sbd < b.rec.sbd
        }
        List {
            if classRoom != nil {
                Picker("Chế độ xem", selection: $tab) {
                    Text("Đã chấm (\(exam.records.count))").tag(0)
                    Text("Chưa chấm (\(analytics.missingStudents.count))").tag(1)
                }
                .pickerStyle(.segmented)
            }
            if tab == 0 {
                ForEach(sorted) { row in
                    let rec = row.rec, g = row.g
                    let student = classRoom?.student(sbd: rec.sbd)
                    NavigationLink {
                        ResultDetailView(exam: $exam, recordID: rec.id)
                    } label: {
                        HStack {
                            VStack(alignment: .leading) {
                                Text(student?.name ?? "SBD \(rec.sbd.isEmpty ? "(trống)" : rec.sbd)")
                                    .font(.body)
                                HStack(spacing: 8) {
                                    if student != nil { Text("SBD \(rec.sbd)") }
                                    else if classRoom != nil { Text("Ngoài lớp").foregroundStyle(.orange) }
                                    Text("Mã đề \(rec.code)")
                                    if let g, g.invalid > 0 { Text("\(g.invalid) phạm quy").foregroundStyle(.orange) }
                                    if exam.config.essayMax > 0, let es = rec.essayScore { Text("TL \(Grader.format(es))") }
                                    if rec.edited { Image(systemName: "pencil") }
                                }
                                .font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            if let g {
                                Text(Grader.format(g.score10)).font(.title3.bold().monospacedDigit())
                                    .foregroundStyle(g.score10 >= 5 ? Color.primary : Color.red)
                            } else {
                                Text("—").foregroundStyle(.red)
                            }
                        }
                    }
                }
                .onDelete { idx in
                    for i in idx { store.deleteRecord(sorted[i].rec.id, in: exam.id) }
                }
            } else {
                let missing = analytics.missingStudents.filter {
                    search.isEmpty || $0.sbd.contains(search) || $0.name.localizedCaseInsensitiveContains(search)
                }
                if missing.isEmpty {
                    Text("Tất cả học sinh trong lớp đã được chấm.").foregroundStyle(.secondary)
                } else {
                    ForEach(missing) { st in
                        HStack {
                            Text(st.sbd).font(.body.monospacedDigit()).frame(width: 90, alignment: .leading)
                            Text(st.name)
                        }
                    }
                }
            }
        }
        .searchable(text: $search, prompt: "SBD hoặc tên")
        .overlay {
            if tab == 0 && exam.records.isEmpty {
                ContentUnavailableView("Chưa có bài nào", systemImage: "tray", description: Text("Bấm “Chấm bằng camera” để bắt đầu."))
            }
        }
        .navigationTitle("Bảng điểm")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Menu {
                    Picker("Sắp xếp", selection: $sortByScore) {
                        Text("Theo SBD").tag(false)
                        Text("Theo điểm").tag(true)
                    }
                    Toggle("Chỉ hiện bài lỗi / phạm quy", isOn: $onlyIssues)
                } label: { Image(systemName: "line.3.horizontal.decrease.circle") }
            }
        }
    }
}

struct ResultDetailView: View {
    @EnvironmentObject var store: Store
    @Binding var exam: Exam
    let recordID: UUID
    @State private var editing = false

    var body: some View {
        if let idx = exam.records.firstIndex(where: { $0.id == recordID }) {
            let rec = exam.records[idx]
            let g = Grader.grade(rec, exam: exam)
            Form {
                if let img = Files.loadImage(rec.imageName) {
                    Section {
                        NavigationLink {
                            ZoomableSheet(image: img, cells: rec.cells, status: g, exam: exam, sheet: rec.sheet ?? exam.config.sheet)
                        } label: {
                            SheetOverlayImage(image: img, cells: rec.cells, status: g, exam: exam, sheet: rec.sheet ?? exam.config.sheet).frame(maxHeight: 320)
                        }
                        if let shareURL = AnnotatedExport.saveSingleJPEG(record: rec, exam: exam, classRoom: store.classRoom(exam.classId)) {
                            ShareLink(item: shareURL) { Label("Chia sẻ ảnh bài chấm (có điểm & khoanh)", systemImage: "square.and.arrow.up") }
                        }
                    } footer: { Text("Xanh: tô đúng · Đỏ: tô sai · Cam: phạm quy. Chạm để phóng to.") }
                }
                Section("Thông tin") {
                    if let n = store.classRoom(exam.classId)?.student(sbd: rec.sbd)?.name { LabeledContent("Họ tên", value: n) }
                    LabeledContent("Số báo danh", value: rec.sbd.isEmpty ? "(trống)" : rec.sbd)
                    LabeledContent("Mã đề", value: rec.code.isEmpty ? "(trống)" : rec.code)
                    LabeledContent("Thời gian", value: rec.createdAt.formatted(date: .abbreviated, time: .shortened))
                    if rec.edited { Text("Bài đã được sửa tay.").font(.footnote).foregroundStyle(.orange) }
                }
                if let g {
                    Section("Điểm") { ScoreSummary(g: g) }
                    ReadOnlyAnswers(rec: rec, exam: exam, g: g)
                } else {
                    Section { Text("Chưa có đáp án cho mã đề \(rec.code). Thêm đáp án hoặc sửa mã đề.").foregroundStyle(.red) }
                }
            }
            .navigationTitle("SBD \(rec.sbd)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .primaryAction) { Button("Sửa") { editing = true } } }
            .sheet(isPresented: $editing) {
                NavigationStack { RecordEditView(record: rec, config: exam.config) { exam.records[idx] = $0 } }
            }
        } else {
            ContentUnavailableView("Bài đã bị xoá", systemImage: "trash")
        }
    }
}

struct ScoreSummary: View {
    let g: GradeResult
    var body: some View {
        LabeledContent("Tổng điểm") { Text(Grader.format(g.score10)).font(.title2.bold()) }
        if g.essayScore > 0 {
            LabeledContent("Trắc nghiệm / Tự luận", value: "\(Grader.format(g.mcqScore)) + \(Grader.format(g.essayScore)) điểm")
        }
        LabeledContent("Phần I", value: "\(g.p1Correct) câu đúng · \(Grader.format(g.p1Score)) điểm")
        LabeledContent("Phần II", value: "\(g.p2Items) ý đúng · \(Grader.format(g.p2Score)) điểm")
        LabeledContent("Phần III", value: "\(g.p3Correct) câu đúng · \(Grader.format(g.p3Score)) điểm")
        if g.invalid > 0 { LabeledContent("Phạm quy (tô nhiều ô)", value: "\(g.invalid)").foregroundStyle(.orange) }
    }
}

/// Bảng đáp án học sinh tô so với đáp án đúng.
struct ReadOnlyAnswers: View {
    let rec: ScanRecord
    let exam: Exam
    let g: GradeResult
    var body: some View {
        let key = exam.key(for: rec.code)
        Section("Chi tiết") {
            let cols = [GridItem(.adaptive(minimum: 70), spacing: 6)]
            LazyVGrid(columns: cols, alignment: .leading, spacing: 6) {
                ForEach(0..<exam.config.p1Count, id: \.self) { i in
                    cell("\(i + 1)", rec.p1[safe: i] ?? "", key?.p1[safe: i] ?? "", g.p1Status[safe: i] ?? nil)
                }
            }
            if exam.config.p2Count > 0 {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 140), spacing: 6)], alignment: .leading, spacing: 6) {
                    ForEach(0..<exam.config.p2Count, id: \.self) { q in
                        let s = (rec.p2[safe: q] ?? "").replacingOccurrences(of: "D", with: "Đ")
                        let k = (key?.p2[safe: q] ?? "").replacingOccurrences(of: "D", with: "Đ")
                        let n = g.p2Status[safe: q]?.compactMap { $0 }.filter { $0 }.count ?? 0
                        cell("II.\(q + 1)", s, k, n == 4 ? true : (n == 0 ? false : nil), extra: "\(n)/4")
                    }
                }
            }
            if exam.config.p3Count > 0 {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 110), spacing: 6)], alignment: .leading, spacing: 6) {
                    ForEach(0..<exam.config.p3Count, id: \.self) { i in
                        cell("III.\(i + 1)", rec.p3[safe: i] ?? "", key?.p3[safe: i] ?? "", g.p3Status[safe: i] ?? nil)
                    }
                }
            }
        }
    }

    private func cell(_ label: String, _ s: String, _ k: String, _ ok: Bool?, extra: String? = nil) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label).font(.caption2).foregroundStyle(.secondary)
            HStack(spacing: 4) {
                Text(s.isEmpty ? "–" : s).font(.callout.bold().monospacedDigit())
                if ok != true, !k.isEmpty { Text("(\(k))").font(.caption2.monospacedDigit()).foregroundStyle(.secondary) }
                if let extra { Text(extra).font(.caption2) }
            }
        }
        .padding(6)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background((ok == true ? Color.green : (ok == false ? Color.red : Color.gray)).opacity(0.15), in: RoundedRectangle(cornerRadius: 6))
    }
}

/// Sửa bài làm (khi máy đọc nhầm hoặc học sinh tô mờ).
struct RecordEditView: View {
    @Environment(\.dismiss) var dismiss
    @State var record: ScanRecord
    @State private var essayText: String
    @State private var showSheet = true
    let config: ExamConfig
    var onSave: (ScanRecord) -> Void

    init(record: ScanRecord, config: ExamConfig, onSave: @escaping (ScanRecord) -> Void) {
        var r = record
        r.p1 = r.p1.padded(to: config.p1Count, with: "")
        r.p2 = r.p2.padded(to: config.p2Count, with: "____")
        r.p3 = r.p3.padded(to: config.p3Count, with: "")
        _record = State(initialValue: r)
        _essayText = State(initialValue: r.essayScore.map { Grader.format($0) } ?? "")
        self.config = config
        self.onSave = onSave
    }

    var body: some View {
        VStack(spacing: 0) {
            if showSheet, let img = Files.loadImage(record.imageName) {
                SheetOverlayImage(image: img, cells: record.cells, status: nil, exam: nil, sheet: record.sheet ?? config.sheet)
                    .frame(maxHeight: 200)
                    .padding(6)
                    .background(Color(.secondarySystemBackground))
            }
            Form {
                Section("Thông tin") {
                    TextField("Số báo danh", text: $record.sbd).keyboardType(.numberPad)
                    TextField("Mã đề", text: $record.code).keyboardType(.numberPad)
                    if config.essayMax > 0 {
                        HStack {
                            Text("Điểm tự luận (tối đa \(Grader.format(config.essayMax)))")
                            Spacer()
                            TextField("0", text: $essayText)
                                .keyboardType(.decimalPad)
                                .multilineTextAlignment(.trailing)
                                .frame(width: 80)
                        }
                    }
                    if record.imageName != nil {
                        Toggle("Hiện ảnh phiếu đối chiếu", isOn: $showSheet)
                    }
                }
                AnswerSections(p1: $record.p1, p2: $record.p2, p3: $record.p3, config: config, status: nil)
            }
        }
        .navigationTitle("Sửa bài")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Huỷ") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("Lưu") {
                    if config.essayMax > 0 {
                        record.essayScore = Double(essayText.replacingOccurrences(of: ",", with: "."))
                    }
                    record.edited = true; onSave(record); dismiss()
                }
            }
        }
    }
}

/// Ảnh phiếu đã nắn thẳng + chấm màu từng ô.
struct SheetOverlayImage: View {
    let image: UIImage
    let cells: [CellMark]
    let status: GradeResult?
    let exam: Exam?
    var sheet: SheetKind = .official2025

    var body: some View {
        Image(uiImage: image)
            .resizable()
            .scaledToFit()
            .overlay {
                GeometryReader { geo in
                    let sx = geo.size.width / image.size.width
                    let sy = geo.size.height / image.size.height
                    let t = sheet.template
                    let r = max(3, t.bubbleRadius * Double(image.size.width) / Double(t.rectifyRect.width) * sx * 1.25)
                    Canvas { ctx, _ in
                        for c in cells where c.filled {
                            let p = OMREngine.rectifiedPoint(c.x, c.y, template: t, width: Int(image.size.width))
                            let rect = CGRect(x: p.x * sx - r, y: p.y * sy - r, width: 2 * r, height: 2 * r)
                            ctx.stroke(Path(ellipseIn: rect), with: .color(color(for: c)), lineWidth: max(1.5, r / 3))
                        }
                    }
                }
            }
    }

    private func color(for c: CellMark) -> Color {
        guard let status, let exam else { return .blue }
        switch c.part {
        case .sbd, .code: return .blue
        case .p1:
            guard c.question <= exam.config.p1Count else { return .gray }
            let st = status.p1Status[safe: c.question - 1] ?? nil
            return cellsInQuestion(c).count > 1 ? .orange : (st == true ? .green : .red)
        case .p2:
            guard c.question <= exam.config.p2Count else { return .gray }
            let i = c.item / 2
            let both = cells.contains { $0.part == .p2 && $0.question == c.question && $0.item / 2 == i && $0.item != c.item && $0.filled }
            if both { return .orange }
            let st = status.p2Status[safe: c.question - 1]?[safe: i] ?? nil
            return st == true ? .green : .red
        case .p3:
            guard c.question <= exam.config.p3Count else { return .gray }
            let st = status.p3Status[safe: c.question - 1] ?? nil
            return st == true ? .green : .red
        }
    }

    private func cellsInQuestion(_ c: CellMark) -> [CellMark] {
        cells.filter { $0.part == c.part && $0.question == c.question && $0.filled }
    }
}

struct ZoomableSheet: View {
    let image: UIImage
    let cells: [CellMark]
    let status: GradeResult?
    let exam: Exam
    let sheet: SheetKind
    @State private var scale: CGFloat = 1
    @GestureState private var pinch: CGFloat = 1

    var body: some View {
        GeometryReader { geo in
            ScrollView([.horizontal, .vertical]) {
                SheetOverlayImage(image: image, cells: cells, status: status, exam: exam, sheet: sheet)
                    .frame(width: geo.size.width * scale * pinch)
            }
            .gesture(MagnificationGesture()
                .updating($pinch) { v, s, _ in s = v }
                .onEnded { v in scale = min(4, max(1, scale * v)) })
        }
        .navigationTitle("Ảnh phiếu")
        .navigationBarTitleDisplayMode(.inline)
    }
}

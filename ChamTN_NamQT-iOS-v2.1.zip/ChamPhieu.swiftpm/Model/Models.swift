import Foundation

/// Môn thi theo cấu trúc QĐ 764/QĐ-BGDĐT.
enum Subject: String, Codable, CaseIterable, Identifiable {
    case toan, tuNhien, xaHoi, ngoaiNgu, tuyChinh
    var id: String { rawValue }
    var title: String {
        switch self {
        case .toan: return "Toán (12 – 4 – 6)"
        case .tuNhien: return "Lý, Hóa, Sinh, Địa (18 – 4 – 6)"
        case .xaHoi: return "Sử, GDKT-PL, Tin, Công nghệ (24 – 4)"
        case .ngoaiNgu: return "Ngoại ngữ (40 câu)"
        case .tuyChinh: return "Tùy chỉnh"
        }
    }
    var preset: ExamConfig {
        switch self {
        case .toan: return ExamConfig(subject: self, p1Count: 12, p2Count: 4, p3Count: 6, p1Point: 0.25, p3Point: 0.5)
        case .tuNhien: return ExamConfig(subject: self, p1Count: 18, p2Count: 4, p3Count: 6, p1Point: 0.25, p3Point: 0.25)
        case .xaHoi: return ExamConfig(subject: self, p1Count: 24, p2Count: 4, p3Count: 0, p1Point: 0.25, p3Point: 0.25)
        case .ngoaiNgu: return ExamConfig(subject: self, p1Count: 40, p2Count: 0, p3Count: 0, p1Point: 0.25, p3Point: 0.25)
        case .tuyChinh: return ExamConfig(subject: self, p1Count: 40, p2Count: 8, p3Count: 6, p1Point: 0.25, p3Point: 0.25, scaleTo10: true)
        }
    }
}

enum RoundMode: String, Codable, CaseIterable, Identifiable, Hashable {
    case none, r01, r025, r05
    var id: String { rawValue }
    var title: String {
        switch self {
        case .none: return "2 chữ số thập phân (0,01)"
        case .r01: return "Làm tròn 0,1"
        case .r025: return "Làm tròn 0,25"
        case .r05: return "Làm tròn 0,5"
        }
    }
    var step: Double {
        switch self {
        case .none: return 0.01
        case .r01: return 0.1
        case .r025: return 0.25
        case .r05: return 0.5
        }
    }
}

struct ExamConfig: Codable, Hashable {
    var subject: Subject
    var p1Count: Int
    var p2Count: Int
    var p3Count: Int
    var p1Point: Double
    /// Điểm Phần II theo số ý đúng trong một câu: 1, 2, 3, 4 ý.
    var p2Scale: [Double] = [0.1, 0.25, 0.5, 1.0]
    var p3Point: Double
    /// Quy đổi tổng điểm về thang 10.
    var scaleTo10: Bool = false
    /// Mẫu phiếu học sinh làm bài.
    var sheet: SheetKind = .official2025
    /// Điểm tự luận tối đa (0 = không có phần tự luận).
    var essayMaxScore: Double? = nil
    /// Chế độ làm tròn tổng điểm.
    var roundMode: RoundMode? = nil

    var template: SheetTemplate { sheet.template }
    var essayMax: Double { max(0, essayMaxScore ?? 0) }
    var effectiveRoundMode: RoundMode { roundMode ?? .none }
    var p1Choices: Int {
        if case let .spec(id) = sheet, let sp = TemplateRegistry.shared.spec(id) { return sp.p1Choices }
        return 4
    }
    var totalMaxScore: Double { (scaleTo10 ? max(0, 10 - essayMax) : maxScore) + essayMax }

    /// Phiếu in từ app luôn có số câu đúng bằng cấu hình.
    mutating func syncSheet() {
        if case .app = sheet { sheet = .app(p1: p1Count, p2: p2Count, p3: p3Count) }
    }

    /// Lỗi cấu hình (nếu có) so với mẫu phiếu đang chọn.
    var sheetProblem: String? {
        switch sheet {
        case .official2025:
            if p1Count > 40 || p2Count > 8 || p3Count > 6 { return "Phiếu của Bộ chỉ có tối đa 40 – 8 – 6 câu." }
        case .app:
            let lay = AppSheetLayout(p1: p1Count, p2: p2Count, p3: p3Count)
            if !lay.fits { return "Phiếu in từ app không đủ chỗ cho \(p1Count) – \(p2Count) – \(p3Count) câu trên một trang A4 (tối đa \(AppSheetLayout.maxP1) – \(AppSheetLayout.maxP2) – \(AppSheetLayout.maxP3), và tổng chiều cao có hạn)." }
        case let .spec(id):
            guard let sp = TemplateRegistry.shared.spec(id) else { return "Mẫu phiếu này đã bị xoá. Hãy chọn mẫu khác." }
            let c = sp.caps
            if p1Count > c.p1 || p2Count > c.p2 || p3Count > c.p3 {
                return "Mẫu “\(sp.name)” chỉ có tối đa \(c.p1) – \(c.p2) – \(c.p3) câu."
            }
        }
        if p1Count + p2Count + p3Count == 0 { return "Bài chấm cần ít nhất 1 câu." }
        return nil
    }

    var maxScore: Double {
        Double(p1Count) * p1Point + Double(p2Count) * (p2Scale.last ?? 1) + Double(p3Count) * p3Point
    }
}

struct AnswerKey: Codable, Identifiable, Hashable {
    var id = UUID()
    var code: String
    var p1: [String]   // "A"…"D" hoặc ""
    var p2: [String]   // 4 ký tự D/S
    var p3: [String]   // ví dụ "-1,5"

    static func empty(code: String, config: ExamConfig) -> AnswerKey {
        AnswerKey(code: code,
                  p1: Array(repeating: "", count: config.p1Count),
                  p2: Array(repeating: "____", count: config.p2Count),
                  p3: Array(repeating: "", count: config.p3Count))
    }

    func resized(to config: ExamConfig) -> AnswerKey {
        var k = self
        k.p1 = p1.padded(to: config.p1Count, with: "")
        k.p2 = p2.padded(to: config.p2Count, with: "____")
        k.p3 = p3.padded(to: config.p3Count, with: "")
        return k
    }

    var isComplete: Bool {
        !p1.contains("") && !p2.contains { $0.contains("_") || $0.count != 4 } && !p3.contains("")
    }
}

struct ScanRecord: Codable, Identifiable, Hashable {
    var id = UUID()
    var createdAt = Date()
    var sbd: String
    var code: String
    var p1: [String]
    var p2: [String]
    var p3: [String]
    var imageName: String?
    var cells: [CellMark] = []
    var sheet: SheetKind? = nil
    var edited = false
    var updatedAt = Date()
    /// Điểm phần tự luận do giáo viên nhập (nếu bài thi kết hợp TN + TL).
    var essayScore: Double? = nil
}

struct Exam: Codable, Identifiable, Hashable {
    var id = UUID()
    var name: String
    var createdAt = Date()
    var classId: UUID?
    var config: ExamConfig
    var keys: [AnswerKey] = []
    var records: [ScanRecord] = []
    var updatedAt = Date()

    func key(for code: String) -> AnswerKey? {
        if let k = keys.first(where: { $0.code == code }) { return k }
        if let n = Int(code) { return keys.first { Int($0.code) == n } }
        return nil
    }
}

struct Student: Codable, Identifiable, Hashable {
    var id = UUID()
    var sbd: String
    var name: String
}

struct ClassRoom: Codable, Identifiable, Hashable {
    var id = UUID()
    var name: String
    var students: [Student] = []
    var updatedAt = Date()

    func student(sbd: String) -> Student? {
        if let s = students.first(where: { $0.sbd == sbd }) { return s }
        if let n = Int(sbd) { return students.first { Int($0.sbd) == n } }
        return nil
    }
}

extension Array {
    /// Cắt hoặc thêm phần tử để mảng có đúng `n` phần tử.
    func padded(to n: Int, with value: Element) -> [Element] {
        if count >= n { return Array(prefix(n)) }
        return self + Array(repeating: value, count: n - count)
    }
}

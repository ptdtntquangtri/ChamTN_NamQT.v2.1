import Foundation
import CoreImage
import CoreImage.CIFilterBuiltins
import UIKit

/// Nhập/xuất đáp án: dán từ Excel, file CSV, mã QR.
enum AnswerKeyIO {
    enum ParseError: LocalizedError {
        case empty, badLine(Int, String)
        var errorDescription: String? {
            switch self {
            case .empty: return "Không có dữ liệu đáp án."
            case let .badLine(n, why): return "Dòng \(n): \(why)"
            }
        }
    }

    /// Chuẩn hoá ký hiệu Đúng/Sai về D/S.
    static func normalizeTF(_ s: String) -> String {
        var out = ""
        for ch in s.uppercased() {
            switch ch {
            case "Đ", "D", "T", "1": out.append("D")
            case "S", "F", "0": out.append("S")
            default: continue
            }
        }
        return out
    }

    /// Mỗi dòng là một mã đề: `mã đề, đáp án…`. Ô cách nhau bằng Tab (dán từ Excel), dấu ; hoặc dấu phẩy ngoài số.
    /// Đáp án có thể ở dạng mỗi câu một ô (A, B, …, ĐSĐS, -1,5…) hoặc gộp: ô 1 = Phần I "ABCD…",
    /// ô 2 = Phần II "ĐSĐS ĐSSĐ …", ô 3 = Phần III "-1,5|12|…".
    static func parse(_ text: String, config: ExamConfig) throws -> [AnswerKey] {
        let lines = text.replacingOccurrences(of: "\r", with: "\n").split(separator: "\n").map(String.init)
        var keys: [AnswerKey] = []
        for (idx, raw) in lines.enumerated() {
            let line = raw.trimmingCharacters(in: .whitespaces)
            if line.isEmpty { continue }
            let sep: Character = line.contains("\t") ? "\t" : (line.contains(";") ? ";" : ",")
            var cells = line.split(separator: sep, omittingEmptySubsequences: false)
                .map { $0.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: "\"", with: "") }
            while cells.last == "" { cells.removeLast() }
            guard let first = cells.first else { continue }
            let codeDigits = first.filter(\.isNumber)
            if codeDigits.isEmpty { continue } // dòng tiêu đề
            let rest = Array(cells.dropFirst())
            var key = AnswerKey.empty(code: codeDigits, config: config)
            let total = config.p1Count + config.p2Count + config.p3Count
            if rest.count >= total && total > 0 {
                for i in 0..<config.p1Count { key.p1[i] = letter(rest[i]) }
                for i in 0..<config.p2Count {
                    let tf = normalizeTF(rest[config.p1Count + i])
                    key.p2[i] = tf.count == 4 ? tf : "____"
                }
                for i in 0..<config.p3Count { key.p3[i] = Grader.normalizeShort(rest[config.p1Count + config.p2Count + i]) }
            } else if !rest.isEmpty {
                let p1s = Array(rest[0].uppercased().filter { "ABCDE".contains($0) })
                for i in 0..<min(config.p1Count, p1s.count) { key.p1[i] = String(p1s[i]) }
                if rest.count > 1 {
                    let tf = Array(normalizeTF(rest[1]))
                    for i in 0..<config.p2Count where (i + 1) * 4 <= tf.count {
                        key.p2[i] = String(tf[(i * 4)..<(i * 4 + 4)])
                    }
                }
                if rest.count > 2 {
                    let parts = rest[2].split(whereSeparator: { $0 == "|" || $0 == " " }).map(String.init)
                    for i in 0..<min(config.p3Count, parts.count) { key.p3[i] = Grader.normalizeShort(parts[i]) }
                }
            } else {
                throw ParseError.badLine(idx + 1, "thiếu đáp án sau mã đề")
            }
            keys.append(key)
        }
        if keys.isEmpty { throw ParseError.empty }
        return keys
    }

    /// Đọc đáp án từ file .xlsx, .csv hoặc .txt.
    static func parseFile(_ url: URL, config: ExamConfig) throws -> [AnswerKey] {
        try parse(textOfTable(url), config: config)
    }

    /// Nội dung bảng (mỗi dòng nối bằng Tab nếu là .xlsx).
    static func textOfTable(_ url: URL) throws -> String {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let data = try Data(contentsOf: url)
        if url.pathExtension.lowercased() == "xlsx" || data.starts(with: [0x50, 0x4B, 0x03, 0x04]) {
            return XLSX.tsv(try XLSX.readFirstSheet(data))
        }
        if let s = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .utf16) {
            return s.hasPrefix("\u{FEFF}") ? String(s.dropFirst()) : s
        }
        throw ParseError.empty
    }

    /// File Excel mẫu theo cấu hình bài chấm (mỗi câu một cột), kèm các mã đề đã có.
    static func templateXLSX(config: ExamConfig, keys: [AnswerKey]) -> Data {
        var header = ["Mã đề"]
        header += (0..<config.p1Count).map { "I.\($0 + 1)" }
        header += (0..<config.p2Count).map { "II.\($0 + 1)" }
        header += (0..<config.p3Count).map { "III.\($0 + 1)" }
        var rows: [[XLSX.Cell]] = [header.map { .text($0) }]
        for k in keys {
            var r: [XLSX.Cell] = [.text(k.code)]
            r += k.p1.map { .text($0) }
            r += k.p2.map { .text($0.replacingOccurrences(of: "D", with: "Đ")) }
            r += k.p3.map { .text($0) }
            rows.append(r)
        }
        if keys.isEmpty { rows.append([.text("0101")]) }
        return XLSX.write(sheetName: "Dap an", rows: rows, columnWidths: [8] + Array(repeating: 6, count: header.count - 1))
    }

    private static func letter(_ s: String) -> String {
        let u = s.uppercased().filter { "ABCDE".contains($0) }
        return u.count == 1 ? u : ""
    }

    /// File CSV mẫu theo cấu hình bài chấm (mỗi câu một cột).
    static func templateCSV(config: ExamConfig, keys: [AnswerKey]) -> String {
        var header = ["Mã đề"]
        header += (0..<config.p1Count).map { "I.\($0 + 1)" }
        header += (0..<config.p2Count).map { "II.\($0 + 1)" }
        header += (0..<config.p3Count).map { "III.\($0 + 1)" }
        var rows = [header.joined(separator: ";")]
        for k in keys {
            var r = [k.code] + k.p1
            r += k.p2.map { $0.replacingOccurrences(of: "D", with: "Đ") }
            r += k.p3
            rows.append(r.joined(separator: ";"))
        }
        if keys.isEmpty { rows.append("0101" + String(repeating: ";", count: header.count - 1)) }
        return "\u{FEFF}" + rows.joined(separator: "\n")
    }

    // MARK: QR

    struct QRPayload: Codable {
        var v = 1
        var n: String
        var c: ExamConfig
        var k: [[String]] // [mã đề, phần I, phần II, phần III]
    }

    static let qrPrefix = "CP25:"

    static func qrString(exam: Exam) -> String? {
        let payload = QRPayload(n: exam.name, c: exam.config, k: exam.keys.map {
            [$0.code, $0.p1.map { $0.isEmpty ? "_" : $0 }.joined(), $0.p2.joined(), $0.p3.joined(separator: "|")]
        })
        guard let json = try? JSONEncoder().encode(payload),
              let z = try? (json as NSData).compressed(using: .zlib) else { return nil }
        return qrPrefix + (z as Data).base64EncodedString()
    }

    static func decodeQR(_ s: String) -> (name: String, config: ExamConfig, keys: [AnswerKey])? {
        guard s.hasPrefix(qrPrefix), let z = Data(base64Encoded: String(s.dropFirst(qrPrefix.count))),
              let json = try? (z as NSData).decompressed(using: .zlib),
              let p = try? JSONDecoder().decode(QRPayload.self, from: json as Data) else { return nil }
        let keys: [AnswerKey] = p.k.compactMap { row in
            guard row.count == 4 else { return nil }
            var k = AnswerKey.empty(code: row[0], config: p.c)
            let a = Array(row[1])
            for i in 0..<min(a.count, p.c.p1Count) { k.p1[i] = a[i] == "_" ? "" : String(a[i]) }
            let b = Array(row[2])
            for i in 0..<p.c.p2Count where (i + 1) * 4 <= b.count { k.p2[i] = String(b[(i * 4)..<(i * 4 + 4)]) }
            let c = row[3].split(separator: "|", omittingEmptySubsequences: false).map(String.init)
            for i in 0..<min(c.count, p.c.p3Count) { k.p3[i] = c[i] }
            return k
        }
        return (p.n, p.c, keys)
    }

    static func qrImage(_ s: String, size: CGFloat = 900) -> UIImage? {
        let f = CIFilter.qrCodeGenerator()
        f.message = Data(s.utf8)
        f.correctionLevel = "M"
        guard let out = f.outputImage else { return nil }
        let scale = size / out.extent.width
        let scaled = out.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        guard let cg = CIContext().createCGImage(scaled, from: scaled.extent) else { return nil }
        return UIImage(cgImage: cg)
    }

    /// Đọc mã QR từ ảnh trong thư viện.
    static func readQR(from image: UIImage) -> String? {
        guard let ci = CIImage(image: image),
              let det = CIDetector(ofType: CIDetectorTypeQRCode, context: nil, options: [CIDetectorAccuracy: CIDetectorAccuracyHigh]) else { return nil }
        return det.features(in: ci).compactMap { ($0 as? CIQRCodeFeature)?.messageString }.first
    }
}

/// Xuất bảng điểm ra Excel (.xlsx) hoặc CSV.
enum ExportService {
    static func table(exam: Exam, classRoom: ClassRoom?) -> [[XLSX.Cell]] {
        let c = exam.config
        var header = ["STT", "SBD", "Họ và tên", "Mã đề", "Điểm", "Điểm P.I", "Điểm P.II", "Điểm P.III", "Đúng P.I", "Ý đúng P.II", "Đúng P.III", "Phạm quy", "Ghi chú"]
        header += (0..<c.p1Count).map { "I.\($0 + 1)" }
        header += (0..<c.p2Count).map { "II.\($0 + 1)" }
        header += (0..<c.p3Count).map { "III.\($0 + 1)" }
        var rows: [[XLSX.Cell]] = [header.map { .text($0) }]
        let sorted = exam.records.sorted { $0.sbd < $1.sbd }
        for (i, r) in sorted.enumerated() {
            let name = classRoom?.student(sbd: r.sbd)?.name ?? ""
            var row: [XLSX.Cell] = [.number(Double(i + 1)), .text(r.sbd), .text(name), .text(r.code)]
            if let g = Grader.grade(r, exam: exam) {
                row += [.number(g.score10), .number(g.p1Score), .number(Grader.round2(g.p2Score)), .number(g.p3Score),
                        .number(Double(g.p1Correct)), .number(Double(g.p2Items)), .number(Double(g.p3Correct)),
                        .number(Double(g.invalid)), .text(r.edited ? "Đã sửa tay" : "")]
            } else {
                row += Array(repeating: XLSX.Cell.text(""), count: 8) + [.text("Chưa có đáp án mã đề \(r.code)")]
            }
            row += r.p1.padded(to: c.p1Count, with: "").map { .text($0) }
            row += r.p2.padded(to: c.p2Count, with: "").map { .text($0.replacingOccurrences(of: "D", with: "Đ")) }
            row += r.p3.padded(to: c.p3Count, with: "").map { .text($0) }
            rows.append(row)
        }
        return rows
    }

    static func xlsx(exam: Exam, classRoom: ClassRoom?) -> URL? {
        let c = exam.config
        let hasEssay = c.essayMax > 0
        // Sheet 1: Bảng điểm tổng hợp
        var sumHeader = ["STT", "SBD", "Họ và tên", "Mã đề", "Tổng điểm"]
        if hasEssay { sumHeader += ["Điểm TN", "Điểm TL"] }
        sumHeader += ["Phần I", "Phần II", "Phần III", "Đúng P.I", "Ý đúng P.II", "Đúng P.III", "Phạm quy", "Ghi chú"]
        var sumRows: [[XLSX.Cell]] = [sumHeader.map { .text($0) }]
        for (i, r) in exam.records.sorted(by: { $0.sbd < $1.sbd }).enumerated() {
            let name = classRoom?.student(sbd: r.sbd)?.name ?? ""
            var row: [XLSX.Cell] = [.number(Double(i + 1)), .text(r.sbd), .text(name), .text(r.code)]
            if let g = Grader.grade(r, exam: exam) {
                row.append(.number(g.score10))
                if hasEssay { row += [.number(g.mcqScore), .number(g.essayScore)] }
                row += [.number(g.p1Score), .number(Grader.round2(g.p2Score)), .number(g.p3Score),
                        .number(Double(g.p1Correct)), .number(Double(g.p2Items)), .number(Double(g.p3Correct)),
                        .number(Double(g.invalid)), .text(r.edited ? "Đã sửa tay" : "")]
            } else {
                row += Array(repeating: XLSX.Cell.text(""), count: hasEssay ? 10 : 8) + [.text("Chưa có đáp án mã đề \(r.code)")]
            }
            sumRows.append(row)
        }
        var sumWidths: [Double] = [5, 11, 26, 8, 10]
        if hasEssay { sumWidths += [9, 9] }
        sumWidths += [8, 8, 8, 9, 10, 9, 9, 16]

        // Sheet 2: Chi tiết bài làm
        var detWidths: [Double] = [5, 11, 26, 8, 7, 8, 8, 8, 8, 9, 9, 8, 14]
        detWidths += Array(repeating: 5.5, count: c.p1Count + c.p2Count + c.p3Count)

        // Sheet 3: Thống kê câu hỏi
        let a = ExamAnalytics.compute(exam: exam, classRoom: classRoom)
        var statRows: [[XLSX.Cell]] = [["Câu", "Phần", "Số đúng", "Số sai", "Bỏ trống", "Tỷ lệ đúng (%)", "Phân bố chọn"].map { .text($0) }]
        for st in a.items {
            let dist = st.distribution.keys.sorted().map { "\($0):\(st.distribution[$0] ?? 0)" }.joined(separator: " ")
            statRows.append([
                .text(st.label), .text(st.part),
                .number(Double(st.correct)), .number(Double(st.wrong)), .number(Double(st.blank)),
                .number(Grader.round2(st.correctRate * 100)), .text(dist),
            ])
        }
        let statWidths: [Double] = [9, 10, 9, 9, 10, 14, 28]

        let data = XLSX.writeSheets([
            XLSX.Sheet(name: "Bang diem", rows: sumRows, columnWidths: sumWidths),
            XLSX.Sheet(name: "Chi tiet", rows: table(exam: exam, classRoom: classRoom), columnWidths: detWidths),
            XLSX.Sheet(name: "Thong ke cau", rows: statRows, columnWidths: statWidths),
        ])
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Bang diem - \(safeName(exam.name)).xlsx")
        do { try data.write(to: url); return url } catch { return nil }
    }

    static func csv(exam: Exam, classRoom: ClassRoom?) -> URL? {
        let rows = table(exam: exam, classRoom: classRoom).enumerated().map { ri, row in
            row.enumerated().map { ci, cell -> String in
                switch cell {
                case let .number(v): return v == v.rounded() ? String(Int(v)) : String(v)
                case let .text(s): return ri > 0 && (ci == 1 || ci == 3) && !s.isEmpty ? "=\"\(s)\"" : s
                }
            }
        }
        let text = "\u{FEFF}" + rows.map { $0.map(escape).joined(separator: ",") }.joined(separator: "\r\n")
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Bang diem - \(safeName(exam.name)).csv")
        do { try text.write(to: url, atomically: true, encoding: .utf8); return url } catch { return nil }
    }

    static func safeName(_ s: String) -> String {
        s.replacingOccurrences(of: "/", with: "-").replacingOccurrences(of: ":", with: "-")
    }

    private static func escape(_ s: String) -> String {
        if s.contains(",") || s.contains("\"") || s.contains("\n") {
            return "\"" + s.replacingOccurrences(of: "\"", with: "\"\"") + "\""
        }
        return s
    }
}

import Foundation
import SwiftUI
import UIKit

/// Toàn bộ dữ liệu cần đồng bộ.
struct SyncSnapshot: Codable {
    var version = 1
    var exams: [Exam]
    var classes: [ClassRoom]
    var deleted: [String: Date] = [:]
    /// Mẫu phiếu tự tạo (có từ bản 1.2; bản cũ không có trường này).
    var templates: [TemplateSpec]? = nil
}

/// Hợp nhất dữ liệu hai máy: bản sửa sau cùng thắng (theo từng bài chấm, từng bài làm, từng lớp);
/// mục đã xoá ở một máy sẽ bị xoá ở máy kia nếu không được sửa sau thời điểm xoá.
enum SyncMerge {
    static func merge(_ a: SyncSnapshot, _ b: SyncSnapshot, now: Date = Date()) -> SyncSnapshot {
        var deleted = a.deleted
        for (k, d) in b.deleted { deleted[k] = max(deleted[k] ?? d, d) }
        // Bỏ dấu xoá cũ hơn 180 ngày
        deleted = deleted.filter { now.timeIntervalSince($0.value) < 180 * 86_400 }

        func isDeleted(_ key: String, _ updated: Date) -> Bool {
            if let d = deleted[key] { return d >= updated }
            return false
        }

        var exams: [Exam] = []
        let bExams = Dictionary(b.exams.map { ($0.id, $0) }, uniquingKeysWith: { x, _ in x })
        var seen = Set<UUID>()
        for ea in a.exams + b.exams where !seen.contains(ea.id) {
            seen.insert(ea.id)
            let x = a.exams.first { $0.id == ea.id }
            let y = bExams[ea.id]
            var winner: Exam
            switch (x, y) {
            case let (x?, y?): winner = x.updatedAt >= y.updatedAt ? x : y
            case let (x?, nil): winner = x
            case let (nil, y?): winner = y
            default: continue
            }
            // Bài làm: hợp theo id, bản mới hơn thắng
            var recs: [UUID: ScanRecord] = [:]
            for r in (x?.records ?? []) + (y?.records ?? []) {
                if let old = recs[r.id], old.updatedAt >= r.updatedAt { continue }
                recs[r.id] = r
            }
            winner.records = recs.values
                .filter { !isDeleted("record:\($0.id)", $0.updatedAt) }
                .sorted { $0.createdAt > $1.createdAt }
            // Một SBD chỉ giữ bài mới nhất
            var bySBD: [String: ScanRecord] = [:]
            var noSBD: [ScanRecord] = []
            for r in winner.records {
                if r.sbd.isEmpty || r.sbd.contains("?") { noSBD.append(r); continue }
                if let o = bySBD[r.sbd], o.updatedAt >= r.updatedAt { continue }
                bySBD[r.sbd] = r
            }
            winner.records = (Array(bySBD.values) + noSBD).sorted { $0.createdAt > $1.createdAt }
            if isDeleted("exam:\(winner.id)", winner.updatedAt) { continue }
            exams.append(winner)
        }
        exams.sort { $0.createdAt > $1.createdAt }

        var classes: [ClassRoom] = []
        var seenC = Set<UUID>()
        for c in a.classes + b.classes where !seenC.contains(c.id) {
            seenC.insert(c.id)
            let x = a.classes.first { $0.id == c.id }, y = b.classes.first { $0.id == c.id }
            var w = c
            if let x, let y { w = x.updatedAt >= y.updatedAt ? x : y }
            if isDeleted("class:\(w.id)", w.updatedAt) { continue }
            classes.append(w)
        }
        classes.sort { $0.name.localizedStandardCompare($1.name) == .orderedAscending }

        var templates: [TemplateSpec] = []
        var seenT = Set<String>()
        let ta = a.templates ?? [], tb = b.templates ?? []
        for t in ta + tb where !seenT.contains(t.id) {
            seenT.insert(t.id)
            let x = ta.first { $0.id == t.id }, y = tb.first { $0.id == t.id }
            var w = t
            if let x, let y { w = (x.updatedAt ?? .distantPast) >= (y.updatedAt ?? .distantPast) ? x : y }
            if isDeleted("template:\(w.id)", w.updatedAt ?? .distantPast) { continue }
            templates.append(w)
        }
        templates.sort { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
        return SyncSnapshot(exams: exams, classes: classes, deleted: deleted, templates: templates)
    }
}

/// Đồng bộ qua một thư mục đám mây do người dùng chọn trong app Tệp
/// (iCloud Drive, Google Drive, OneDrive, Dropbox…). Không cần tài khoản riêng.
@MainActor
final class SyncManager: ObservableObject {
    static let shared = SyncManager()

    @Published var folderName: String?
    @Published var status = "Chưa bật đồng bộ"
    @Published var lastSync: Date?
    @Published var busy = false
    @Published var auto: Bool { didSet { UserDefaults.standard.set(auto, forKey: "syncAuto") } }

    private let bookmarkKey = "syncFolderBookmark"
    private let lastKey = "syncLast"

    private init() {
        auto = UserDefaults.standard.object(forKey: "syncAuto") as? Bool ?? true
        if let url = resolveFolder() { folderName = url.lastPathComponent }
        lastSync = UserDefaults.standard.object(forKey: lastKey) as? Date
        if folderName != nil { status = lastSync == nil ? "Chưa đồng bộ lần nào" : "Sẵn sàng" }
    }

    var isConfigured: Bool { folderName != nil }

    func setFolder(_ url: URL) {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            let data = try url.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil)
            UserDefaults.standard.set(data, forKey: bookmarkKey)
            folderName = url.lastPathComponent
            status = "Đã chọn thư mục"
        } catch {
            status = "Không lưu được quyền truy cập thư mục: \(error.localizedDescription)"
        }
    }

    func disconnect() {
        UserDefaults.standard.removeObject(forKey: bookmarkKey)
        folderName = nil
        status = "Chưa bật đồng bộ"
    }

    private func resolveFolder() -> URL? {
        guard let data = UserDefaults.standard.data(forKey: bookmarkKey) else { return nil }
        var stale = false
        guard let url = try? URL(resolvingBookmarkData: data, options: [], relativeTo: nil, bookmarkDataIsStale: &stale) else { return nil }
        if stale, let fresh = try? url.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil) {
            UserDefaults.standard.set(fresh, forKey: bookmarkKey)
        }
        return url
    }

    func syncIfAuto(_ store: Store) {
        if auto && isConfigured && !busy { sync(store) }
    }

    func sync(_ store: Store) {
        guard let folder = resolveFolder(), !busy else { return }
        busy = true
        status = "Đang đồng bộ…"
        let local = store.snapshot
        let bg = UIApplication.shared.beginBackgroundTask(withName: "sync")
        Task.detached(priority: .utility) {
            let result = SyncManager.runSync(folder: folder, local: local)
            await MainActor.run {
                UIApplication.shared.endBackgroundTask(bg)
                self.busy = false
                switch result {
                case let .success((merged, images)):
                    store.apply(merged)
                    self.lastSync = Date()
                    UserDefaults.standard.set(self.lastSync, forKey: self.lastKey)
                    self.status = "Đã đồng bộ \(merged.exams.count) bài chấm" + (images > 0 ? ", \(images) ảnh" : "")
                case let .failure(err):
                    self.status = "Lỗi: \(err.localizedDescription)"
                }
            }
        }
    }

    struct SyncError: LocalizedError {
        var message: String
        var errorDescription: String? { message }
    }

    /// Chạy ngoài luồng chính: đọc bản trên mây, hợp nhất, ghi lại cả hai phía, chép ảnh còn thiếu.
    nonisolated static func runSync(folder: URL, local: SyncSnapshot) -> Result<(SyncSnapshot, Int), Error> {
        let access = folder.startAccessingSecurityScopedResource()
        defer { if access { folder.stopAccessingSecurityScopedResource() } }
        let fm = FileManager.default
        let root = folder.appendingPathComponent("ChamTN_NamQT", isDirectory: true)
        let remoteImages = root.appendingPathComponent("Images", isDirectory: true)
        let dataURL = root.appendingPathComponent("data.json")
        do {
            try fm.createDirectory(at: remoteImages, withIntermediateDirectories: true)
            try? fm.startDownloadingUbiquitousItem(at: dataURL)

            // Đọc bản trên mây (nếu có)
            var remote: SyncSnapshot?
            var readError: Error?
            if fm.fileExists(atPath: dataURL.path) || fm.fileExists(atPath: root.appendingPathComponent(".data.json.icloud").path) {
                var coordErr: NSError?
                NSFileCoordinator().coordinate(readingItemAt: dataURL, options: [], error: &coordErr) { url in
                    do {
                        let d = try Data(contentsOf: url)
                        remote = try JSONDecoder().decode(SyncSnapshot.self, from: d)
                    } catch { readError = error }
                }
                if let e = coordErr ?? readError { throw SyncError(message: "Không đọc được dữ liệu trên mây (\(e.localizedDescription)).") }
            }
            let merged = remote.map { SyncMerge.merge(local, $0) } ?? local

            // Ghi bản hợp nhất lên mây
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.sortedKeys]
            let out = try encoder.encode(merged)
            var writeErr: NSError?
            var innerWrite: Error?
            NSFileCoordinator().coordinate(writingItemAt: dataURL, options: .forReplacing, error: &writeErr) { url in
                do { try out.write(to: url, options: .atomic) } catch { innerWrite = error }
            }
            if let e = writeErr ?? innerWrite { throw SyncError(message: "Không ghi được lên mây (\(e.localizedDescription)).") }

            // Chép ảnh phiếu hai chiều
            var copied = 0
            let localImages = Files.imagesDir
            let needed = Set(merged.exams.flatMap { $0.records.compactMap(\.imageName) })
            for name in needed {
                let l = localImages.appendingPathComponent(name), r = remoteImages.appendingPathComponent(name)
                let hasL = fm.fileExists(atPath: l.path), hasR = fm.fileExists(atPath: r.path)
                if hasL && !hasR {
                    var e: NSError?
                    NSFileCoordinator().coordinate(writingItemAt: r, options: .forReplacing, error: &e) { url in
                        if (try? fm.copyItem(at: l, to: url)) != nil { copied += 1 }
                    }
                } else if !hasL && hasR {
                    try? fm.startDownloadingUbiquitousItem(at: r)
                    var e: NSError?
                    NSFileCoordinator().coordinate(readingItemAt: r, options: [], error: &e) { url in
                        if (try? fm.copyItem(at: url, to: l)) != nil { copied += 1 }
                    }
                }
            }
            return .success((merged, copied))
        } catch {
            return .failure(error)
        }
    }
}

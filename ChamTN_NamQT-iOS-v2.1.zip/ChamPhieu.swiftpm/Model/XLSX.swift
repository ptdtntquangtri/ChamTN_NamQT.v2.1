import Foundation
import Compression

/// Đọc và ghi file Excel .xlsx không cần thư viện ngoài.
/// .xlsx là file ZIP chứa các tệp XML: đọc bằng bộ giải nén DEFLATE của Apple, ghi bằng ZIP không nén.
enum XLSX {
    enum XLSXError: LocalizedError {
        case notZip, missing(String), corrupt(String)
        var errorDescription: String? {
            switch self {
            case .notZip: return "File không phải định dạng .xlsx."
            case let .missing(n): return "File .xlsx thiếu phần \(n)."
            case let .corrupt(n): return "Không giải nén được \(n)."
            }
        }
    }

    enum Cell {
        case text(String)
        case number(Double)
    }

    // MARK: - Đọc

    /// Trả về các dòng của trang tính đầu tiên (mỗi ô là chuỗi, ô trống là "").
    static func readFirstSheet(_ data: Data) throws -> [[String]] {
        let zip = try ZipReader(data)
        let shared = try zip.file("xl/sharedStrings.xml").map(parseSharedStrings) ?? []
        var sheetPath = "xl/worksheets/sheet1.xml"
        if let wb = try zip.file("xl/workbook.xml"), let rels = try zip.file("xl/_rels/workbook.xml.rels"),
           let rid = firstSheetRelId(wb), let target = relTarget(rels, id: rid) {
            sheetPath = target.hasPrefix("/") ? String(target.dropFirst()) : "xl/" + target
        }
        guard let sheet = try zip.file(sheetPath) ?? zip.firstFile(prefix: "xl/worksheets/sheet") else {
            throw XLSXError.missing("trang tính")
        }
        return parseSheet(sheet, shared: shared)
    }

    /// Các dòng nối bằng Tab (giống khi copy từ Excel).
    static func tsv(_ rows: [[String]]) -> String {
        rows.map { $0.joined(separator: "\t") }.joined(separator: "\n")
    }

    private static func parseSharedStrings(_ d: Data) -> [String] {
        let p = SimpleXML(d)
        var out: [String] = []
        var cur = ""
        var inT = false
        p.onStart = { name, _ in
            if name == "si" { cur = "" }
            if name == "t" { inT = true }
        }
        p.onText = { s in if inT { cur += s } }
        p.onEnd = { name in
            if name == "t" { inT = false }
            if name == "si" { out.append(cur) }
        }
        p.run()
        return out
    }

    private static func parseSheet(_ d: Data, shared: [String]) -> [[String]] {
        let p = SimpleXML(d)
        var rows: [Int: [Int: String]] = [:]
        var rowIndex = 0
        var colIndex = 0
        var type = ""
        var value = ""
        var collecting = false
        var lastRow = 0
        p.onStart = { name, attrs in
            switch name {
            case "row":
                rowIndex = Int(attrs["r"] ?? "") ?? (lastRow + 1)
                lastRow = rowIndex
                colIndex = 0
            case "c":
                type = attrs["t"] ?? ""
                value = ""
                if let r = attrs["r"] { colIndex = columnIndex(r) } else { colIndex += 1 }
            case "v", "t":
                collecting = true
            default: break
            }
        }
        p.onText = { s in if collecting { value += s } }
        p.onEnd = { name in
            switch name {
            case "v", "t": collecting = false
            case "c":
                var s = value
                switch type {
                case "s": s = Int(value).flatMap { shared.indices.contains($0) ? shared[$0] : nil } ?? ""
                case "b": s = value == "1" ? "TRUE" : "FALSE"
                case "inlineStr", "str", "e": break
                default: s = cleanNumber(value)
                }
                rows[rowIndex, default: [:]][colIndex] = s.trimmingCharacters(in: .whitespacesAndNewlines)
            default: break
            }
        }
        p.run()
        guard let maxRow = rows.keys.max() else { return [] }
        var out: [[String]] = []
        for r in 1...maxRow {
            let cols = rows[r] ?? [:]
            let maxCol = cols.keys.max() ?? 0
            out.append(maxCol == 0 ? [] : (1...maxCol).map { cols[$0] ?? "" })
        }
        return out
    }

    /// "AB12" → 28 (đánh số từ 1)
    static func columnIndex(_ ref: String) -> Int {
        var n = 0
        for ch in ref.uppercased() {
            guard let a = ch.asciiValue, a >= 65, a <= 90 else { break }
            n = n * 26 + Int(a - 64)
        }
        return n
    }

    static func columnName(_ index: Int) -> String {
        var n = index, s = ""
        while n > 0 {
            let r = (n - 1) % 26
            s = String(UnicodeScalar(UInt8(65 + r))) + s
            n = (n - 1) / 26
        }
        return s
    }

    /// Bỏ đuôi sai số dấu phẩy động: "2.4500000000000002" → "2.45"
    static func cleanNumber(_ v: String) -> String {
        guard let d = Double(v), v.contains(".") || v.lowercased().contains("e") else { return v }
        if d == d.rounded(), abs(d) < 1e15 { return String(Int64(d)) }
        let f = NumberFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.maximumFractionDigits = 8
        f.minimumFractionDigits = 0
        f.usesGroupingSeparator = false
        return f.string(from: NSNumber(value: d)) ?? v
    }

    private static func firstSheetRelId(_ d: Data) -> String? {
        let p = SimpleXML(d)
        var id: String?
        p.onStart = { name, attrs in
            if name == "sheet", id == nil { id = attrs["r:id"] ?? attrs.first(where: { $0.key.hasSuffix(":id") })?.value }
        }
        p.run()
        return id
    }

    private static func relTarget(_ d: Data, id: String) -> String? {
        let p = SimpleXML(d)
        var target: String?
        p.onStart = { name, attrs in
            if name == "Relationship", attrs["Id"] == id { target = attrs["Target"] }
        }
        p.run()
        return target
    }

    // MARK: - Ghi

    struct Sheet {
        var name: String
        var rows: [[Cell]]
        var columnWidths: [Double] = []
    }

    /// Tạo file .xlsx một trang tính. Dòng đầu được in đậm và cố định khi cuộn.
    static func write(sheetName: String, rows: [[Cell]], columnWidths: [Double] = []) -> Data {
        writeSheets([Sheet(name: sheetName, rows: rows, columnWidths: columnWidths)])
    }

    /// Tạo file .xlsx nhiều trang tính (mỗi trang tự in đậm & cố định dòng tiêu đề).
    static func writeSheets(_ sheets: [Sheet]) -> Data {
        let list = sheets.isEmpty ? [Sheet(name: "Sheet1", rows: [])] : sheets
        var zip = ZipWriter()
        var ctOverrides = ""
        var wbSheets = ""
        var wbRels = ""
        for (idx, s) in list.enumerated() {
            let n = idx + 1
            var sheet = #"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"#
            sheet += #"<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">"#
            sheet += #"<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>"#
            if !s.columnWidths.isEmpty {
                sheet += "<cols>"
                for (i, w) in s.columnWidths.enumerated() {
                    sheet += #"<col min="\#(i + 1)" max="\#(i + 1)" width="\#(w)" customWidth="1"/>"#
                }
                sheet += "</cols>"
            }
            sheet += "<sheetData>"
            for (ri, row) in s.rows.enumerated() {
                let r = ri + 1
                sheet += #"<row r="\#(r)">"#
                for (ci, cell) in row.enumerated() {
                    let ref = columnName(ci + 1) + String(r)
                    let style = ri == 0 ? #" s="1""# : ""
                    switch cell {
                    case let .number(v):
                        if v.isFinite { sheet += #"<c r="\#(ref)"\#(style)><v>\#(v)</v></c>"# }
                    case let .text(str):
                        if str.isEmpty { continue }
                        sheet += #"<c r="\#(ref)" t="inlineStr"\#(style)><is><t xml:space="preserve">\#(escape(str))</t></is></c>"#
                    }
                }
                sheet += "</row>"
            }
            sheet += "</sheetData></worksheet>"
            zip.add("xl/worksheets/sheet\(n).xml", Data(sheet.utf8))
            ctOverrides += #"<Override PartName="/xl/worksheets/sheet\#(n).xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>"#
            wbSheets += #"<sheet name="\#(escape(String(s.name.prefix(31))))" sheetId="\#(n)" r:id="rId\#(n)"/>"#
            wbRels += #"<Relationship Id="rId\#(n)" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet\#(n).xml"/>"#
        }
        let styleRid = list.count + 1
        let contentTypes = #"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>\#(ctOverrides)<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>"#
        let rootRels = #"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"#
        let workbook = #"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>\#(wbSheets)</sheets></workbook>"#
        let wbRelsXml = #"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\#(wbRels)<Relationship Id="rId\#(styleRid)" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"#
        let styles = #"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>"#

        zip.add("[Content_Types].xml", Data(contentTypes.utf8))
        zip.add("_rels/.rels", Data(rootRels.utf8))
        zip.add("xl/workbook.xml", Data(workbook.utf8))
        zip.add("xl/_rels/workbook.xml.rels", Data(wbRelsXml.utf8))
        zip.add("xl/styles.xml", Data(styles.utf8))
        return zip.finish()
    }

    static func escape(_ s: String) -> String {
        var out = ""
        for ch in s.unicodeScalars {
            switch ch {
            case "&": out += "&amp;"
            case "<": out += "&lt;"
            case ">": out += "&gt;"
            case "\"": out += "&quot;"
            default:
                // Ký tự điều khiển không hợp lệ trong XML
                if ch.value < 0x20 && ch != "\t" && ch != "\n" && ch != "\r" { continue }
                out.unicodeScalars.append(ch)
            }
        }
        return out
    }
}

// MARK: - XML đơn giản (bọc XMLParser, bỏ tiền tố namespace của tên thẻ)

final class SimpleXML: NSObject, XMLParserDelegate {
    var onStart: (String, [String: String]) -> Void = { _, _ in }
    var onEnd: (String) -> Void = { _ in }
    var onText: (String) -> Void = { _ in }
    private let parser: XMLParser

    init(_ data: Data) { parser = XMLParser(data: data) }

    func run() {
        parser.delegate = self
        parser.parse()
    }

    private func local(_ n: String) -> String {
        if let i = n.lastIndex(of: ":") { return String(n[n.index(after: i)...]) }
        return n
    }

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes: [String: String] = [:]) {
        onStart(local(elementName), attributes)
    }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        onEnd(local(elementName))
    }
    func parser(_ parser: XMLParser, foundCharacters string: String) { onText(string) }
}

// MARK: - ZIP

struct ZipReader {
    struct Entry { var name: String; var method: Int; var compSize: Int; var size: Int; var offset: Int }
    let bytes: [UInt8]
    var entries: [String: Entry] = [:]
    var order: [String] = []

    init(_ data: Data) throws {
        bytes = [UInt8](data)
        guard bytes.count >= 22 else { throw XLSX.XLSXError.notZip }
        // Tìm End Of Central Directory (0x06054b50) từ cuối file
        var eocd = -1
        var i = bytes.count - 22
        let stop = max(0, bytes.count - 22 - 65_557)
        while i >= stop {
            if u32(i) == 0x0605_4b50 { eocd = i; break }
            i -= 1
        }
        guard eocd >= 0 else { throw XLSX.XLSXError.notZip }
        let count = u16(eocd + 10)
        var p = u32(eocd + 16)
        for _ in 0..<count {
            guard p + 46 <= bytes.count, u32(p) == 0x0201_4b50 else { throw XLSX.XLSXError.notZip }
            let method = u16(p + 10)
            let comp = u32(p + 20), size = u32(p + 24)
            let nlen = u16(p + 28), xlen = u16(p + 30), clen = u16(p + 32)
            let off = u32(p + 42)
            guard p + 46 + nlen <= bytes.count else { throw XLSX.XLSXError.notZip }
            let name = String(decoding: bytes[(p + 46)..<(p + 46 + nlen)], as: UTF8.self)
            entries[name] = Entry(name: name, method: method, compSize: comp, size: size, offset: off)
            order.append(name)
            p += 46 + nlen + xlen + clen
        }
    }

    private func u16(_ o: Int) -> Int { Int(bytes[o]) | Int(bytes[o + 1]) << 8 }
    private func u32(_ o: Int) -> Int { u16(o) | u16(o + 2) << 16 }

    func file(_ name: String) throws -> Data? {
        guard let e = entries[name] else { return nil }
        return try extract(e)
    }

    func firstFile(prefix: String) throws -> Data? {
        guard let n = order.filter({ $0.hasPrefix(prefix) }).sorted().first, let e = entries[n] else { return nil }
        return try extract(e)
    }

    func extract(_ e: Entry) throws -> Data {
        let h = e.offset
        guard h + 30 <= bytes.count, u32(h) == 0x0403_4b50 else { throw XLSX.XLSXError.corrupt(e.name) }
        let start = h + 30 + u16(h + 26) + u16(h + 28)
        guard start + e.compSize <= bytes.count else { throw XLSX.XLSXError.corrupt(e.name) }
        let src = Array(bytes[start..<(start + e.compSize)])
        switch e.method {
        case 0: return Data(src)
        case 8:
            if e.size == 0 { return Data() }
            var dst = [UInt8](repeating: 0, count: e.size)
            let n = dst.withUnsafeMutableBufferPointer { d in
                src.withUnsafeBufferPointer { s in
                    compression_decode_buffer(d.baseAddress!, e.size, s.baseAddress!, src.count, nil, COMPRESSION_ZLIB)
                }
            }
            guard n == e.size else { throw XLSX.XLSXError.corrupt(e.name) }
            return Data(dst)
        default:
            throw XLSX.XLSXError.corrupt(e.name)
        }
    }
}

/// Ghi ZIP không nén (đủ cho .xlsx, Excel/Numbers/Google Sheets đều mở được).
struct ZipWriter {
    private var out = [UInt8]()
    private var central = [UInt8]()
    private var count = 0

    private static let crcTable: [UInt32] = (0..<256).map { i -> UInt32 in
        var c = UInt32(i)
        for _ in 0..<8 { c = (c & 1) != 0 ? (0xEDB8_8320 ^ (c >> 1)) : (c >> 1) }
        return c
    }

    static func crc32(_ data: [UInt8]) -> UInt32 {
        var c: UInt32 = 0xFFFF_FFFF
        for b in data { c = crcTable[Int((c ^ UInt32(b)) & 0xFF)] ^ (c >> 8) }
        return c ^ 0xFFFF_FFFF
    }

    private static func le16(_ v: Int) -> [UInt8] { [UInt8(v & 0xFF), UInt8((v >> 8) & 0xFF)] }
    private static func le32(_ v: UInt32) -> [UInt8] { [UInt8(v & 0xFF), UInt8((v >> 8) & 0xFF), UInt8((v >> 16) & 0xFF), UInt8((v >> 24) & 0xFF)] }

    mutating func add(_ name: String, _ data: Data) {
        let bytes = [UInt8](data)
        let nameBytes = [UInt8](name.utf8)
        let crc = ZipWriter.crc32(bytes)
        let offset = UInt32(out.count)
        let size = UInt32(bytes.count)
        // DOS time 00:00, date 2025-01-01
        let time = 0, date = ((2025 - 1980) << 9) | (1 << 5) | 1
        var local = ZipWriter.le32(0x0403_4b50)
        local += ZipWriter.le16(20) + ZipWriter.le16(0x0800) + ZipWriter.le16(0)
        local += ZipWriter.le16(time) + ZipWriter.le16(date)
        local += ZipWriter.le32(crc) + ZipWriter.le32(size) + ZipWriter.le32(size)
        local += ZipWriter.le16(nameBytes.count) + ZipWriter.le16(0)
        out += local + nameBytes + bytes

        var c = ZipWriter.le32(0x0201_4b50)
        c += ZipWriter.le16(20) + ZipWriter.le16(20) + ZipWriter.le16(0x0800) + ZipWriter.le16(0)
        c += ZipWriter.le16(time) + ZipWriter.le16(date)
        c += ZipWriter.le32(crc) + ZipWriter.le32(size) + ZipWriter.le32(size)
        c += ZipWriter.le16(nameBytes.count) + ZipWriter.le16(0) + ZipWriter.le16(0)
        c += ZipWriter.le16(0) + ZipWriter.le16(0) + ZipWriter.le32(0)
        c += ZipWriter.le32(offset)
        central += c + nameBytes
        count += 1
    }

    func finish() -> Data {
        var end = ZipWriter.le32(0x0605_4b50)
        end += ZipWriter.le16(0) + ZipWriter.le16(0)
        end += ZipWriter.le16(count) + ZipWriter.le16(count)
        end += ZipWriter.le32(UInt32(central.count)) + ZipWriter.le32(UInt32(out.count))
        end += ZipWriter.le16(0)
        return Data(out + central + end)
    }
}

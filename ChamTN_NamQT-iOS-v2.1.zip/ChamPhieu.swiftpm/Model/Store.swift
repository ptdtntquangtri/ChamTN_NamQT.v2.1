import Foundation
import SwiftUI
import UIKit

/// Lưu toàn bộ dữ liệu trên máy (JSON trong thư mục Documents). Không cần tài khoản, không gửi dữ liệu đi đâu.
@MainActor
final class Store: ObservableObject {
    @Published var exams: [Exam] = [] { didSet { if !suppressStamp { stampExams(old: oldValue) }; scheduleSave() } }
    @Published var classes: [ClassRoom] = [] { didSet { if !suppressStamp { stampClasses(old: oldValue) }; scheduleSave() } }
    /// Mẫu phiếu tự tạo (Azota, phiếu của trường…).
    @Published var templates: [TemplateSpec] = [] {
        didSet {
            if !suppressStamp {
                let now = Date()
                let ids = Set(templates.map(\.id))
                for t in oldValue where !ids.contains(t.id) { deleted["template:\(t.id)"] = now }
            }
            TemplateRegistry.shared.setCustom(templates)
            scheduleSave()
        }
    }
    /// Dấu xoá để đồng bộ: "exam:<id>", "record:<id>", "class:<id>" → thời điểm xoá.
    private(set) var deleted: [String: Date] = [:]

    private var saveTask: Task<Void, Never>?
    private var loading = false
    private var suppressStamp = false

    private var dataURL: URL { Files.documents.appendingPathComponent("data.json") }

    init() { load() }

    func load() {
        loading = true
        defer { loading = false }
        guard let data = try? Data(contentsOf: dataURL),
              let snap = try? JSONDecoder().decode(SyncSnapshot.self, from: data) else { return }
        suppressStamp = true
        templates = snap.templates ?? []
        exams = snap.exams
        classes = snap.classes
        deleted = snap.deleted
        suppressStamp = false
    }

    var snapshot: SyncSnapshot { SyncSnapshot(exams: exams, classes: classes, deleted: deleted, templates: templates) }

    func saveTemplate(_ t: TemplateSpec) {
        var t = t
        t.updatedAt = Date()
        if let i = templates.firstIndex(where: { $0.id == t.id }) { templates[i] = t } else { templates.append(t) }
    }

    /// Áp dữ liệu đã hợp nhất từ đồng bộ (giữ nguyên dấu thời gian).
    func apply(_ snap: SyncSnapshot) {
        suppressStamp = true
        templates = snap.templates ?? []
        exams = snap.exams
        classes = snap.classes
        deleted = snap.deleted
        suppressStamp = false
        saveNow()
    }

    // MARK: Dấu thời gian sửa đổi (phục vụ đồng bộ)

    private func stampExams(old: [Exam]) {
        let now = Date()
        let oldByID = Dictionary(old.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
        var list = exams
        var changed = false
        for i in list.indices {
            guard let o = oldByID[list[i].id], o != list[i] else { continue }
            let oldRecs = Dictionary(o.records.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
            for j in list[i].records.indices {
                if let r = oldRecs[list[i].records[j].id], r != list[i].records[j] { list[i].records[j].updatedAt = now }
            }
            let ids = Set(list[i].records.map(\.id))
            for r in o.records where !ids.contains(r.id) { deleted["record:\(r.id)"] = now }
            list[i].updatedAt = now
            changed = true
        }
        let ids = Set(list.map(\.id))
        for e in old where !ids.contains(e.id) {
            deleted["exam:\(e.id)"] = now
            for r in e.records { deleted["record:\(r.id)"] = now }
        }
        if changed {
            suppressStamp = true
            exams = list
            suppressStamp = false
        }
    }

    private func stampClasses(old: [ClassRoom]) {
        let now = Date()
        let oldByID = Dictionary(old.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
        var list = classes
        var changed = false
        for i in list.indices {
            if let o = oldByID[list[i].id], o != list[i] { list[i].updatedAt = now; changed = true }
        }
        let ids = Set(list.map(\.id))
        for c in old where !ids.contains(c.id) { deleted["class:\(c.id)"] = now }
        if changed {
            suppressStamp = true
            classes = list
            suppressStamp = false
        }
    }

    private func scheduleSave() {
        guard !loading else { return }
        saveTask?.cancel()
        saveTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 400_000_000)
            guard !Task.isCancelled else { return }
            self?.saveNow()
        }
    }

    func saveNow() {
        let snap = snapshot
        if let data = try? JSONEncoder().encode(snap) {
            try? data.write(to: dataURL, options: .atomic)
        }
    }

    // MARK: Bindings

    func examBinding(_ id: UUID) -> Binding<Exam>? {
        guard exams.contains(where: { $0.id == id }) else { return nil }
        return Binding(
            get: { self.exams.first(where: { $0.id == id }) ?? Exam(name: "", config: Subject.toan.preset) },
            set: { new in if let i = self.exams.firstIndex(where: { $0.id == id }) { self.exams[i] = new } }
        )
    }

    func classBinding(_ id: UUID) -> Binding<ClassRoom>? {
        guard classes.contains(where: { $0.id == id }) else { return nil }
        return Binding(
            get: { self.classes.first(where: { $0.id == id }) ?? ClassRoom(name: "") },
            set: { new in if let i = self.classes.firstIndex(where: { $0.id == id }) { self.classes[i] = new } }
        )
    }

    func classRoom(_ id: UUID?) -> ClassRoom? {
        guard let id else { return nil }
        return classes.first { $0.id == id }
    }

    // MARK: Exams

    func duplicate(_ exam: Exam, name: String, classId: UUID?) {
        var e = exam
        e.id = UUID(); e.name = name; e.classId = classId; e.records = []; e.createdAt = Date()
        e.keys = exam.keys.map { var k = $0; k.id = UUID(); return k }
        exams.insert(e, at: 0)
    }

    func delete(examIDs: [UUID]) {
        for e in exams where examIDs.contains(e.id) {
            for r in e.records { deleteImage(r.imageName) }
        }
        exams.removeAll { examIDs.contains($0.id) }
    }

    /// Thêm hoặc thay bài cùng SBD. Trả về true nếu là thay thế.
    @discardableResult
    func upsert(record: ScanRecord, in examID: UUID) -> Bool {
        guard let i = exams.firstIndex(where: { $0.id == examID }) else { return false }
        if !record.sbd.isEmpty, !record.sbd.contains("?"),
           let j = exams[i].records.firstIndex(where: { $0.sbd == record.sbd }) {
            deleteImage(exams[i].records[j].imageName)
            exams[i].records[j] = record
            return true
        }
        exams[i].records.insert(record, at: 0)
        return false
    }

    func deleteRecord(_ id: UUID, in examID: UUID) {
        guard let i = exams.firstIndex(where: { $0.id == examID }) else { return }
        if let r = exams[i].records.first(where: { $0.id == id }) { deleteImage(r.imageName) }
        exams[i].records.removeAll { $0.id == id }
    }

    func deleteImage(_ name: String?) { Files.deleteImage(name) }
}

/// Tệp ảnh phiếu đã chấm.
enum Files {
    static var documents: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0] }
    static var imagesDir: URL {
        let u = documents.appendingPathComponent("Images", isDirectory: true)
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }

    static func saveImage(_ img: GrayImage) -> String? {
        guard let cg = img.cgImage(), let data = UIImage(cgImage: cg).jpegData(compressionQuality: 0.6) else { return nil }
        let name = UUID().uuidString + ".jpg"
        do { try data.write(to: imagesDir.appendingPathComponent(name)); return name } catch { return nil }
    }

    static func loadImage(_ name: String?) -> UIImage? {
        guard let name else { return nil }
        return UIImage(contentsOfFile: imagesDir.appendingPathComponent(name).path)
    }

    static func deleteImage(_ name: String?) {
        guard let name else { return }
        try? FileManager.default.removeItem(at: imagesDir.appendingPathComponent(name))
    }
}

/// Khoá cài đặt (dùng với @AppStorage).
enum SettingKey {
    static let autoMode = "autoMode"        // tự chấm phiếu tiếp theo
    static let stableFrames = "stableFrames" // số khung hình giống nhau liên tiếp trước khi nhận
    static let sound = "sound"
    static let saveImages = "saveImages"
}

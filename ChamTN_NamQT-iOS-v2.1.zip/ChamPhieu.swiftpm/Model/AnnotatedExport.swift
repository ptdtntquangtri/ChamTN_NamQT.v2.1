import UIKit

/// Vẽ ảnh bài chấm đã khoanh đúng/sai + khung điểm ở đầu trang; xuất JPEG (1 bài) hoặc PDF (cả lớp).
enum AnnotatedExport {
    private static func uiColor(for c: CellMark, cells: [CellMark], status: GradeResult?, exam: Exam) -> UIColor {
        guard let status else { return .systemBlue }
        switch c.part {
        case .sbd, .code: return .systemBlue
        case .p1:
            guard c.question <= exam.config.p1Count else { return .systemGray }
            if cells.filter({ $0.part == c.part && $0.question == c.question && $0.filled }).count > 1 { return .systemOrange }
            return (status.p1Status[safe: c.question - 1] ?? nil) == true ? .systemGreen : .systemRed
        case .p2:
            guard c.question <= exam.config.p2Count else { return .systemGray }
            let i = c.item / 2
            let both = cells.contains { $0.part == .p2 && $0.question == c.question && $0.item / 2 == i && $0.item != c.item && $0.filled }
            if both { return .systemOrange }
            return (status.p2Status[safe: c.question - 1]?[safe: i] ?? nil) == true ? .systemGreen : .systemRed
        case .p3:
            guard c.question <= exam.config.p3Count else { return .systemGray }
            return (status.p3Status[safe: c.question - 1] ?? nil) == true ? .systemGreen : .systemRed
        }
    }

    static func renderImage(record rec: ScanRecord, exam: Exam, classRoom: ClassRoom?, sheetImage: UIImage) -> UIImage {
        let g = Grader.grade(rec, exam: exam)
        let w = sheetImage.size.width
        let headerH = max(110, w * 0.14)
        let totalSize = CGSize(width: w, height: sheetImage.size.height + headerH)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        return UIGraphicsImageRenderer(size: totalSize, format: fmt).image { ctx in
            let cg = ctx.cgContext
            UIColor.white.setFill()
            cg.fill(CGRect(origin: .zero, size: totalSize))

            // Thanh tiêu đề điểm
            UIColor(white: 0.96, alpha: 1).setFill()
            cg.fill(CGRect(x: 0, y: 0, width: w, height: headerH))
            UIColor(white: 0.84, alpha: 1).setStroke()
            cg.setLineWidth(2)
            cg.move(to: CGPoint(x: 0, y: headerH - 1))
            cg.addLine(to: CGPoint(x: w, y: headerH - 1))
            cg.strokePath()

            let scale = w / 800
            let name = classRoom?.student(sbd: rec.sbd)?.name ?? "SBD \(rec.sbd.isEmpty ? "(trống)" : rec.sbd)"
            let titleAttr: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 24 * scale), .foregroundColor: UIColor.black]
            let subAttr: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 16 * scale), .foregroundColor: UIColor.darkGray]
            let scoreColor: UIColor = (g == nil || (g?.score10 ?? 0) < 5) ? .systemRed : UIColor(red: 0.1, green: 0.45, blue: 0.15, alpha: 1)
            let scoreAttr: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 40 * scale), .foregroundColor: scoreColor]

            (name as NSString).draw(at: CGPoint(x: 20 * scale, y: 12 * scale), withAttributes: titleAttr)
            let info = "\(exam.name) · SBD: \(rec.sbd.isEmpty ? "—" : rec.sbd) · Mã đề: \(rec.code.isEmpty ? "—" : rec.code)"
            (info as NSString).draw(at: CGPoint(x: 20 * scale, y: 44 * scale), withAttributes: subAttr)
            let detail: String
            if let g {
                let base = "P.I: \(g.p1Correct) đúng (\(Grader.format(g.p1Score))đ) · P.II: \(g.p2Items) ý (\(Grader.format(g.p2Score))đ) · P.III: \(g.p3Correct) đúng (\(Grader.format(g.p3Score))đ)"
                detail = exam.config.essayMax > 0 ? "\(base) · TL: \(Grader.format(g.essayScore))đ" : base
            } else {
                detail = "Chưa có đáp án mã đề \(rec.code)"
            }
            (detail as NSString).draw(at: CGPoint(x: 20 * scale, y: 70 * scale), withAttributes: subAttr)

            let scoreText = g.map { Grader.format($0.score10) } ?? "—"
            let scoreSize = (scoreText as NSString).size(withAttributes: scoreAttr)
            (scoreText as NSString).draw(at: CGPoint(x: w - 20 * scale - scoreSize.width, y: (headerH - scoreSize.height) / 2), withAttributes: scoreAttr)

            // Ảnh phiếu + vòng khoanh
            sheetImage.draw(in: CGRect(x: 0, y: headerH, width: w, height: sheetImage.size.height))
            let t = (rec.sheet ?? exam.config.sheet).template
            let r = max(4, t.bubbleRadius * Double(w) / Double(t.rectifyRect.width) * 1.25)
            cg.setLineWidth(max(2, CGFloat(r) / 2.8))
            for cell in rec.cells where cell.filled {
                let p = OMREngine.rectifiedPoint(cell.x, cell.y, template: t, width: Int(w))
                let rect = CGRect(x: p.x - r, y: p.y + headerH - r, width: 2 * r, height: 2 * r)
                uiColor(for: cell, cells: rec.cells, status: g, exam: exam).setStroke()
                cg.strokeEllipse(in: rect)
            }
        }
    }

    static func saveSingleJPEG(record rec: ScanRecord, exam: Exam, classRoom: ClassRoom?) -> URL? {
        guard let img = Files.loadImage(rec.imageName) else { return nil }
        let out = renderImage(record: rec, exam: exam, classRoom: classRoom, sheetImage: img)
        guard let data = out.jpegData(compressionQuality: 0.85) else { return nil }
        let sbd = rec.sbd.isEmpty ? "khong-sbd" : rec.sbd
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Bai cham - \(sbd).jpg")
        try? data.write(to: url)
        return url
    }

    /// Xuất toàn bộ bài chấm có ảnh của lớp thành 1 file PDF A4 (mỗi trang 1 bài).
    static func saveClassPDF(exam: Exam, classRoom: ClassRoom?) -> URL? {
        let recordsWithImg = exam.records.sorted { $0.sbd < $1.sbd }.compactMap { r -> (ScanRecord, UIImage)? in
            guard let img = Files.loadImage(r.imageName) else { return nil }
            return (r, img)
        }
        guard !recordsWithImg.isEmpty else { return nil }
        let pageRect = CGRect(x: 0, y: 0, width: 595, height: 842)
        let data = UIGraphicsPDFRenderer(bounds: pageRect).pdfData { ctx in
            let margin: CGFloat = 18
            let availW = pageRect.width - 2 * margin
            let availH = pageRect.height - 2 * margin
            for (rec, img) in recordsWithImg {
                ctx.beginPage()
                let annotated = renderImage(record: rec, exam: exam, classRoom: classRoom, sheetImage: img)
                let s = min(availW / annotated.size.width, availH / annotated.size.height)
                let dw = annotated.size.width * s, dh = annotated.size.height * s
                annotated.draw(in: CGRect(x: (pageRect.width - dw) / 2, y: (pageRect.height - dh) / 2, width: dw, height: dh))
            }
        }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Anh bai cham - \(ExportService.safeName(exam.name)).pdf")
        try? data.write(to: url)
        return url
    }
}

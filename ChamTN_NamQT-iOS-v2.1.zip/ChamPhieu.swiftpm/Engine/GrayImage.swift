import Foundation
import CoreGraphics
import CoreVideo
import UIKit

/// Ảnh xám 8 bit, lưu theo hàng.
struct GrayImage {
    let width: Int
    let height: Int
    var pixels: [UInt8]

    init(width: Int, height: Int, pixels: [UInt8]) {
        self.width = width
        self.height = height
        self.pixels = pixels
    }

    /// Lấy kênh độ sáng (Y) từ khung hình camera định dạng 420YpCbCr8BiPlanar.
    init?(pixelBuffer: CVPixelBuffer) {
        CVPixelBufferLockBaseAddress(pixelBuffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, .readOnly) }
        let planar = CVPixelBufferIsPlanar(pixelBuffer)
        let w = planar ? CVPixelBufferGetWidthOfPlane(pixelBuffer, 0) : CVPixelBufferGetWidth(pixelBuffer)
        let h = planar ? CVPixelBufferGetHeightOfPlane(pixelBuffer, 0) : CVPixelBufferGetHeight(pixelBuffer)
        let rowBytes = planar ? CVPixelBufferGetBytesPerRowOfPlane(pixelBuffer, 0) : CVPixelBufferGetBytesPerRow(pixelBuffer)
        guard let base = planar ? CVPixelBufferGetBaseAddressOfPlane(pixelBuffer, 0) : CVPixelBufferGetBaseAddress(pixelBuffer) else { return nil }
        let format = CVPixelBufferGetPixelFormatType(pixelBuffer)
        var out = [UInt8](repeating: 0, count: w * h)
        let src = base.assumingMemoryBound(to: UInt8.self)
        if planar {
            out.withUnsafeMutableBufferPointer { dst in
                for y in 0..<h {
                    memcpy(dst.baseAddress! + y * w, src + y * rowBytes, w)
                }
            }
        } else if format == kCVPixelFormatType_32BGRA {
            for y in 0..<h {
                let row = src + y * rowBytes
                for x in 0..<w {
                    let b = Int(row[4 * x]), g = Int(row[4 * x + 1]), r = Int(row[4 * x + 2])
                    out[y * w + x] = UInt8((r * 77 + g * 150 + b * 29) >> 8)
                }
            }
        } else {
            return nil
        }
        self.init(width: w, height: h, pixels: out)
    }

    /// Chuyển UIImage (ảnh chụp/ảnh thư viện) sang ảnh xám, cạnh dài tối đa `maxSide`.
    init?(uiImage: UIImage, maxSide: Int = 1920) {
        guard let cg = uiImage.normalizedCGImage() else { return nil }
        let scale = min(1.0, Double(maxSide) / Double(max(cg.width, cg.height)))
        let w = max(1, Int(Double(cg.width) * scale)), h = max(1, Int(Double(cg.height) * scale))
        var out = [UInt8](repeating: 255, count: w * h)
        let ok: Bool = out.withUnsafeMutableBytes { buf in
            guard let ctx = CGContext(data: buf.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w, space: CGColorSpaceCreateDeviceGray(),
                                      bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return false }
            ctx.interpolationQuality = .high
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard ok else { return nil }
        self.init(width: w, height: h, pixels: out)
    }

    @inline(__always) func pixel(_ x: Int, _ y: Int) -> UInt8 {
        let xx = min(max(x, 0), width - 1), yy = min(max(y, 0), height - 1)
        return pixels[yy * width + xx]
    }

    /// Nội suy song tuyến.
    @inline(__always) func bilinear(_ x: Double, _ y: Double) -> Double {
        let x0 = Int(floor(x)), y0 = Int(floor(y))
        let fx = x - Double(x0), fy = y - Double(y0)
        let a = Double(pixel(x0, y0)), b = Double(pixel(x0 + 1, y0))
        let c = Double(pixel(x0, y0 + 1)), d = Double(pixel(x0 + 1, y0 + 1))
        return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy
    }

    func cgImage() -> CGImage? {
        let data = Data(pixels) as CFData
        guard let provider = CGDataProvider(data: data) else { return nil }
        return CGImage(width: width, height: height, bitsPerComponent: 8, bitsPerPixel: 8, bytesPerRow: width,
                       space: CGColorSpaceCreateDeviceGray(), bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.none.rawValue),
                       provider: provider, decode: nil, shouldInterpolate: true, intent: .defaultIntent)
    }
}

extension UIImage {
    /// Vẽ lại ảnh theo đúng chiều (bỏ thông tin xoay EXIF).
    func normalizedCGImage() -> CGImage? {
        if imageOrientation == .up, let cg = cgImage { return cg }
        let format = UIGraphicsImageRendererFormat.default()
        format.scale = 1
        let renderer = UIGraphicsImageRenderer(size: size, format: format)
        let img = renderer.image { _ in draw(in: CGRect(origin: .zero, size: size)) }
        return img.cgImage
    }
}

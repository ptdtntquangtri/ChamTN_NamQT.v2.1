import Foundation
import CoreGraphics

/// Loại phiếu trả lời.
enum SheetKind: Codable, Hashable {
    /// Phiếu chính thức của Bộ GD&ĐT, mẫu 2025 (CV 1239): 40 – 8 – 6, SBD 8 số, mã đề 4 số.
    case official2025
    /// Phiếu do app in ra (A4), số câu từng phần đúng bằng cấu hình bài chấm. SBD 6 số, mã đề 3 số.
    case app(p1: Int, p2: Int, p3: Int)
    /// Mẫu phiếu mô tả bằng dữ liệu (TNMaker có sẵn hoặc mẫu tự tạo như Azota).
    case spec(id: String)

    var title: String {
        switch self {
        case .official2025: return "Phiếu Bộ GD&ĐT 2025"
        case let .app(a, b, c): return "Phiếu in từ app (\(a)–\(b)–\(c))"
        case let .spec(id): return TemplateRegistry.shared.spec(id)?.name ?? "Mẫu phiếu đã bị xoá"
        }
    }
    var template: SheetTemplate { SheetTemplate(kind: self) }
}

/// Hình học một mẫu phiếu.
///
/// Hệ toạ độ "sheet": tâm ô vuông định vị trên–trái = (0,0), trên–phải = (1,0), dưới–phải = (1, aspect),
/// dưới–trái = (0, aspect). Hai ô vuông ở giữa hai cạnh bên nằm ở `middleFraction` từ trên xuống.
struct SheetTemplate {
    let kind: SheetKind
    let aspect: Double
    let middleFraction: Double
    let markerSide: Double
    let bubbleRadius: Double
    let sbdDigits: Int
    let codeDigits: Int
    let p1Cap: Int
    let p2Cap: Int
    let p3Cap: Int
    let rectifyRect: CGRect
    /// Có giá trị khi là mẫu phiếu dữ liệu (TNMaker, Azota…).
    let spec: TemplateSpec?

    init(kind: SheetKind) {
        self.kind = kind
        switch kind {
        case let .spec(id):
            let sp = TemplateRegistry.shared.spec(id) ?? TemplateSpec(id: id, name: "?", aspect: 1, bubbleR: 0.01, markers: [], blocks: [])
            spec = sp
            let caps = sp.caps
            aspect = sp.aspect; middleFraction = 0.5
            markerSide = sp.cornerIndices.first.map { sp.markers.indices.contains($0) ? sp.markers[$0].side : 0.03 } ?? 0.03
            bubbleRadius = sp.bubbleR
            sbdDigits = caps.sbd; codeDigits = caps.code; p1Cap = caps.p1; p2Cap = caps.p2; p3Cap = caps.p3
            rectifyRect = sp.rectifyRect
        case .official2025:
            spec = nil
            aspect = Official.aspect; middleFraction = 0.6096; markerSide = 0.017446; bubbleRadius = 0.00788
            sbdDigits = 8; codeDigits = 4; p1Cap = 40; p2Cap = 8; p3Cap = 6
            rectifyRect = CGRect(x: -0.035, y: -0.365, width: 1.07, height: 1.38)
        case let .app(a, b, c):
            spec = nil
            let lay = AppSheetLayout(p1: a, p2: b, p3: c)
            aspect = lay.aspect; middleFraction = AppSheetLayout.middleFraction
            markerSide = AppSheetLayout.markerMM / AppSheetLayout.unit
            bubbleRadius = AppSheetLayout.bubbleMM / AppSheetLayout.unit
            sbdDigits = AppSheetLayout.sbdDigits; codeDigits = AppSheetLayout.codeDigits
            p1Cap = a; p2Cap = b; p3Cap = c
            rectifyRect = CGRect(x: -0.04, y: -0.04, width: 1.08, height: lay.aspect + 0.08)
        }
    }

    /// Câu q (1…), phương án k (0=A…3=D)
    func p1(_ q: Int, _ k: Int) -> CGPoint {
        switch kind {
        case .official2025: return Official.p1(q, k)
        case .app: return AppSheetLayout.toSheet(appLayout.p1mm(q, k))
        case .spec: return specPoint(.p1, q, k)
        }
    }
    /// Câu q, ý i (0=a…3=d), ds 0 = Đúng, 1 = Sai
    func p2(_ q: Int, _ i: Int, _ ds: Int) -> CGPoint {
        switch kind {
        case .official2025: return Official.p2(q, i, ds)
        case .app: return AppSheetLayout.toSheet(appLayout.p2mm(q, i, ds))
        case .spec: return specPoint(.p2, q, i * 2 + ds)
        }
    }
    /// Câu q, hàng row (0 "-", 1 ",", 2…11 chữ số 0…9), cột c (0…3)
    func p3(_ q: Int, _ row: Int, _ c: Int) -> CGPoint {
        switch kind {
        case .official2025: return Official.p3(q, row, c)
        case .app: return AppSheetLayout.toSheet(appLayout.p3mm(q, row, c))
        case .spec:
            let idx = SheetTemplate.p3Cells.firstIndex { $0.row == row && $0.col == c } ?? 0
            return specPoint(.p3, q, idx)
        }
    }
    func sbd(_ c: Int, _ d: Int) -> CGPoint {
        switch kind {
        case .official2025: return Official.sbd(c, d)
        case .app: return AppSheetLayout.toSheet(AppSheetLayout.sbdmm(c, d))
        case .spec: return specPoint(.sbd, c + 1, d)
        }
    }
    func code(_ c: Int, _ d: Int) -> CGPoint {
        switch kind {
        case .official2025: return Official.code(c, d)
        case .app: return AppSheetLayout.toSheet(AppSheetLayout.codemm(c, d))
        case .spec: return specPoint(.code, c + 1, d)
        }
    }

    private func specPoint(_ k: TemplateSpec.BlockKind, _ q: Int, _ item: Int) -> CGPoint {
        guard let c = spec?.cells().first(where: { $0.kind == k && $0.question == q && $0.item == item }) else { return .zero }
        return CGPoint(x: c.x, y: c.y)
    }

    private var appLayout: AppSheetLayout {
        if case let .app(a, b, c) = kind { return AppSheetLayout(p1: a, p2: b, p3: c) }
        return AppSheetLayout(p1: 0, p2: 0, p3: 0)
    }

    /// Các ô của một câu Phần III: (hàng, cột, ký hiệu)
    static let p3Cells: [(row: Int, col: Int, symbol: Character)] = {
        var cells: [(Int, Int, Character)] = [(0, 0, "-"), (1, 1, ","), (1, 2, ",")]
        for d in 0..<10 {
            for c in 0..<4 { cells.append((2 + d, c, Character(String(d)))) }
        }
        return cells.map { (row: $0.0, col: $0.1, symbol: $0.2) }
    }()

    /// Nhóm câu dùng chung một mức "giấy trắng" khi tính độ đậm.
    var p1Groups: [[Int]] { stride(from: 1, through: max(p1Cap, 1), by: 10).compactMap { s in p1Cap >= s ? Array(s...min(s + 9, p1Cap)) : nil } }
    var p2Groups: [[Int]] { stride(from: 1, through: max(p2Cap, 1), by: 2).compactMap { s in p2Cap >= s ? Array(s...min(s + 1, p2Cap)) : nil } }

    /// Phiếu chính thức: toạ độ đo từ mẫu phiếu của Bộ.
    enum Official {
        static let aspect: Double = 505.65 / 888.0
        static let p1X0 = 0.143826, p1BlockDX = 0.240391, p1OptDX = 0.042562
        static let p1V0 = 0.118186, p1DV = 0.047158
        static let p2V0 = 0.781474, p2DV = 0.046690
        static let p3X0 = 0.112822, p3BlockDX = 0.153422, p3ColDX = 0.025605
        static let p3V0 = 1.134908, p3DV = 0.052316
        static let sbdX0 = 0.710425, sbdDX = 0.020540
        static let codeX0 = 0.895344, codeDX = 0.020647
        static let headV0 = -0.590794, headDV = 0.055312

        static func p1(_ q: Int, _ k: Int) -> CGPoint {
            let b = (q - 1) / 10, r = (q - 1) % 10
            return CGPoint(x: p1X0 + Double(b) * p1BlockDX + (Double(k) - 1.5) * p1OptDX,
                           y: (p1V0 + Double(r) * p1DV) * aspect)
        }
        static func p2(_ q: Int, _ i: Int, _ ds: Int) -> CGPoint {
            let b = (q - 1) / 2, s = (q - 1) % 2, k = 2 * s + ds
            return CGPoint(x: p1X0 + Double(b) * p1BlockDX + (Double(k) - 1.5) * p1OptDX,
                           y: (p2V0 + Double(i) * p2DV) * aspect)
        }
        static func p3(_ q: Int, _ row: Int, _ c: Int) -> CGPoint {
            CGPoint(x: p3X0 + Double(q - 1) * p3BlockDX + (Double(c) - 1.5) * p3ColDX,
                    y: (p3V0 + Double(row) * p3DV) * aspect)
        }
        static func sbd(_ c: Int, _ d: Int) -> CGPoint {
            CGPoint(x: sbdX0 + Double(c) * sbdDX, y: (headV0 + Double(d) * headDV) * aspect)
        }
        static func code(_ c: Int, _ d: Int) -> CGPoint {
            CGPoint(x: codeX0 + Double(c) * codeDX, y: (headV0 + Double(d) * headDV) * aspect)
        }
    }
}

/// Bố cục phiếu do app in (đơn vị mm trên trang A4 210 × 297). Dùng chung cho cả máy in PDF và bộ đọc,
/// nên phiếu in ra và phiếu được đọc luôn khớp nhau.
struct AppSheetLayout {
    static let markerLeft = 12.0, markerRight = 198.0, markerTop = 14.0, markerBottom = 283.0
    static let unit = markerRight - markerLeft
    static let middleFraction = 0.4
    static let markerMM = 6.0
    static let bubbleMM = 1.9
    static let sbdDigits = 6, codeDigits = 3
    static let maxP1 = 100, maxP2 = 10, maxP3 = 12
    static let answerTop = 86.0, contentBottomLimit = 279.0

    let p1: Int, p2: Int, p3: Int
    let p1Y: Double, p2Y: Double, p3Y: Double, bottom: Double

    init(p1: Int, p2: Int, p3: Int) {
        self.p1 = p1; self.p2 = p2; self.p3 = p3
        var y = AppSheetLayout.answerTop
        p1Y = y
        y += Double(p1 > 0 ? (p1 + 49) / 50 : 0) * 60 + (p1 > 0 ? 3 : 0)
        p2Y = y
        y += Double(p2 > 0 ? (p2 + 4) / 5 : 0) * 29 + (p2 > 0 ? 3 : 0)
        p3Y = y
        y += Double(p3 > 0 ? (p3 + 5) / 6 : 0) * 62
        bottom = y
    }

    var aspect: Double { (AppSheetLayout.markerBottom - AppSheetLayout.markerTop) / AppSheetLayout.unit }
    var fits: Bool {
        bottom <= AppSheetLayout.contentBottomLimit && p1 <= AppSheetLayout.maxP1 && p2 <= AppSheetLayout.maxP2 && p3 <= AppSheetLayout.maxP3
    }
    static var middleY: Double { markerTop + middleFraction * (markerBottom - markerTop) }
    static var markerCenters: [CGPoint] {
        [CGPoint(x: markerLeft, y: markerTop), CGPoint(x: markerRight, y: markerTop),
         CGPoint(x: markerLeft, y: middleY), CGPoint(x: markerRight, y: middleY),
         CGPoint(x: markerLeft, y: markerBottom), CGPoint(x: markerRight, y: markerBottom)]
    }

    static func toSheet(_ p: CGPoint) -> CGPoint {
        CGPoint(x: (Double(p.x) - markerLeft) / unit, y: (Double(p.y) - markerTop) / unit)
    }

    func p1mm(_ q: Int, _ k: Int) -> CGPoint {
        let i = q - 1, blk = i / 10, band = blk / 5, col = blk % 5, r = i % 10
        return CGPoint(x: 20 + Double(col) * 34 + 10 + Double(k) * 6, y: p1Y + Double(band) * 60 + 9 + Double(r) * 5.2)
    }
    func p2mm(_ q: Int, _ i: Int, _ ds: Int) -> CGPoint {
        let j = q - 1, band = j / 5, col = j % 5
        return CGPoint(x: 20 + Double(col) * 34 + 14 + Double(ds) * 8, y: p2Y + Double(band) * 29 + 9 + Double(i) * 5.2)
    }
    func p3mm(_ q: Int, _ row: Int, _ c: Int) -> CGPoint {
        let j = q - 1, band = j / 6, col = j % 6
        return CGPoint(x: 20 + Double(col) * 28 + 8 + Double(c) * 5, y: p3Y + Double(band) * 62 + 9 + Double(row) * 4.4)
    }
    static func sbdmm(_ c: Int, _ d: Int) -> CGPoint { CGPoint(x: 120 + Double(c) * 5.2, y: 37 + Double(d) * 4.6) }
    static func codemm(_ c: Int, _ d: Int) -> CGPoint { CGPoint(x: 160 + Double(c) * 5.2, y: 37 + Double(d) * 4.6) }
}

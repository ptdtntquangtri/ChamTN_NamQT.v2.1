import Foundation
import CoreGraphics

/// Mẫu phiếu mô tả bằng dữ liệu: vị trí các ô vuông định vị và các lưới ô tô.
/// Dùng cho phiếu TNMaker (có sẵn) và phiếu do người dùng tự tạo từ phiếu trắng (Azota, phiếu của trường…).
///
/// Hệ toạ độ "sheet": tâm ô vuông góc trên–trái = (0,0), trên–phải = (1,0), dưới–phải = (1, aspect), dưới–trái = (0, aspect).
struct TemplateSpec: Codable, Identifiable, Hashable {
    struct Marker: Codable, Hashable { var x: Double; var y: Double; var side: Double }

    enum BlockKind: String, Codable, CaseIterable, Identifiable {
        case p1, p2, p3, sbd, code
        var id: String { rawValue }
        var title: String {
            switch self {
            case .p1: return "Phần I – ABCD"
            case .p2: return "Phần II – Đúng/Sai"
            case .p3: return "Phần III – Trả lời ngắn"
            case .sbd: return "Số báo danh"
            case .code: return "Mã đề"
            }
        }
    }

    /// Một lưới ô tô. `xs` là toạ độ các cột, `ys` các hàng.
    /// - p1: mỗi hàng một câu (bắt đầu từ `first`), 4 cột A–D.
    /// - p2: 4 hàng ý a–d; mỗi 2 cột (Đúng, Sai) là một câu, câu đầu là `first`.
    /// - p3: một câu (`first`), 12 hàng ("-", ",", 0…9) × 4 cột.
    /// - sbd / code: mỗi cột một chữ số (cột đầu là chữ số thứ `first`), 10 hàng 0…9.
    struct Block: Codable, Hashable, Identifiable {
        var id = UUID()
        var kind: BlockKind
        var first: Int
        var xs: [Double]
        var ys: [Double]

        enum CodingKeys: String, CodingKey { case kind, first, xs, ys }
        init(kind: BlockKind, first: Int, xs: [Double], ys: [Double]) {
            self.kind = kind; self.first = first; self.xs = xs; self.ys = ys
        }
        init(from decoder: Decoder) throws {
            let c = try decoder.container(keyedBy: CodingKeys.self)
            kind = try c.decode(BlockKind.self, forKey: .kind)
            first = try c.decode(Int.self, forKey: .first)
            xs = try c.decode([Double].self, forKey: .xs)
            ys = try c.decode([Double].self, forKey: .ys)
        }
        func encode(to encoder: Encoder) throws {
            var c = encoder.container(keyedBy: CodingKeys.self)
            try c.encode(kind, forKey: .kind); try c.encode(first, forKey: .first)
            try c.encode(xs, forKey: .xs); try c.encode(ys, forKey: .ys)
        }

        /// Số hàng/cột cần có theo loại vùng.
        static func shape(_ kind: BlockKind, count: Int) -> (rows: Int, cols: Int) {
            switch kind {
            case .p1: return (max(1, count), 4)
            case .p2: return (4, 2 * max(1, count))
            case .p3: return (12, 4)
            case .sbd, .code: return (10, max(1, count))
            }
        }

        var questionCount: Int {
            switch kind {
            case .p1: return ys.count
            case .p2: return xs.count / 2
            case .p3: return 1
            case .sbd, .code: return xs.count
            }
        }

        var label: String {
            switch kind {
            case .p1: return "Phần I: câu \(first)–\(first + ys.count - 1)"
            case .p2: return xs.count / 2 > 1 ? "Phần II: câu \(first)–\(first + xs.count / 2 - 1)" : "Phần II: câu \(first)"
            case .p3: return "Phần III: câu \(first)"
            case .sbd: return "Số báo danh (\(xs.count) số)"
            case .code: return "Mã đề (\(xs.count) số)"
            }
        }
    }

    struct Cell: Hashable {
        var kind: BlockKind
        var question: Int   // số câu, hoặc vị trí chữ số (1…) với SBD/mã đề
        var item: Int       // p1: 0–3 · p2: ý×2 + (0 Đúng, 1 Sai) · p3: chỉ số trong p3Cells · sbd/code: chữ số 0–9
        var x: Double
        var y: Double
        var block: Int
    }

    var id: String
    var name: String
    var note: String = ""
    var aspect: Double
    var bubbleR: Double
    var markers: [Marker]
    var blocks: [Block]
    var builtin: Bool = false
    var updatedAt: Date? = nil
    /// Nhóm mẫu phiếu: "tnmaker", "qm", hoặc nil (tự tạo).
    var group: String? = nil
    /// Số đáp án mỗi câu Phần I (4 = A–D, 5 = A–E).
    var choices: Int? = nil

    var p1Choices: Int {
        let inferred = blocks.filter { $0.kind == .p1 }.map { $0.xs.count }.max() ?? 4
        return min(5, max(4, choices ?? inferred))
    }

    // MARK: Các ô

    func cells() -> [Cell] {
        var out: [Cell] = []
        for (bi, b) in blocks.enumerated() {
            switch b.kind {
            case .p1:
                for (r, y) in b.ys.enumerated() {
                    for (c, x) in b.xs.prefix(5).enumerated() { out.append(Cell(kind: .p1, question: b.first + r, item: c, x: x, y: y, block: bi)) }
                }
            case .sbd, .code:
                for (c, x) in b.xs.enumerated() {
                    for (d, y) in b.ys.prefix(10).enumerated() { out.append(Cell(kind: b.kind, question: b.first + c, item: d, x: x, y: y, block: bi)) }
                }
            case .p2:
                for q in 0..<(b.xs.count / 2) {
                    for (i, y) in b.ys.prefix(4).enumerated() {
                        for ds in 0..<2 { out.append(Cell(kind: .p2, question: b.first + q, item: i * 2 + ds, x: b.xs[q * 2 + ds], y: y, block: bi)) }
                    }
                }
            case .p3:
                guard b.xs.count >= 4, b.ys.count >= 12 else { continue }
                for (idx, cell) in SheetTemplate.p3Cells.enumerated() {
                    out.append(Cell(kind: .p3, question: b.first, item: idx, x: b.xs[cell.col], y: b.ys[cell.row], block: bi))
                }
            }
        }
        return out
    }

    struct Caps: Hashable { var p1 = 0, p2 = 0, p3 = 0, sbd = 0, code = 0 }

    var caps: Caps {
        var c = Caps()
        for cell in cells() {
            switch cell.kind {
            case .p1: c.p1 = max(c.p1, cell.question)
            case .p2: c.p2 = max(c.p2, cell.question)
            case .p3: c.p3 = max(c.p3, cell.question)
            case .sbd: c.sbd = max(c.sbd, cell.question)
            case .code: c.code = max(c.code, cell.question)
            }
        }
        return c
    }

    /// Chỉ số 4 ô vuông góc: trên–trái, trên–phải, dưới–phải, dưới–trái.
    var cornerIndices: [Int] {
        let targets = [CGPoint(x: 0, y: 0), CGPoint(x: 1, y: 0), CGPoint(x: 1, y: aspect), CGPoint(x: 0, y: aspect)]
        return targets.map { t in
            markers.indices.min { hypot(markers[$0].x - Double(t.x), markers[$0].y - Double(t.y)) < hypot(markers[$1].x - Double(t.x), markers[$1].y - Double(t.y)) } ?? 0
        }
    }

    /// Vùng ảnh nắn thẳng để lưu/hiển thị: bao các ô định vị và ô tô.
    var rectifyRect: CGRect {
        var minX = 0.0, minY = 0.0, maxX = 1.0, maxY = aspect
        for m in markers { minX = min(minX, m.x); minY = min(minY, m.y); maxX = max(maxX, m.x); maxY = max(maxY, m.y) }
        for b in blocks {
            minX = min(minX, b.xs.min() ?? 0); maxX = max(maxX, b.xs.max() ?? 0)
            minY = min(minY, b.ys.min() ?? 0); maxY = max(maxY, b.ys.max() ?? 0)
        }
        let pad = 0.04
        return CGRect(x: minX - pad, y: minY - pad, width: maxX - minX + 2 * pad, height: maxY - minY + 2 * pad)
    }

    var summary: String {
        let c = caps
        var parts: [String] = []
        let optLabel = p1Choices == 5 ? "ABCDE" : "ABCD"
        if c.p1 > 0 { parts.append("\(c.p1) câu \(optLabel)") }
        if c.p2 > 0 { parts.append("\(c.p2) câu Đ/S") }
        if c.p3 > 0 { parts.append("\(c.p3) câu trả lời ngắn") }
        parts.append("SBD \(c.sbd) số, mã đề \(c.code) số")
        return parts.joined(separator: " · ")
    }
}

/// Danh sách mẫu phiếu dùng chung cho mọi luồng (camera chạy ngoài luồng chính).
final class TemplateRegistry: @unchecked Sendable {
    static let shared = TemplateRegistry()
    private let lock = NSLock()
    private var custom: [String: TemplateSpec] = [:]

    func setCustom(_ list: [TemplateSpec]) {
        lock.lock(); defer { lock.unlock() }
        custom = Dictionary(list.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
    }

    func spec(_ id: String) -> TemplateSpec? {
        lock.lock()
        let c = custom[id]
        lock.unlock()
        if let c { return c }
        return BuiltinTemplates.all.first(where: { $0.id == id })
    }
}

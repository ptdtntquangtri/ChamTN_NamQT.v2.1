import Foundation
import CoreGraphics

/// Phép biến đổi phối cảnh 3×3 (h33 = 1).
struct Homography: Codable, Hashable {
    var m: [Double] // 9 phần tử, theo hàng

    static let identity = Homography(m: [1, 0, 0, 0, 1, 0, 0, 0, 1])

    /// Tìm H sao cho H(src[i]) = dst[i] với 4 cặp điểm.
    static func from(_ src: [CGPoint], to dst: [CGPoint]) -> Homography? {
        guard src.count == 4, dst.count == 4 else { return nil }
        var a = [[Double]](repeating: [Double](repeating: 0, count: 9), count: 8)
        for i in 0..<4 {
            let x = Double(src[i].x), y = Double(src[i].y)
            let u = Double(dst[i].x), v = Double(dst[i].y)
            a[2 * i] = [x, y, 1, 0, 0, 0, -u * x, -u * y, u]
            a[2 * i + 1] = [0, 0, 0, x, y, 1, -v * x, -v * y, v]
        }
        // Khử Gauss có chọn trụ
        for col in 0..<8 {
            var pivot = col
            for r in (col + 1)..<8 where abs(a[r][col]) > abs(a[pivot][col]) { pivot = r }
            if abs(a[pivot][col]) < 1e-12 { return nil }
            a.swapAt(col, pivot)
            for r in 0..<8 where r != col {
                let f = a[r][col] / a[col][col]
                if f == 0 { continue }
                for c in col..<9 { a[r][c] -= f * a[col][c] }
            }
        }
        var h = [Double](repeating: 0, count: 9)
        for i in 0..<8 { h[i] = a[i][8] / a[i][i] }
        h[8] = 1
        return Homography(m: h)
    }

    /// Bình phương tối thiểu với nhiều cặp điểm (≥ 4).
    static func fit(_ src: [CGPoint], to dst: [CGPoint]) -> Homography? {
        guard src.count == dst.count, src.count >= 4 else { return nil }
        if src.count == 4 { return from(src, to: dst) }
        var ata = [[Double]](repeating: [Double](repeating: 0, count: 9), count: 8)
        for (p, q) in zip(src, dst) {
            let x = Double(p.x), y = Double(p.y), u = Double(q.x), v = Double(q.y)
            let rows: [([Double], Double)] = [([x, y, 1, 0, 0, 0, -u * x, -u * y], u), ([0, 0, 0, x, y, 1, -v * x, -v * y], v)]
            for (r, b) in rows {
                for i in 0..<8 {
                    for j in 0..<8 { ata[i][j] += r[i] * r[j] }
                    ata[i][8] += r[i] * b
                }
            }
        }
        for col in 0..<8 {
            var pivot = col
            for r in (col + 1)..<8 where abs(ata[r][col]) > abs(ata[pivot][col]) { pivot = r }
            if abs(ata[pivot][col]) < 1e-14 { return nil }
            ata.swapAt(col, pivot)
            for r in 0..<8 where r != col {
                let f = ata[r][col] / ata[col][col]
                if f == 0 { continue }
                for c in col..<9 { ata[r][c] -= f * ata[col][c] }
            }
        }
        var h = [Double](repeating: 0, count: 9)
        for i in 0..<8 { h[i] = ata[i][8] / ata[i][i] }
        h[8] = 1
        return Homography(m: h)
    }

    func inverse() -> Homography? {
        let a = m
        let c00 = a[4] * a[8] - a[5] * a[7], c01 = a[5] * a[6] - a[3] * a[8], c02 = a[3] * a[7] - a[4] * a[6]
        let det = a[0] * c00 + a[1] * c01 + a[2] * c02
        guard abs(det) > 1e-18 else { return nil }
        let inv = [c00, a[2] * a[7] - a[1] * a[8], a[1] * a[5] - a[2] * a[4],
                   c01, a[0] * a[8] - a[2] * a[6], a[2] * a[3] - a[0] * a[5],
                   c02, a[1] * a[6] - a[0] * a[7], a[0] * a[4] - a[1] * a[3]]
        return Homography(m: inv.map { $0 / det })
    }

    func apply(_ p: CGPoint) -> CGPoint {
        let x = Double(p.x), y = Double(p.y)
        let w = m[6] * x + m[7] * y + m[8]
        return CGPoint(x: (m[0] * x + m[1] * y + m[2]) / w,
                       y: (m[3] * x + m[4] * y + m[5]) / w)
    }

    @inline(__always) func apply(_ x: Double, _ y: Double) -> (Double, Double) {
        let w = m[6] * x + m[7] * y + m[8]
        return ((m[0] * x + m[1] * y + m[2]) / w, (m[3] * x + m[4] * y + m[5]) / w)
    }
}

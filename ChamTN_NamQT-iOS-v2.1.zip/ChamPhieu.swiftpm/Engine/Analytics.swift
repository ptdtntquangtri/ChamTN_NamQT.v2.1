import Foundation

/// Thống kê & phân tích đề thi (phổ điểm, phân loại, tỷ lệ đúng/sai từng câu, học sinh chưa chấm).
struct ItemStat: Identifiable, Hashable {
    var id: String
    var part: String
    var label: String
    var correct: Int
    var wrong: Int
    var blank: Int
    var distribution: [String: Int]

    var total: Int { correct + wrong + blank }
    var correctRate: Double { total == 0 ? 0 : Double(correct) / Double(total) }
}

struct ScoreTier: Identifiable, Hashable {
    var id: String { label }
    var label: String
    var range: String
    var count: Int
}

struct ExamAnalytics {
    var gradedCount: Int
    var ungradedCount: Int
    var avg: Double
    var max: Double
    var min: Double
    var passCount: Int
    var tiers: [ScoreTier]
    var histogram: [Int] // 10 khoảng: [0..1), [1..2), ..., [9..10]
    var items: [ItemStat]
    var missingStudents: [Student]
    var unknownRecords: [ScanRecord]

    var hardestItems: [ItemStat] {
        items.filter { $0.total > 0 }.sorted { $0.correctRate < $1.correctRate }
    }

    static func compute(exam: Exam, classRoom: ClassRoom?) -> ExamAnalytics {
        let graded: [(ScanRecord, GradeResult)] = exam.records.compactMap { r in
            guard let g = Grader.grade(r, exam: exam) else { return nil }
            return (r, g)
        }
        let scores = graded.map(\.1.score10)
        let avg = scores.isEmpty ? 0 : Grader.round2(scores.reduce(0, +) / Double(scores.count))
        let maxS = scores.max() ?? 0
        let minS = scores.min() ?? 0
        let pass = scores.filter { $0 >= 5 }.count

        let tiers = [
            ScoreTier(label: "Giỏi", range: "≥ 8,0", count: scores.filter { $0 >= 8 }.count),
            ScoreTier(label: "Khá", range: "6,5 – <8,0", count: scores.filter { $0 >= 6.5 && $0 < 8 }.count),
            ScoreTier(label: "Trung bình", range: "5,0 – <6,5", count: scores.filter { $0 >= 5 && $0 < 6.5 }.count),
            ScoreTier(label: "Yếu", range: "3,5 – <5,0", count: scores.filter { $0 >= 3.5 && $0 < 5 }.count),
            ScoreTier(label: "Kém", range: "< 3,5", count: scores.filter { $0 < 3.5 }.count),
        ]

        var hist = Array(repeating: 0, count: 10)
        for s in scores {
            let bin = Swift.min(9, Swift.max(0, Int(s)))
            hist[bin] += 1
        }

        var items: [ItemStat] = []
        let c = exam.config
        for i in 0..<c.p1Count {
            var ok = 0, wrong = 0, blank = 0
            var dist: [String: Int] = [:]
            for (r, g) in graded {
                let ans = i < r.p1.count ? r.p1[i] : ""
                if !ans.isEmpty { dist[ans, default: 0] += 1 }
                switch g.p1Status[safe: i] ?? nil {
                case true: ok += 1
                case false: wrong += 1
                case nil: blank += 1
                }
            }
            items.append(ItemStat(id: "p1-\(i)", part: "Phần I", label: "I.\(i + 1)", correct: ok, wrong: wrong, blank: blank, distribution: dist))
        }
        let subLetters = ["a", "b", "c", "d"]
        for q in 0..<c.p2Count {
            for si in 0..<4 {
                var ok = 0, wrong = 0, blank = 0
                var dist: [String: Int] = [:]
                for (r, g) in graded {
                    let s = Array(q < r.p2.count ? r.p2[q] : "____")
                    let ch: Character = si < s.count ? s[si] : "_"
                    let sym = ch == "D" ? "Đ" : (ch == "S" ? "S" : (ch == "*" ? "*" : ""))
                    if !sym.isEmpty { dist[sym, default: 0] += 1 }
                    switch g.p2Status[safe: q]?[safe: si] ?? nil {
                    case true: ok += 1
                    case false: wrong += 1
                    case nil: blank += 1
                    }
                }
                items.append(ItemStat(id: "p2-\(q)-\(si)", part: "Phần II", label: "II.\(q + 1)\(subLetters[si])", correct: ok, wrong: wrong, blank: blank, distribution: dist))
            }
        }
        for i in 0..<c.p3Count {
            var ok = 0, wrong = 0, blank = 0
            var dist: [String: Int] = [:]
            for (r, g) in graded {
                let ans = i < r.p3.count ? r.p3[i] : ""
                if !ans.isEmpty { dist[ans, default: 0] += 1 }
                switch g.p3Status[safe: i] ?? nil {
                case true: ok += 1
                case false: wrong += 1
                case nil: blank += 1
                }
            }
            items.append(ItemStat(id: "p3-\(i)", part: "Phần III", label: "III.\(i + 1)", correct: ok, wrong: wrong, blank: blank, distribution: dist))
        }

        let missing: [Student]
        let unknown: [ScanRecord]
        if let cls = classRoom {
            missing = cls.students.filter { st in
                !exam.records.contains { r in
                    r.sbd == st.sbd || (Int(r.sbd) != nil && Int(r.sbd) == Int(st.sbd))
                }
            }.sorted { $0.sbd < $1.sbd }
            unknown = exam.records.filter { cls.student(sbd: $0.sbd) == nil }
        } else {
            missing = []; unknown = []
        }

        return ExamAnalytics(gradedCount: graded.count, ungradedCount: exam.records.count - graded.count,
                             avg: avg, max: maxS, min: minS, passCount: pass, tiers: tiers, histogram: hist,
                             items: items, missingStudents: missing, unknownRecords: unknown)
    }
}

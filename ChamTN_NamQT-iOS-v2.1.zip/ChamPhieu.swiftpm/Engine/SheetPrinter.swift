import UIKit

/// Vẽ phiếu trả lời của app ra PDF (A4). Toạ độ lấy từ `AppSheetLayout` — đúng bộ toạ độ mà bộ đọc dùng.
enum SheetPrinter {
    static let pageSize = CGSize(width: 595.28, height: 841.89) // A4, đơn vị point
    @inline(__always) static func pt(_ mm: Double) -> CGFloat { CGFloat(mm * 72.0 / 25.4) }
    @inline(__always) static func pt(_ p: CGPoint) -> CGPoint { CGPoint(x: pt(Double(p.x)), y: pt(Double(p.y))) }

    struct Options {
        var title = "PHIẾU TRẢ LỜI TRẮC NGHIỆM"
        var examName = ""
        var subtitle = ""
        var copies = 1
        /// In 2 phiếu cạnh nhau trên 1 trang A4 ngang (cắt đôi thành 2 phiếu A5 tiết kiệm giấy).
        var twoPerPage = false
        var footer = "ChamTN_NamQT · Tô kín ô tròn bằng bút chì 2B hoặc bút mực đen · Không tô ra ngoài, không làm bẩn 6 ô vuông đen"
    }

    static func pdf(p1: Int, p2: Int, p3: Int, options: Options) -> Data {
        let lay = AppSheetLayout(p1: p1, p2: p2, p3: p3)
        if !options.twoPerPage {
            let renderer = UIGraphicsPDFRenderer(bounds: CGRect(origin: .zero, size: pageSize))
            return renderer.pdfData { ctx in
                for _ in 0..<max(1, options.copies) {
                    ctx.beginPage()
                    draw(lay, options: options, in: ctx.cgContext)
                }
            }
        }
        // A4 ngang: 841.89 × 595.28 pt, mỗi nửa là một phiếu A5 (tỉ lệ 1/√2 = 0.7071)
        let landSize = CGSize(width: pageSize.height, height: pageSize.width)
        let scale = landSize.height / pageSize.height
        let halfW = landSize.width / 2
        let pageCount = max(1, (options.copies + 1) / 2)
        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(origin: .zero, size: landSize))
        return renderer.pdfData { ctx in
            for _ in 0..<pageCount {
                ctx.beginPage()
                let cg = ctx.cgContext
                for slot in 0..<2 {
                    cg.saveGState()
                    cg.translateBy(x: CGFloat(slot) * halfW, y: 0)
                    cg.scaleBy(x: scale, y: scale)
                    draw(lay, options: options, in: cg)
                    cg.restoreGState()
                }
                // Đường nét đứt cắt giữa
                cg.saveGState()
                cg.setStrokeColor(UIColor.lightGray.cgColor)
                cg.setLineWidth(0.7)
                cg.setLineDash(phase: 0, lengths: [4, 4])
                cg.move(to: CGPoint(x: halfW, y: 12))
                cg.addLine(to: CGPoint(x: halfW, y: landSize.height - 12))
                cg.strokePath()
                cg.restoreGState()
            }
        }
    }

    // MARK: - Vẽ

    static func draw(_ lay: AppSheetLayout, options: Options, in cg: CGContext) {
        // 6 ô vuông định vị
        cg.setFillColor(UIColor.black.cgColor)
        let half = AppSheetLayout.markerMM / 2
        for c in AppSheetLayout.markerCenters {
            cg.fill(CGRect(x: pt(Double(c.x) - half), y: pt(Double(c.y) - half), width: pt(AppSheetLayout.markerMM), height: pt(AppSheetLayout.markerMM)))
        }

        // Tiêu đề và thông tin
        text(options.title, at: CGPoint(x: 105, y: 17.5), size: 14, weight: .bold, align: .center)
        if !options.examName.isEmpty {
            text(options.examName, at: CGPoint(x: 20, y: 26), size: 9.5, weight: .semibold, maxWidth: 88)
        }
        let infoX = 20.0
        text("Họ và tên: ..............................................................", at: CGPoint(x: infoX, y: 36), size: 9)
        text("Lớp: ..................   Ngày: ......./......./..........", at: CGPoint(x: infoX, y: 46), size: 9)
        text("Mã đề: ..............   Điểm: ..............", at: CGPoint(x: infoX, y: 56), size: 9)
        if !options.subtitle.isEmpty {
            text(options.subtitle, at: CGPoint(x: infoX, y: 66), size: 7.5, color: .darkGray, maxWidth: 90)
        }
        text("Tô số báo danh và mã đề ở ô bên phải →", at: CGPoint(x: infoX, y: 74), size: 7, color: .darkGray)

        // Số báo danh và mã đề
        digitBlock(label: "Số báo danh", count: AppSheetLayout.sbdDigits, pos: AppSheetLayout.sbdmm, in: cg)
        digitBlock(label: "Mã đề", count: AppSheetLayout.codeDigits, pos: AppSheetLayout.codemm, in: cg)

        // Phần I
        if lay.p1 > 0 {
            text("PHẦN I. Chọn một phương án A, B, C, D", at: CGPoint(x: 20, y: lay.p1Y - 2.8), size: 8, weight: .bold)
            for q in 1...lay.p1 {
                let p = lay.p1mm(q, 0)
                text("\(q)", at: CGPoint(x: Double(p.x) - 3.6, y: Double(p.y) - 1.6), size: 7.5, weight: .semibold, align: .right)
                for k in 0..<4 { bubble(lay.p1mm(q, k), label: ["A", "B", "C", "D"][k], in: cg) }
            }
        }
        // Phần II
        if lay.p2 > 0 {
            text("PHẦN II. Đúng / Sai", at: CGPoint(x: 20, y: lay.p2Y - 2.8), size: 8, weight: .bold)
            for q in 1...lay.p2 {
                let first = lay.p2mm(q, 0, 0)
                text("Câu \(q)", at: CGPoint(x: Double(first.x) - 1, y: Double(first.y) - 6.6), size: 7, weight: .semibold)
                for i in 0..<4 {
                    let p = lay.p2mm(q, i, 0)
                    text(["a)", "b)", "c)", "d)"][i], at: CGPoint(x: Double(p.x) - 6.5, y: Double(p.y) - 1.5), size: 7)
                    bubble(lay.p2mm(q, i, 0), label: "Đ", in: cg)
                    bubble(lay.p2mm(q, i, 1), label: "S", in: cg)
                }
            }
        }
        // Phần III
        if lay.p3 > 0 {
            text("PHẦN III. Trả lời ngắn – tô từ trái sang phải", at: CGPoint(x: 20, y: lay.p3Y - 2.8), size: 8, weight: .bold)
            for q in 1...lay.p3 {
                let first = lay.p3mm(q, 0, 0)
                text("Câu \(q)", at: CGPoint(x: Double(first.x) - 6, y: Double(first.y) - 6.6), size: 7, weight: .semibold)
                for cell in SheetTemplate.p3Cells {
                    bubble(lay.p3mm(q, cell.row, cell.col), label: String(cell.symbol), in: cg)
                }
            }
        }
        text(options.footer, at: CGPoint(x: 105, y: 289), size: 6.5, color: .darkGray, align: .center, maxWidth: 180)
    }

    private static func digitBlock(label: String, count: Int, pos: (Int, Int) -> CGPoint, in cg: CGContext) {
        let first = pos(0, 0), last = pos(count - 1, 0)
        let center = (Double(first.x) + Double(last.x)) / 2
        text(label, at: CGPoint(x: center, y: 25.5), size: 7.5, weight: .semibold, align: .center)
        // Ô viết số
        cg.setStrokeColor(UIColor.darkGray.cgColor)
        cg.setLineWidth(0.5)
        for c in 0..<count {
            let x = Double(pos(c, 0).x)
            cg.stroke(CGRect(x: pt(x - 2.4), y: pt(29.2), width: pt(4.8), height: pt(4.6)))
        }
        for c in 0..<count {
            for d in 0..<10 { bubble(pos(c, d), label: "\(d)", in: cg) }
        }
    }

    private static func bubble(_ mm: CGPoint, label: String, in cg: CGContext) {
        let r = pt(AppSheetLayout.bubbleMM)
        let c = pt(mm)
        cg.setStrokeColor(UIColor(white: 0.25, alpha: 1).cgColor)
        cg.setLineWidth(0.6)
        cg.strokeEllipse(in: CGRect(x: c.x - r, y: c.y - r, width: 2 * r, height: 2 * r))
        let font = UIFont.systemFont(ofSize: 5.2, weight: .regular)
        let attrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: UIColor(white: 0.62, alpha: 1)]
        let s = label as NSString
        let size = s.size(withAttributes: attrs)
        s.draw(at: CGPoint(x: c.x - size.width / 2, y: c.y - size.height / 2), withAttributes: attrs)
    }

    /// Vẽ chữ; `at` tính bằng mm, là điểm trên–trái (hoặc trên–giữa / trên–phải theo `align`).
    private static func text(_ s: String, at mm: CGPoint, size: CGFloat, weight: UIFont.Weight = .regular,
                             color: UIColor = .black, align: NSTextAlignment = .left, maxWidth: Double = 170) {
        let font = UIFont.systemFont(ofSize: size, weight: weight)
        let para = NSMutableParagraphStyle()
        para.alignment = align
        let attrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: color, .paragraphStyle: para]
        let w = pt(maxWidth)
        let x: CGFloat
        switch align {
        case .center: x = pt(Double(mm.x)) - w / 2
        case .right: x = pt(Double(mm.x)) - w
        default: x = pt(Double(mm.x))
        }
        (s as NSString).draw(in: CGRect(x: x, y: pt(Double(mm.y)), width: w, height: size * 3), withAttributes: attrs)
    }
}

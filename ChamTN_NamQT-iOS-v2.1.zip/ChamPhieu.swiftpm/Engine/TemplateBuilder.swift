import Foundation
import CoreGraphics
import Accelerate
import UIKit
import PDFKit

/// Tạo mẫu phiếu từ ảnh/PDF phiếu trắng (Azota, TNMaker mở rộng, phiếu của trường…).
/// Tự tìm ô vuông định vị và các ô tròn; người dùng khoanh từng vùng, app khớp lưới vào các ô tròn đã tìm thấy.
enum TemplateBuilder {
    struct Mark: Hashable { var x: Double; var y: Double; var size: Double }

    struct Detection {
        var image: GrayImage
        var markers: [Mark]
        var bubbles: [Mark]
        var corners: [Mark]?   // trên–trái, trên–phải, dưới–phải, dưới–trái
        var bubbleSize: Double
    }

    // MARK: Ảnh nguồn

    /// Trang đầu của PDF thành ảnh xám, cạnh dài khoảng 2400 px.
    static func image(fromPDF url: URL) -> GrayImage? {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        guard let doc = PDFDocument(url: url), let page = doc.page(at: 0) else { return nil }
        let box = page.bounds(for: .mediaBox)
        let scale = 2400 / max(box.width, box.height)
        let size = CGSize(width: box.width * scale, height: box.height * scale)
        let img = page.thumbnail(of: size, for: .mediaBox)
        return GrayImage(uiImage: img, maxSide: 2400)
    }

    // MARK: Nhận dạng

    static func detect(_ img: GrayImage) -> Detection {
        let w = img.width, h = img.height, n = w * h
        let rad = max(8, min(w, h) / 40)
        var mean = [UInt8](repeating: 0, count: n)
        var src = img.pixels
        let k = UInt32(2 * rad + 1)
        _ = src.withUnsafeMutableBytes { sb in
            mean.withUnsafeMutableBytes { mb in
                var s = vImage_Buffer(data: sb.baseAddress, height: vImagePixelCount(h), width: vImagePixelCount(w), rowBytes: w)
                var d = vImage_Buffer(data: mb.baseAddress, height: vImagePixelCount(h), width: vImagePixelCount(w), rowBytes: w)
                return vImageBoxConvolve_Planar8(&s, &d, nil, 0, 0, k, k, 0, vImage_Flags(kvImageEdgeExtend))
            }
        }
        var dark = [UInt8](repeating: 0, count: n)
        for i in 0..<n where Double(img.pixels[i]) < Double(mean[i]) * 0.85 { dark[i] = 1 }

        var markers: [Mark] = []
        components(dark, w, h, value: 1) { minX, minY, maxX, maxY, count, _, _ in
            let bw = Double(maxX - minX + 1), bh = Double(maxY - minY + 1)
            let W = Double(w)
            guard bw > 0.006 * W, bw < 0.06 * W, bh > 0.006 * W, bh < 0.06 * W else { return }
            guard max(bw, bh) <= 1.3 * min(bw, bh), Double(count) >= 0.85 * bw * bh else { return }
            markers.append(Mark(x: Double(minX + maxX) / 2, y: Double(minY + maxY) / 2, size: (bw + bh) / 2))
        }

        var holes: [Mark] = []
        components(dark, w, h, value: 0) { minX, minY, maxX, maxY, count, sx, sy in
            guard minX > 0, minY > 0, maxX < w - 1, maxY < h - 1 else { return }
            let bw = Double(maxX - minX + 1), bh = Double(maxY - minY + 1)
            let W = Double(w)
            guard bw > 0.004 * W, bw < 0.04 * W, max(bw, bh) <= 1.35 * min(bw, bh) else { return }
            let fr = Double(count) / (bw * bh)
            guard fr >= 0.45, fr <= 0.86 else { return }
            let cx = sx / Double(count), cy = sy / Double(count)
            let mx = Double(minX + maxX) / 2, my = Double(minY + maxY) / 2
            guard abs(cx - mx) <= 0.15 * bw, abs(cy - my) <= 0.15 * bh else { return }
            holes.append(Mark(x: mx, y: my, size: (bw + bh) / 2))
        }
        // Giữ nhóm kích thước phổ biến nhất (ô tròn), bỏ lỗ của chữ cái
        var bubbleSize = 0.0
        if !holes.isEmpty {
            let logs = holes.map { log($0.size) }
            var best = (0, logs[0])
            for c in logs {
                let k = logs.filter { abs($0 - c) < 0.2 }.count
                if k > best.0 { best = (k, c) }
            }
            let near = logs.filter { abs($0 - best.1) < 0.2 }.sorted()
            bubbleSize = exp(near[near.count / 2])
            holes = holes.filter { $0.size > bubbleSize * 0.6 && $0.size < bubbleSize * 1.45 }
        }
        return Detection(image: img, markers: markers, bubbles: holes, corners: corners(markers), bubbleSize: bubbleSize)
    }

    /// Gán nhãn thành phần liên thông (4 lân cận) cho các điểm có giá trị `value`.
    private static func components(_ mask: [UInt8], _ w: Int, _ h: Int, value: UInt8,
                                   _ visit: (Int, Int, Int, Int, Int, Double, Double) -> Void) {
        var seen = [Bool](repeating: false, count: w * h)
        var stack = [Int32]()
        stack.reserveCapacity(1 << 16)
        mask.withUnsafeBufferPointer { mk in
            seen.withUnsafeMutableBufferPointer { vis in
                for start in 0..<(w * h) where mk[start] == value && !vis[start] {
                    stack.removeAll(keepingCapacity: true)
                    stack.append(Int32(start)); vis[start] = true
                    var minX = Int.max, minY = Int.max, maxX = 0, maxY = 0, count = 0
                    var sx = 0.0, sy = 0.0
                    while let p32 = stack.popLast() {
                        let p = Int(p32), x = p % w, y = p / w
                        count += 1; sx += Double(x); sy += Double(y)
                        minX = min(minX, x); maxX = max(maxX, x); minY = min(minY, y); maxY = max(maxY, y)
                        if x > 0, mk[p - 1] == value, !vis[p - 1] { vis[p - 1] = true; stack.append(Int32(p - 1)) }
                        if x < w - 1, mk[p + 1] == value, !vis[p + 1] { vis[p + 1] = true; stack.append(Int32(p + 1)) }
                        if y > 0, mk[p - w] == value, !vis[p - w] { vis[p - w] = true; stack.append(Int32(p - w)) }
                        if y < h - 1, mk[p + w] == value, !vis[p + w] { vis[p + w] = true; stack.append(Int32(p + w)) }
                    }
                    visit(minX, minY, maxX, maxY, count, sx, sy)
                }
            }
        }
    }

    /// 4 ô vuông lớn ở 4 góc ngoài cùng.
    static func corners(_ markers: [Mark]) -> [Mark]? {
        guard markers.count >= 4 else { return nil }
        let top4 = markers.map(\.size).sorted().suffix(4)
        let ref = top4.sorted()[top4.count / 2]
        let big = markers.filter { $0.size >= 0.6 * ref }
        guard big.count >= 4,
              let tl = big.min(by: { $0.x + $0.y < $1.x + $1.y }),
              let br = big.max(by: { $0.x + $0.y < $1.x + $1.y }),
              let tr = big.max(by: { $0.x - $0.y < $1.x - $1.y }),
              let bl = big.min(by: { $0.x - $0.y < $1.x - $1.y }) else { return nil }
        let set = Set([tl, tr, br, bl])
        return set.count == 4 ? [tl, tr, br, bl] : nil
    }

    // MARK: Khớp lưới

    /// `rect` (pixel): hai góc đi qua tâm ô tròn đầu tiên (trên–trái) và cuối cùng (dưới–phải) của vùng.
    static func fitGrid(_ bubbles: [Mark], rect: CGRect, rows: Int, cols: Int, snap: Bool) -> (xs: [Double], ys: [Double]) {
        let x0 = Double(rect.minX), x1 = Double(rect.maxX), y0 = Double(rect.minY), y1 = Double(rect.maxY)
        func uniform(_ a: Double, _ b: Double, _ k: Int) -> [Double] {
            k == 1 ? [(a + b) / 2] : (0..<k).map { a + (b - a) * Double($0) / Double(k - 1) }
        }
        guard snap else { return (uniform(x0, x1, cols), uniform(y0, y1, rows)) }
        let pad = 0.6 * max((x1 - x0) / Double(max(cols - 1, 1)), (y1 - y0) / Double(max(rows - 1, 1)))
        var inside = bubbles.filter { $0.x > x0 - pad && $0.x < x1 + pad && $0.y > y0 - pad && $0.y < y1 + pad }
        if !inside.isEmpty {
            let med = inside.map(\.size).sorted()[inside.count / 2]
            inside = inside.filter { $0.size > 0.75 * med && $0.size < 1.33 * med }
        }
        let xs = robust(kmeans1D(inside.map(\.x), k: cols, lo: x0, hi: x1), lo: x0, hi: x1)
        let ys = robust(kmeans1D(inside.map(\.y), k: rows, lo: y0, hi: y1), lo: y0, hi: y1)
        return (xs, ys)
    }

    static func kmeans1D(_ vals: [Double], k: Int, lo: Double, hi: Double) -> [Double] {
        var c: [Double] = k == 1 ? [(lo + hi) / 2] : (0..<k).map { lo + (hi - lo) * Double($0) / Double(k - 1) }
        guard !vals.isEmpty else { return c }
        func assign() -> [Int] {
            vals.map { v in c.indices.min { abs(c[$0] - v) < abs(c[$1] - v) } ?? 0 }
        }
        for _ in 0..<15 {
            let a = assign()
            var new = c
            for i in 0..<k {
                let m = vals.indices.filter { a[$0] == i }.map { vals[$0] }
                if !m.isEmpty { new[i] = m.reduce(0, +) / Double(m.count) }
            }
            if zip(new, c).allSatisfy({ abs($0 - $1) < 1e-6 }) { break }
            c = new
        }
        let a = assign()
        let have = (0..<k).map { i in a.contains(i) }
        let haveIdx = (0..<k).filter { have[$0] }
        if haveIdx.count >= 2 && haveIdx.count < k {
            let (s, b) = lineFit(haveIdx.map(Double.init), haveIdx.map { c[$0] })
            for i in 0..<k where !have[i] { c[i] = s * Double(i) + b }
        } else if haveIdx.count < 2 {
            c = k == 1 ? [(lo + hi) / 2] : (0..<k).map { lo + (hi - lo) * Double($0) / Double(k - 1) }
        }
        return c.sorted()
    }

    /// Thay các tâm lệch khỏi đường thẳng (chỉ số → toạ độ) bằng giá trị trên đường thẳng.
    static func robust(_ c: [Double], lo: Double, hi: Double) -> [Double] {
        let k = c.count
        guard k >= 3 else { return c }
        let step = abs(hi - lo) / Double(k - 1)
        var bestInl: [Bool] = Array(repeating: true, count: k)
        var bestCount = -1
        for i in 0..<k {
            for j in (i + 1)..<k {
                let s = (c[j] - c[i]) / Double(j - i), b = c[i] - s * Double(i)
                let inl = (0..<k).map { abs(c[$0] - (s * Double($0) + b)) < 0.2 * step }
                let cnt = inl.filter { $0 }.count
                if cnt > bestCount { bestCount = cnt; bestInl = inl }
            }
        }
        let idx = (0..<k).filter { bestInl[$0] }
        let (s, b) = idx.count >= 2 ? lineFit(idx.map(Double.init), idx.map { c[$0] }) : lineFit((0..<k).map(Double.init), c)
        return (0..<k).map { abs(c[$0] - (s * Double($0) + b)) > 0.2 * step ? s * Double($0) + b : c[$0] }
    }

    static func lineFit(_ x: [Double], _ y: [Double]) -> (Double, Double) {
        let n = Double(x.count)
        let mx = x.reduce(0, +) / n, my = y.reduce(0, +) / n
        var sxy = 0.0, sxx = 0.0
        for (a, b) in zip(x, y) { sxy += (a - mx) * (b - my); sxx += (a - mx) * (a - mx) }
        let s = sxx > 0 ? sxy / sxx : 0
        return (s, my - s * mx)
    }

    // MARK: Ra mẫu phiếu

    struct PixelBlock: Identifiable, Hashable {
        var id = UUID()
        var kind: TemplateSpec.BlockKind
        var first: Int
        var count: Int
        var rect: CGRect
        var snap = true
        var xs: [Double] = []
        var ys: [Double] = []
    }

    static func makeSpec(name: String, detection d: Detection, blocks: [PixelBlock], id: String = "custom-" + UUID().uuidString) -> TemplateSpec? {
        guard let c = d.corners else { return nil }
        let W = hypot(c[1].x - c[0].x, c[1].y - c[0].y)
        let A = hypot(c[3].x - c[0].x, c[3].y - c[0].y) / W
        let src = c.map { CGPoint(x: $0.x, y: $0.y) }
        guard W > 0, let H = Homography.from(src, to: [CGPoint(x: 0, y: 0), CGPoint(x: 1, y: 0), CGPoint(x: 1, y: A), CGPoint(x: 0, y: A)]) else { return nil }
        let markers = d.markers.map { m -> TemplateSpec.Marker in
            let (x, y) = H.apply(m.x, m.y)
            return TemplateSpec.Marker(x: x, y: y, side: m.size / W)
        }
        let specBlocks = blocks.map { b -> TemplateSpec.Block in
            let ym = b.ys.reduce(0, +) / Double(max(b.ys.count, 1)), xm = b.xs.reduce(0, +) / Double(max(b.xs.count, 1))
            return TemplateSpec.Block(kind: b.kind, first: b.first,
                                      xs: b.xs.map { H.apply($0, ym).0 }, ys: b.ys.map { H.apply(xm, $0).1 })
        }
        let r = d.bubbleSize > 0 ? d.bubbleSize / 2 / W : 0.008
        return TemplateSpec(id: id, name: name, note: "Tự tạo từ phiếu trắng", aspect: A, bubbleR: r, markers: markers,
                            blocks: specBlocks, builtin: false, updatedAt: Date())
    }
}

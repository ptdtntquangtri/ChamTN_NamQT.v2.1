import Foundation
import CoreGraphics
import Accelerate
import CoreImage

/// Một ô tròn đã đọc, dùng để vẽ lớp phủ trên ảnh phiếu.
struct CellMark: Codable, Hashable {
    enum Part: String, Codable { case sbd, code, p1, p2, p3 }
    var part: Part
    var question: Int     // số câu (hoặc số cột với SBD/mã đề)
    var item: Int         // P.I: phương án 0–3 · P.II: ý×2 + (0 Đúng, 1 Sai) · P.III: chỉ số ô · SBD/mã đề: chữ số
    var x: Double         // toạ độ sheet
    var y: Double
    var fill: Double      // độ đậm tương đối (0 = giấy trắng, 1 = như ô định vị)
    var filled: Bool
}

/// Kết quả đọc một phiếu.
struct SheetReading {
    var sbd: String
    var code: String
    var p1: [String]   // 40 phần tử: "", "A"…"D", "*" (tô nhiều ô = phạm quy)
    var p2: [String]   // 8 phần tử, mỗi phần tử 4 ký tự: D (Đúng), S (Sai), _ (bỏ trống), * (tô cả hai)
    var p3: [String]   // 6 phần tử: chuỗi đã tô, "*" trong chuỗi = một cột tô nhiều ô
    var cells: [CellMark]
    var corners: [CGPoint]          // toạ độ ảnh: Phần I trái, Phần I phải, Phần III phải, Phần III trái
    var sheetToImage: Homography
    var threshold: Double
    /// Mẫu phiếu thực sự khớp (phiếu Bộ có 2 kiểu in).
    var kind: SheetKind? = nil

    func template(fallback: SheetTemplate) -> SheetTemplate { kind?.template ?? fallback }

    /// Chữ ký để so sánh hai khung hình liên tiếp.
    var signature: String {
        sbd + "|" + code + "|" + p1.joined(separator: ",") + "|" + p2.joined(separator: ",") + "|" + p3.joined(separator: ",")
    }
}

/// Bộ nhận dạng phiếu trả lời trắc nghiệm (OMR) cho mẫu phiếu Bộ GD&ĐT 2025.
///
/// 1. Tìm các khối đen đặc gần vuông (ô định vị) bằng ngưỡng thích nghi + gán nhãn thành phần liên thông.
/// 2. Chọn 2 bộ ba thẳng hàng (trái/phải) có ô giữa nằm ở 61% từ Phần I → Phần III.
/// 3. Tính phép biến đổi phối cảnh, lấy mẫu độ sáng từng ô tròn, ngưỡng tô tính tự động (2-means).
enum OMREngine {
    struct Blob { var x: Double; var y: Double; var area: Double }

    static let fillMinThreshold = 0.18
    static let fillMaxThreshold = 0.5

    // MARK: - Public

    /// Mẫu phiếu Bộ 2025 bản in có 4 ô vuông lớn ở 4 góc (bản phổ biến dùng với QM 2025).
    static let officialCornerSpec = "bgd2025-qm"

    static func read(_ img: GrayImage, template t: SheetTemplate) -> SheetReading? {
        let blobs = findMarkerCandidates(img)
        if let spec = t.spec {
            guard var r = SpecEngine.read(img, spec: spec, candidates: blobs) else { return nil }
            r.kind = t.kind; return r
        }
        if t.kind == .official2025, let spec = TemplateRegistry.shared.spec(officialCornerSpec),
           var r = SpecEngine.read(img, spec: spec, candidates: blobs) {
            r.kind = .spec(id: officialCornerSpec); return r
        }
        guard let quad = pickQuad(blobs, template: t) else { return nil }
        if t.kind == .official2025 && hasForeignBigMarkers(blobs, quad: quad.corners, template: t) { return nil }
        guard var r = decode(img, corners: quad.corners, template: t) else { return nil }
        r.kind = t.kind; return r
    }

    /// Phiếu Bộ (bản ô vuông ở đầu mỗi phần) không có ô vuông nào lớn gấp đôi ô định vị.
    /// Nếu có ≥ 2 ô như vậy quanh phiếu thì đây là phiếu khác (vd. bản có ô vuông lớn ở góc) bị nhận nhầm.
    private static func hasForeignBigMarkers(_ c: [Blob], quad: [CGPoint], template t: SheetTemplate) -> Bool {
        let A = t.aspect
        let sheet = [CGPoint(x: 0, y: 0), CGPoint(x: 1, y: 0), CGPoint(x: 1, y: A), CGPoint(x: 0, y: A)]
        guard let H = Homography.from(sheet, to: quad), let Hi = H.inverse() else { return false }
        let areas: [Double] = quad.map { q in
            let qx = Double(q.x), qy = Double(q.y)
            return c.min(by: { hypot($0.x - qx, $0.y - qy) < hypot($1.x - qx, $1.y - qy) })?.area ?? 0
        }
        let ref = areas.reduce(0, +) / Double(areas.count)
        var big = 0
        for b in c where b.area >= 2.0 * ref {
            let (x, y) = Hi.apply(b.x, b.y)
            if x > -0.4 && x < 1.4 && y > -1.2 * A && y < 2.0 * A { big += 1 }
        }
        return big >= 2
    }

    // MARK: - Bước 1: tìm ứng viên ô định vị

    static func findMarkerCandidates(_ img: GrayImage) -> [Blob] {
        let w = img.width, h = img.height
        guard w > 64, h > 64 else { return [] }
        let rad = max(8, min(w, h) / 16)

        // Mặt nạ điểm tối: g < 0.6 × trung bình cục bộ (lọc hộp bằng vImage cho nhanh)
        let n = w * h
        var mean = [UInt8](repeating: 0, count: n)
        var src = img.pixels
        let k = UInt32(2 * rad + 1)
        let ok: Bool = src.withUnsafeMutableBytes { sb in
            mean.withUnsafeMutableBytes { mb in
                var s = vImage_Buffer(data: sb.baseAddress, height: vImagePixelCount(h), width: vImagePixelCount(w), rowBytes: w)
                var d = vImage_Buffer(data: mb.baseAddress, height: vImagePixelCount(h), width: vImagePixelCount(w), rowBytes: w)
                return vImageBoxConvolve_Planar8(&s, &d, nil, 0, 0, k, k, 0, vImage_Flags(kvImageEdgeExtend)) == kvImageNoError
            }
        }
        guard ok else { return [] }
        var gf = [Float](repeating: 0, count: n), mf = [Float](repeating: 0, count: n), diff = [Float](repeating: 0, count: n)
        vDSP_vfltu8(img.pixels, 1, &gf, 1, vDSP_Length(n))
        vDSP_vfltu8(mean, 1, &mf, 1, vDSP_Length(n))
        var factor: Float = 0.6
        vDSP_vsmsb(mf, 1, &factor, gf, 1, &diff, 1, vDSP_Length(n))   // diff = 0.6·mean − g
        var mask = [UInt8](repeating: 0, count: n)
        diff.withUnsafeBufferPointer { df in
            mask.withUnsafeMutableBufferPointer { mk in
                for i in 0..<n where df[i] > 0 { mk[i] = 1 }
            }
        }

        // Gán nhãn thành phần liên thông (4 lân cận)
        let minDim = Double(min(w, h))
        let minA = max(12.0, pow(minDim * 0.008, 2))
        let maxA = pow(minDim * 0.05, 2)
        var visited = [Bool](repeating: false, count: w * h)
        var stack = [Int32](); stack.reserveCapacity(4096)
        var comp = [Int32](); comp.reserveCapacity(4096)
        var out: [Blob] = []

        mask.withUnsafeBufferPointer { mk in
            visited.withUnsafeMutableBufferPointer { vis in
                for start in 0..<(w * h) where mk[start] == 1 && !vis[start] {
                    stack.removeAll(keepingCapacity: true)
                    comp.removeAll(keepingCapacity: true)
                    stack.append(Int32(start)); vis[start] = true
                    while let p32 = stack.popLast() {
                        let p = Int(p32)
                        comp.append(p32)
                        let x = p % w, y = p / w
                        if x > 0, mk[p - 1] == 1, !vis[p - 1] { vis[p - 1] = true; stack.append(Int32(p - 1)) }
                        if x < w - 1, mk[p + 1] == 1, !vis[p + 1] { vis[p + 1] = true; stack.append(Int32(p + 1)) }
                        if y > 0, mk[p - w] == 1, !vis[p - w] { vis[p - w] = true; stack.append(Int32(p - w)) }
                        if y < h - 1, mk[p + w] == 1, !vis[p + w] { vis[p + w] = true; stack.append(Int32(p + w)) }
                    }
                    let n = Double(comp.count)
                    if n < minA || n > maxA { continue }
                    var sx = 0.0, sy = 0.0
                    for p in comp { sx += Double(Int(p) % w); sy += Double(Int(p) / w) }
                    let cx = sx / n, cy = sy / n
                    var cxx = 0.0, cyy = 0.0, cxy = 0.0, md2 = 0.0
                    for p in comp {
                        let dx = Double(Int(p) % w) - cx, dy = Double(Int(p) / w) - cy
                        cxx += dx * dx; cyy += dy * dy; cxy += dx * dy
                        md2 = max(md2, dx * dx + dy * dy)
                    }
                    cxx /= n; cyy /= n; cxy /= n
                    let tr = cxx + cyy, det = cxx * cyy - cxy * cxy
                    let disc = sqrt(max(0, tr * tr / 4 - det))
                    let l1 = tr / 2 + disc, l2 = tr / 2 - disc
                    guard l1 > 0, l2 / l1 >= 0.45 else { continue }        // gần đẳng hướng
                    guard n / (md2 + 0.5) <= 2.65 else { continue }          // vuông (hình tròn ≈ 3.14, vuông ≈ 2)
                    out.append(Blob(x: cx, y: cy, area: n))
                }
            }
        }
        return out
    }

    // MARK: - Bước 2: chọn 6 ô định vị

    struct Quad { var corners: [CGPoint]; var middles: [CGPoint] }

    static func pickQuad(_ c: [Blob], template t: SheetTemplate) -> Quad? {
        let n = c.count
        guard n >= 6 else { return nil }
        let fr = t.middleFraction, A = t.aspect
        struct Triple { var err: Double; var top: Int; var mid: Int; var bot: Int; var len: Double }
        var triples: [Triple] = []
        for i in 0..<n {
            for j in 0..<n where i != j {
                let ax = c[i].x, ay = c[i].y, bx = c[j].x, by = c[j].y
                let L = hypot(bx - ax, by - ay)
                if L < 20 { continue }
                let mx = ax + (bx - ax) * fr, my = ay + (by - ay) * fr
                var best = -1; var bd = Double.infinity
                for k in 0..<n {
                    let d = hypot(c[k].x - mx, c[k].y - my)
                    if d < bd { bd = d; best = k }
                }
                if best == i || best == j || bd > 0.06 * L { continue }
                let sizes = [c[i].area, c[j].area, c[best].area]
                if sizes.max()! > 2.2 * sizes.min()! { continue }
                let expected = pow(t.markerSide / A * L, 2)
                let mean = sizes.reduce(0, +) / 3
                if !(mean > 0.85 * expected && mean < 2.6 * expected) { continue }
                triples.append(Triple(err: bd / L, top: i, mid: best, bot: j, len: L))
            }
        }
        if triples.count < 2 { return nil }

        func pt(_ i: Int) -> CGPoint { CGPoint(x: c[i].x, y: c[i].y) }
        func angle(_ u: (Double, Double), _ v: (Double, Double)) -> Double {
            let d = (u.0 * v.0 + u.1 * v.1) / (hypot(u.0, u.1) * hypot(v.0, v.1))
            return acos(max(-1, min(1, d))) * 180 / .pi
        }
        let sheetCorners = [CGPoint(x: 0, y: 0), CGPoint(x: 1, y: 0), CGPoint(x: 1, y: A), CGPoint(x: 0, y: A)]
        var best: (Double, Quad)? = nil
        for t1 in triples {
            for t2 in triples {
                let ids: Set<Int> = [t1.top, t1.mid, t1.bot, t2.top, t2.mid, t2.bot]
                if ids.count < 6 { continue }
                let lt = c[t1.top], lb = c[t1.bot], rt = c[t2.top], rb = c[t2.bot]
                let col = ((lb.x - lt.x + rb.x - rt.x) / 2, (lb.y - lt.y + rb.y - rt.y) / 2)
                let row = ((rt.x - lt.x + rb.x - lb.x) / 2, (rt.y - lt.y + rb.y - lb.y) / 2)
                let hl = hypot(col.0, col.1), wl = hypot(row.0, row.1)
                guard wl > 0, hl / wl > A * 0.7, hl / wl < A * 1.4 else { continue }
                let cross = col.0 * row.1 - col.1 * row.0
                if cross >= 0 { continue }   // bộ trái phải nằm bên trái khi nhìn từ trên xuống
                if abs(t1.len - t2.len) > 0.35 * max(t1.len, t2.len) { continue }
                // Kích thước hai bên phải phù hợp với phối cảnh
                let areaL = (c[t1.top].area + c[t1.mid].area + c[t1.bot].area) / 3
                let areaR = (c[t2.top].area + c[t2.mid].area + c[t2.bot].area) / 3
                let expRatio = pow(t2.len / t1.len, 2)
                let ratio = areaR / areaL
                if ratio > expRatio * 1.8 || ratio < expRatio / 1.8 { continue }
                if angle((rt.x - lt.x, rt.y - lt.y), (rb.x - lb.x, rb.y - lb.y)) > 20 { continue }
                if angle((lb.x - lt.x, lb.y - lt.y), (rb.x - rt.x, rb.y - rt.y)) > 20 { continue }
                if abs(90 - angle(row, col)) > 25 { continue }
                let corners = [pt(t1.top), pt(t2.top), pt(t2.bot), pt(t1.bot)]
                guard let H = Homography.from(sheetCorners, to: corners) else { continue }
                var e = 0.0
                for (u, k) in [(0.0, t1.mid), (1.0, t2.mid)] {
                    let p = H.apply(CGPoint(x: u, y: fr * A))
                    e += hypot(Double(p.x) - c[k].x, Double(p.y) - c[k].y) / wl
                }
                let score = e + 0.2 * (t1.err + t2.err)
                if best == nil || score < best!.0 {
                    best = (score, Quad(corners: corners, middles: [pt(t1.mid), pt(t2.mid)]))
                }
            }
        }
        if let b = best, b.0 < 0.05 { return b.1 }
        return nil
    }

    // MARK: - Bước 3: đọc ô tô

    static func decode(_ img: GrayImage, corners: [CGPoint], template t: SheetTemplate) -> SheetReading? {
        let A = t.aspect
        let sheetCorners = [CGPoint(x: 0, y: 0), CGPoint(x: 1, y: 0), CGPoint(x: 1, y: A), CGPoint(x: 0, y: A)]
        guard let H = Homography.from(sheetCorners, to: corners) else { return nil }

        // Lưới điểm lấy mẫu trong 55% bán kính ô tròn
        let rr = t.bubbleRadius * 0.55
        var offsets: [(Double, Double)] = []
        for i in 0..<5 {
            for j in 0..<5 {
                let dx = -rr + Double(i) * rr / 2, dy = -rr + Double(j) * rr / 2
                if dx * dx + dy * dy <= rr * rr * 1.05 { offsets.append((dx, dy)) }
            }
        }
        func sample(_ p: CGPoint) -> Double {
            var s = 0.0
            for (dx, dy) in offsets {
                let (x, y) = H.apply(Double(p.x) + dx, Double(p.y) + dy)
                s += Double(img.pixel(Int(x.rounded()), Int(y.rounded())))
            }
            return s / Double(offsets.count)
        }
        let dark = sheetCorners.map(sample).reduce(0, +) / 4

        func block(_ pts: [CGPoint]) -> [Double] {
            let vals = pts.map(sample)
            let paper = percentile(vals, 0.75)
            let denom = max(paper - dark, 20)
            return vals.map { (paper - $0) / denom }
        }

        // Ô của từng nhóm
        let p1Q = t.p1Groups, p2Q = t.p2Groups
        let p1Groups: [[CGPoint]] = p1Q.map { qs in qs.flatMap { q in (0..<4).map { t.p1(q, $0) } } }
        let p2Groups: [[CGPoint]] = p2Q.map { qs in qs.flatMap { q in (0..<4).flatMap { i in (0..<2).map { t.p2(q, i, $0) } } } }
        let p3Groups: [[CGPoint]] = (0..<t.p3Cap).map { qi in SheetTemplate.p3Cells.map { t.p3(qi + 1, $0.row, $0.col) } }
        var sbdPts: [CGPoint] = [], codePts: [CGPoint] = []
        for c in 0..<t.sbdDigits { for d in 0..<10 { sbdPts.append(t.sbd(c, d)) } }
        for c in 0..<t.codeDigits { for d in 0..<10 { codePts.append(t.code(c, d)) } }

        let p1F = p1Groups.map(block), p2F = p2Groups.map(block), p3F = p3Groups.map(block)
        let sbdF = block(sbdPts), codeF = block(codePts)

        // Ngưỡng tô chung (2-means trên toàn bộ ô trả lời)
        let allF = (p1F + p2F + p3F).flatMap { $0 }
        let T = twoMeansThreshold(allF)

        var cells: [CellMark] = []
        func digits(_ f: [Double], _ pts: [CGPoint], ncol: Int, part: CellMark.Part) -> String {
            var s = ""
            for c in 0..<ncol {
                var on: [Int] = []
                for d in 0..<10 {
                    let v = f[c * 10 + d]
                    let filled = v > T
                    if filled { on.append(d) }
                    cells.append(CellMark(part: part, question: c + 1, item: d, x: Double(pts[c * 10 + d].x), y: Double(pts[c * 10 + d].y), fill: v, filled: filled))
                }
                if on.count == 1 { s += String(on[0]) } else if on.count > 1 { s += "?" }
            }
            return s
        }
        let sbd = digits(sbdF, sbdPts, ncol: t.sbdDigits, part: .sbd)
        let code = digits(codeF, codePts, ncol: t.codeDigits, part: .code)

        var p1: [String] = []
        let letters = ["A", "B", "C", "D"]
        for b in 0..<p1Q.count {
            for r in 0..<p1Q[b].count {
                var on: [Int] = []
                for k in 0..<4 {
                    let v = p1F[b][r * 4 + k], filled = v > T
                    if filled { on.append(k) }
                    let p = p1Groups[b][r * 4 + k]
                    cells.append(CellMark(part: .p1, question: p1Q[b][r], item: k, x: Double(p.x), y: Double(p.y), fill: v, filled: filled))
                }
                p1.append(on.isEmpty ? "" : (on.count == 1 ? letters[on[0]] : "*"))
            }
        }
        var p2: [String] = []
        for b in 0..<p2Q.count {
            for qi in 0..<p2Q[b].count {
                var s = ""
                for i in 0..<4 {
                    let di = qi * 8 + i * 2
                    let dv = p2F[b][di], sv = p2F[b][di + 1]
                    let dOn = dv > T, sOn = sv > T
                    s += dOn && sOn ? "*" : (dOn ? "D" : (sOn ? "S" : "_"))
                    for (idx, v, on) in [(di, dv, dOn), (di + 1, sv, sOn)] {
                        let p = p2Groups[b][idx]
                        cells.append(CellMark(part: .p2, question: p2Q[b][qi], item: idx - qi * 8, x: Double(p.x), y: Double(p.y), fill: v, filled: on))
                    }
                }
                p2.append(s)
            }
        }
        var p3: [String] = []
        for q in 0..<t.p3Cap {
            var cols: [[Character]] = [[], [], [], []]
            for (idx, cell) in SheetTemplate.p3Cells.enumerated() {
                let v = p3F[q][idx], on = v > T
                if on { cols[cell.col].append(cell.symbol) }
                let p = p3Groups[q][idx]
                cells.append(CellMark(part: .p3, question: q + 1, item: idx, x: Double(p.x), y: Double(p.y), fill: v, filled: on))
            }
            var s = ""
            for col in cols where !col.isEmpty { s.append(col.count > 1 ? "*" : col[0]) }
            p3.append(s)
        }

        // Kiểm tra hợp lý: phiếu lệch khung thường cho ra rất nhiều câu tô nhiều ô
        let multi = p1.filter { $0 == "*" }.count + p2.filter { $0.contains("*") }.count
        if multi > 12 { return nil }

        return SheetReading(sbd: sbd, code: code, p1: p1, p2: p2, p3: p3, cells: cells,
                            corners: corners, sheetToImage: H, threshold: T)
    }

    static func percentile(_ v: [Double], _ q: Double) -> Double {
        guard !v.isEmpty else { return 0 }
        let s = v.sorted()
        let pos = q * Double(s.count - 1)
        let lo = Int(floor(pos)), hi = Int(ceil(pos))
        return s[lo] + (s[hi] - s[lo]) * (pos - Double(lo))
    }

    static func twoMeansThreshold(_ f: [Double]) -> Double {
        guard let mx = f.max() else { return fillMaxThreshold }
        var c0 = percentile(f, 0.3), c1 = mx
        for _ in 0..<10 {
            let t = (c0 + c1) / 2
            let lo = f.filter { $0 < t }, hi = f.filter { $0 >= t }
            if lo.isEmpty || hi.isEmpty { break }
            c0 = lo.reduce(0, +) / Double(lo.count)
            c1 = hi.reduce(0, +) / Double(hi.count)
        }
        if c1 - c0 < 0.15 { return fillMaxThreshold }
        return min(max((c0 + c1) / 2, fillMinThreshold), fillMaxThreshold)
    }

    // MARK: - Ảnh nắn thẳng để lưu

    static let ciContext = CIContext(options: [.useSoftwareRenderer: false])

    /// Nắn thẳng vùng phiếu (dùng GPU qua Core Image; nếu lỗi thì tính bằng CPU).
    static func rectify(_ img: GrayImage, sheetToImage H: Homography, template t: SheetTemplate, width: Int = 1000) -> GrayImage {
        let r = t.rectifyRect
        let scale = Double(width) / Double(r.width)
        let height = Int(Double(r.height) * scale)
        if let cg = img.cgImage() {
            let ci = CIImage(cgImage: cg)
            let ih = Double(img.height)
            func p(_ x: CGFloat, _ y: CGFloat) -> CGPoint {
                let q = H.apply(CGPoint(x: x, y: y))
                return CGPoint(x: q.x, y: CGFloat(ih) - q.y) // Core Image: gốc toạ độ ở dưới
            }
            let f = CIFilter(name: "CIPerspectiveCorrection")
            f?.setValue(ci, forKey: kCIInputImageKey)
            f?.setValue(CIVector(cgPoint: p(r.minX, r.minY)), forKey: "inputTopLeft")
            f?.setValue(CIVector(cgPoint: p(r.maxX, r.minY)), forKey: "inputTopRight")
            f?.setValue(CIVector(cgPoint: p(r.maxX, r.maxY)), forKey: "inputBottomRight")
            f?.setValue(CIVector(cgPoint: p(r.minX, r.maxY)), forKey: "inputBottomLeft")
            if let out = f?.outputImage, out.extent.width > 1, out.extent.height > 1 {
                let sx = CGFloat(width) / out.extent.width, sy = CGFloat(height) / out.extent.height
                let scaled = out.transformed(by: CGAffineTransform(translationX: -out.extent.minX, y: -out.extent.minY))
                    .transformed(by: CGAffineTransform(scaleX: sx, y: sy))
                var px = [UInt8](repeating: 255, count: width * height)
                px.withUnsafeMutableBytes { buf in
                    ciContext.render(scaled, toBitmap: buf.baseAddress!, rowBytes: width,
                                     bounds: CGRect(x: 0, y: 0, width: width, height: height),
                                     format: .L8, colorSpace: CGColorSpaceCreateDeviceGray())
                }
                return GrayImage(width: width, height: height, pixels: px)
            }
        }
        var px = [UInt8](repeating: 255, count: width * height)
        for y in 0..<height {
            let sy = Double(r.minY) + (Double(y) + 0.5) / scale
            for x in 0..<width {
                let sx = Double(r.minX) + (Double(x) + 0.5) / scale
                let (ix, iy) = H.apply(sx, sy)
                if ix < 0 || iy < 0 || ix >= Double(img.width - 1) || iy >= Double(img.height - 1) { continue }
                px[y * width + x] = UInt8(max(0, min(255, img.bilinear(ix, iy))))
            }
        }
        return GrayImage(width: width, height: height, pixels: px)
    }

    /// Đổi toạ độ sheet → toạ độ ảnh nắn thẳng (pixel).
    static func rectifiedPoint(_ x: Double, _ y: Double, template t: SheetTemplate, width: Int = 1000) -> CGPoint {
        let r = t.rectifyRect
        let scale = Double(width) / Double(r.width)
        return CGPoint(x: (x - Double(r.minX)) * scale, y: (y - Double(r.minY)) * scale)
    }
}

import Foundation

struct GradeResult: Hashable {
    var score: Double            // điểm thô trắc nghiệm
    var score10: Double          // tổng điểm hiển thị (đã quy đổi + cộng tự luận + làm tròn)
    var p1Score: Double, p2Score: Double, p3Score: Double
    var p1Correct: Int, p3Correct: Int
    var p2Items: Int             // tổng số ý Phần II đúng
    var invalid: Int             // số câu phạm quy (tô nhiều ô)
    var p1Status: [Bool?]        // true đúng, false sai, nil bỏ trống
    var p2Status: [[Bool?]]
    var p3Status: [Bool?]
    var mcqScore: Double = 0     // điểm trắc nghiệm (đã quy đổi nếu bật)
    var essayScore: Double = 0   // điểm tự luận
}

enum Grader {
    static func grade(p1: [String], p2: [String], p3: [String], key: AnswerKey, config: ExamConfig, essayScore: Double? = nil) -> GradeResult {
        var invalid = 0
        var p1Correct = 0
        var p1Status: [Bool?] = []
        for i in 0..<config.p1Count {
            let s = i < p1.count ? p1[i] : ""
            let k = i < key.p1.count ? key.p1[i] : ""
            if s == "*" { invalid += 1 }
            if s.isEmpty { p1Status.append(nil); continue }
            let ok = s == k && !k.isEmpty
            if ok { p1Correct += 1 }
            p1Status.append(ok)
        }
        var p2Score = 0.0, p2Items = 0
        var p2Status: [[Bool?]] = []
        for q in 0..<config.p2Count {
            let s = Array(q < p2.count ? p2[q] : "____")
            let k = Array(q < key.p2.count ? key.p2[q] : "____")
            var correct = 0
            var st: [Bool?] = []
            for i in 0..<4 {
                let sc: Character = i < s.count ? s[i] : "_"
                let kc: Character = i < k.count ? k[i] : "_"
                if sc == "*" { invalid += 1 }
                if sc == "_" { st.append(nil); continue }
                let ok = sc == kc && (kc == "D" || kc == "S")
                if ok { correct += 1 }
                st.append(ok)
            }
            p2Items += correct
            if correct > 0, correct <= config.p2Scale.count { p2Score += config.p2Scale[correct - 1] }
            p2Status.append(st)
        }
        var p3Correct = 0
        var p3Status: [Bool?] = []
        for q in 0..<config.p3Count {
            let s = q < p3.count ? p3[q] : ""
            let k = q < key.p3.count ? key.p3[q] : ""
            if s.contains("*") { invalid += 1 }
            if s.isEmpty { p3Status.append(nil); continue }
            let ok = shortAnswerEqual(s, k)
            if ok { p3Correct += 1 }
            p3Status.append(ok)
        }
        let p1Score = Double(p1Correct) * config.p1Point
        let p3Score = Double(p3Correct) * config.p3Point
        let raw = p1Score + p2Score + p3Score
        let mcqTarget = config.scaleTo10 ? max(0, 10 - config.essayMax) : config.maxScore
        let mcqShown = config.scaleTo10 && config.maxScore > 0 ? raw / config.maxScore * mcqTarget : raw
        let essay = config.essayMax > 0 ? min(max(0, essayScore ?? 0), config.essayMax) : 0
        let total = applyRound(mcqShown + essay, mode: config.effectiveRoundMode)
        return GradeResult(score: raw, score10: total, p1Score: p1Score, p2Score: p2Score, p3Score: p3Score,
                           p1Correct: p1Correct, p3Correct: p3Correct, p2Items: p2Items, invalid: invalid,
                           p1Status: p1Status, p2Status: p2Status, p3Status: p3Status,
                           mcqScore: round2(mcqShown), essayScore: round2(essay))
    }

    static func grade(_ r: ScanRecord, exam: Exam) -> GradeResult? {
        guard let key = exam.key(for: r.code) else { return nil }
        return grade(p1: r.p1, p2: r.p2, p3: r.p3, key: key, config: exam.config, essayScore: r.essayScore)
    }

    static func applyRound(_ v: Double, mode: RoundMode) -> Double {
        let step = mode.step
        return round2((v / step).rounded() * step)
    }

    /// Chuẩn hoá đáp án trả lời ngắn: "." → ",", bỏ khoảng trắng.
    static func normalizeShort(_ s: String) -> String {
        s.replacingOccurrences(of: ".", with: ",").replacingOccurrences(of: " ", with: "")
    }

    /// So sánh đáp án trả lời ngắn: trùng chuỗi, hoặc cùng giá trị số (1,50 = 1,5).
    static func shortAnswerEqual(_ student: String, _ key: String) -> Bool {
        let a = normalizeShort(student), b = normalizeShort(key)
        if a.isEmpty || b.isEmpty || a.contains("*") { return false }
        if a == b { return true }
        if let x = Decimal(string: a.replacingOccurrences(of: ",", with: "."), locale: Locale(identifier: "en_US_POSIX")),
           let y = Decimal(string: b.replacingOccurrences(of: ",", with: "."), locale: Locale(identifier: "en_US_POSIX")),
           isNumeric(a), isNumeric(b) {
            return x == y
        }
        return false
    }

    private static func isNumeric(_ s: String) -> Bool {
        s.range(of: #"^-?[0-9]*,?[0-9]+$|^-?[0-9]+,?$"#, options: .regularExpression) != nil
    }

    static func round2(_ v: Double) -> Double { (v * 100).rounded() / 100 }

    static func format(_ v: Double) -> String {
        let f = NumberFormatter()
        f.locale = Locale(identifier: "vi_VN")
        f.minimumFractionDigits = 0
        f.maximumFractionDigits = 2
        return f.string(from: NSNumber(value: v)) ?? String(v)
    }
}

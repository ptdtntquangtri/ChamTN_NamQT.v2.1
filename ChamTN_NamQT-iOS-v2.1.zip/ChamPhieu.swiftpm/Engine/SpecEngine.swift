import Foundation
import CoreGraphics

/// Đọc phiếu theo mẫu dữ liệu (`TemplateSpec`): TNMaker, Azota, phiếu tự tạo.
///
/// 1. Mỗi cặp ứng viên ô vuông (i, j) được thử làm cạnh trên của phiếu (trên–trái → trên–phải);
///    suy ra vị trí hai góc dưới, tìm ô vuông gần đó.
/// 2. Với mỗi bộ 4 góc, chiếu toàn bộ ô định vị của mẫu lên ảnh và đếm số ô khớp (vị trí + kích thước).
/// 3. Chọn bộ khớp nhiều nhất (≥ 60% ô định vị, đủ 4 góc), tinh chỉnh phép biến đổi bằng tất cả ô khớp.
/// 4. Lấy mẫu độ sáng từng ô tô, ngưỡng tô tính tự động giống phiếu của Bộ.
enum SpecEngine {
    static func read(_ img: GrayImage, spec: TemplateSpec, candidates: [OMREngine.Blob]) -> SheetReading? {
        guard let (H, corners) = locate(candidates, spec: spec, minDim: Double(min(img.width, img.height))) else { return nil }
        return decode(img, spec: spec, H: H, corners: corners)
    }

    static func locate(_ cands: [OMREngine.Blob], spec: TemplateSpec, minDim: Double) -> (Homography, [CGPoint])? {
        // Giữ tối đa 90 ứng viên lớn nhất để giới hạn thời gian
        let c = cands.count > 90 ? Array(cands.sorted { $0.area > $1.area }.prefix(90)) : cands
        let n = c.count
        guard n >= 4, spec.markers.count >= 4 else { return nil }
        let A = spec.aspect
        let ci = spec.cornerIndices
        let side = ci.map { spec.markers[$0].side }.reduce(0, +) / 4
        let sheetC = [CGPoint(x: 0, y: 0), CGPoint(x: 1, y: 0), CGPoint(x: 1, y: A), CGPoint(x: 0, y: A)]
        let M = spec.markers

        var bestScore = -1.0, bestErr = Double.infinity
        var bestMatched: [(Int, Int)] = []

        search: for i in 0..<n {
            for j in 0..<n where i != j {
                let vx = c[j].x - c[i].x, vy = c[j].y - c[i].y
                let L = hypot(vx, vy)
                if L < 40 || L < 0.25 * minDim { continue }
                let exp = pow(side * L, 2)
                guard c[i].area > 0.35 * exp, c[i].area < 2.8 * exp, c[j].area > 0.35 * exp, c[j].area < 2.8 * exp else { continue }
                let dx = -vy * A, dy = vx * A
                let preds = [(c[j].x + dx, c[j].y + dy), (c[i].x + dx, c[i].y + dy)]
                // Ứng viên góc dưới: trong bán kính dự đoán, ưu tiên kích thước gần ô góc nhất
                var opts: [[Int]] = []
                for (px, py) in preds {
                    var near: [(Double, Int)] = []
                    for k in 0..<n where k != i && k != j {
                        let d = hypot(c[k].x - px, c[k].y - py)
                        if d < 0.5 * L && c[k].area > 0.3 * exp && c[k].area < 3.2 * exp { near.append((abs(log(c[k].area / exp)), k)) }
                    }
                    near.sort { $0.0 < $1.0 }
                    opts.append(near.prefix(4).map(\.1))
                }
                for k0 in opts[0] {
                    for k1 in opts[1] where k1 != k0 {
                        let quad = [CGPoint(x: c[i].x, y: c[i].y), CGPoint(x: c[j].x, y: c[j].y),
                                    CGPoint(x: c[k0].x, y: c[k0].y), CGPoint(x: c[k1].x, y: c[k1].y)]
                        guard let H = Homography.from(sheetC, to: quad) else { continue }
                        var matched: [(Int, Int)] = []
                        var err = 0.0
                        for (mi, m) in M.enumerated() {
                            let (px, py) = H.apply(m.x, m.y)
                            var bd = Double.infinity, bk = -1
                            for k in 0..<n {
                                let d = hypot(c[k].x - px, c[k].y - py)
                                if d < bd { bd = d; bk = k }
                            }
                            let es = pow(m.side * L, 2)
                            if bk >= 0, bd < 0.025 * L, c[bk].area > 0.3 * es, c[bk].area < 3.2 * es {
                                matched.append((mi, bk)); err += bd / L
                            }
                        }
                        let raw = Double(matched.count) / Double(M.count)
                        // Phạt khi còn ô vuông lớn nằm ngoài phiếu: bộ 4 góc sai thường bỏ sót góc thật ở ngoài
                        var outside = 0
                        if let Hi = H.inverse() {
                            for k in 0..<n where c[k].area >= 0.5 * exp {
                                let (u, w) = Hi.apply(c[k].x, c[k].y)
                                let out = u < -0.03 || u > 1.03 || w < -0.03 || w > A + 0.03
                                let near = u > -0.5 && u < 1.5 && w > -0.5 && w < A + 0.5
                                if out && near { outside += 1 }
                            }
                        }
                        let score = raw - 0.1 * Double(outside)
                        let meanErr = err / Double(max(matched.count, 1))
                        if score > bestScore || (score == bestScore && meanErr < bestErr) {
                            bestScore = score; bestErr = meanErr; bestMatched = matched
                            if raw >= 1, outside == 0, meanErr < 0.004 { break search }   // khớp hoàn hảo: dừng sớm
                        }
                    }
                }
            }
        }
        guard Double(bestMatched.count) / Double(M.count) >= 0.6, bestMatched.count >= 4 else { return nil }
        let mids = Set(bestMatched.map(\.0))
        guard ci.allSatisfy({ mids.contains($0) }) else { return nil }
        // Ô định vị không có ô đối xứng khi xoay 180°: phải khớp ít nhất một nửa, để không đọc ngược phiếu
        let disc = discriminating(spec)
        if !disc.isEmpty && disc.filter({ mids.contains($0) }).count * 2 < disc.count { return nil }
        let src = bestMatched.map { CGPoint(x: M[$0.0].x, y: M[$0.0].y) }
        let dst = bestMatched.map { CGPoint(x: c[$0.1].x, y: c[$0.1].y) }
        guard let H = Homography.fit(src, to: dst) else { return nil }
        let corners = sheetC.map { H.apply($0) }
        return (H, corners)
    }

    /// Chỉ số các ô định vị không trùng với ô nào khi xoay phiếu 180°.
    static func discriminating(_ spec: TemplateSpec) -> [Int] {
        let A = spec.aspect
        return spec.markers.indices.filter { i in
            let rx = 1 - spec.markers[i].x, ry = A - spec.markers[i].y
            return !spec.markers.contains { hypot($0.x - rx, $0.y - ry) < 0.025 }
        }
    }

    static func decode(_ img: GrayImage, spec: TemplateSpec, H: Homography, corners: [CGPoint]) -> SheetReading? {
        let rr = spec.bubbleR * 0.55
        var offsets: [(Double, Double)] = []
        for i in 0..<5 {
            for j in 0..<5 {
                let dx = -rr + Double(i) * rr / 2, dy = -rr + Double(j) * rr / 2
                if dx * dx + dy * dy <= rr * rr * 1.05 { offsets.append((dx, dy)) }
            }
        }
        func sample(_ x: Double, _ y: Double) -> Double {
            var s = 0.0
            for (dx, dy) in offsets {
                let (ix, iy) = H.apply(x + dx, y + dy)
                s += Double(img.pixel(Int(ix.rounded()), Int(iy.rounded())))
            }
            return s / Double(offsets.count)
        }
        let dark = spec.cornerIndices.map { sample(spec.markers[$0].x, spec.markers[$0].y) }.reduce(0, +) / 4
        let cells = spec.cells()
        let values = cells.map { sample($0.x, $0.y) }
        // Chuẩn hoá theo từng vùng
        var fill = [Double](repeating: 0, count: cells.count)
        var byBlock: [Int: [Int]] = [:]
        for (i, c) in cells.enumerated() { byBlock[c.block, default: []].append(i) }
        for idxs in byBlock.values {
            let v = idxs.map { values[$0] }
            let paper = OMREngine.percentile(v, 0.75)
            let denom = max(paper - dark, 20)
            for i in idxs { fill[i] = (paper - values[i]) / denom }
        }
        let answerFill = cells.indices.filter { [.p1, .p2, .p3].contains(cells[$0].kind) }.map { fill[$0] }
        let T = OMREngine.twoMeansThreshold(answerFill.isEmpty ? fill : answerFill)

        let caps = spec.caps
        var p1 = [String](repeating: "", count: caps.p1)
        var p2 = [String](repeating: "____", count: caps.p2)
        var p3 = [String](repeating: "", count: caps.p3)
        var digits: [TemplateSpec.BlockKind: [Int: [Int]]] = [.sbd: [:], .code: [:]]
        var p1On: [Int: [Int]] = [:]
        var p2On: [Int: Set<Int>] = [:]
        var p3On: [Int: [[Character]]] = [:]
        var marks: [CellMark] = []
        for (i, c) in cells.enumerated() {
            let on = fill[i] > T
            let part: CellMark.Part
            switch c.kind {
            case .p1: part = .p1; p1On[c.question, default: []] += on ? [c.item] : []
            case .p2: part = .p2; if on { p2On[c.question, default: []].insert(c.item) }
            case .p3:
                part = .p3
                if p3On[c.question] == nil { p3On[c.question] = [[], [], [], []] }
                if on { let cell = SheetTemplate.p3Cells[c.item]; p3On[c.question]![cell.col].append(cell.symbol) }
            case .sbd: part = .sbd; digits[.sbd]![c.question, default: []] += on ? [c.item] : []
            case .code: part = .code; digits[.code]![c.question, default: []] += on ? [c.item] : []
            }
            marks.append(CellMark(part: part, question: c.question, item: c.item, x: c.x, y: c.y, fill: fill[i], filled: on))
        }
        func digitString(_ k: TemplateSpec.BlockKind) -> String {
            let d = digits[k] ?? [:]
            var s = ""
            for q in d.keys.sorted() {
                let on = d[q] ?? []
                if on.count == 1 { s += String(on[0]) } else if on.count > 1 { s += "?" }
            }
            return s
        }
        let letters = ["A", "B", "C", "D", "E"]
        for (q, on) in p1On where q >= 1 && q <= p1.count {
            p1[q - 1] = on.isEmpty ? "" : (on.count == 1 && on[0] < letters.count ? letters[on[0]] : "*")
        }
        for (q, on) in p2On where q >= 1 && q <= p2.count {
            var s = ""
            for i in 0..<4 {
                let d = on.contains(i * 2), sa = on.contains(i * 2 + 1)
                s += d && sa ? "*" : (d ? "D" : (sa ? "S" : "_"))
            }
            p2[q - 1] = s
        }
        for (q, cols) in p3On where q >= 1 && q <= p3.count {
            var s = ""
            for col in cols where !col.isEmpty { s.append(col.count > 1 ? "*" : col[0]) }
            p3[q - 1] = s
        }
        let multi = p1.filter { $0 == "*" }.count + p2.filter { $0.contains("*") }.count
        if multi > max(12, caps.p1 / 4) { return nil }
        return SheetReading(sbd: digitString(.sbd), code: digitString(.code), p1: p1, p2: p2, p3: p3, cells: marks,
                            corners: corners, sheetToImage: H, threshold: T)
    }
}

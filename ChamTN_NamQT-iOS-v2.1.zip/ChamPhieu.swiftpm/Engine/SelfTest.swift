import Foundation
import CoreGraphics

/// Kiểm tra nhanh logic chấm điểm và đọc đáp án (chạy trong mục Cài đặt).
enum SelfTest {
    static func run() -> String {
        var fails: [String] = []
        func check(_ cond: Bool, _ name: String) { if !cond { fails.append(name) } }

        let toan = Subject.toan.preset
        let key = AnswerKey(code: "0101",
                            p1: ["B", "A", "B", "C", "B", "A", "B", "B", "A", "D", "D", "A"],
                            p2: ["DSSD", "DSDD", "DSSD", "DSSS"],
                            p3: ["1808", "95,3", "3360", "2,45", "2150", "2016"])
        // Bài đúng hoàn toàn → 10 điểm
        let full = Grader.grade(p1: key.p1, p2: key.p2, p3: key.p3, key: key, config: toan)
        check(abs(full.score - 10) < 1e-9, "Toán đúng hết = 10 (được \(full.score))")
        // Phần II: đúng 1, 2, 3, 0 ý
        let g2 = Grader.grade(p1: [], p2: ["DDDD", "DSSS", "DSDS", "SDSS"], p3: [], key: key, config: toan)
        // câu1 DSSD vs DDDD: đúng a,d = 2 ý → 0.25; câu2 DSDD vs DSSS: a,b,d? key DSDD, sv DSSS → a,b đúng; c sai; d sai → 2 ý → 0.25
        // câu3 DSSD vs DSDS: a,b đúng → 0.25; câu4 DSSS vs SDSS: c,d đúng → 0.25
        check(abs(g2.p2Score - 1.0) < 1e-9, "Phần II 4×2 ý = 1,0 (được \(g2.p2Score))")
        let g3 = Grader.grade(p1: [], p2: ["DSS_", "D___", "____", "SDDD"], p3: [], key: key, config: toan)
        check(abs(g3.p2Score - (0.5 + 0.1 + 0)) < 1e-9, "Phần II 3 ý + 1 ý = 0,6 (được \(g3.p2Score))")
        // Phạm quy
        let g4 = Grader.grade(p1: ["*", "A"], p2: [], p3: [], key: key, config: toan)
        check(g4.invalid == 1 && g4.p1Correct == 1, "Phạm quy Phần I")
        // Trả lời ngắn
        check(Grader.shortAnswerEqual("2,45", "2.45"), "2,45 = 2.45")
        check(Grader.shortAnswerEqual("1,50", "1,5"), "1,50 = 1,5")
        check(!Grader.shortAnswerEqual("-1,5", "1,5"), "-1,5 ≠ 1,5")
        check(!Grader.shortAnswerEqual("1*5", "1,5"), "ô tô nhiều ký tự")
        // Đọc đáp án dán từ Excel
        let text = "Mã đề\tI.1\n0101\tBABCBABBADDA\tĐSSĐ ĐSĐĐ ĐSSĐ ĐSSS\t1808|95,3|3360|2,45|2150|2016\n"
        if let k = try? AnswerKeyIO.parse(text, config: toan).first {
            check(k.p1 == key.p1 && k.p2 == key.p2 && k.p3 == key.p3, "Dán đáp án dạng gộp")
        } else { fails.append("Dán đáp án dạng gộp (lỗi đọc)") }
        let cells = (["0102"] + key.p1 + ["Đ S S Đ", "ĐSĐĐ", "dssd", "đsss"] + key.p3).joined(separator: "\t")
        if let k = try? AnswerKeyIO.parse(cells, config: toan).first {
            check(k.code == "0102" && k.p1 == key.p1 && k.p2 == key.p2 && k.p3 == key.p3, "Dán đáp án mỗi câu một ô")
        } else { fails.append("Dán đáp án mỗi câu một ô (lỗi đọc)") }
        // QR khứ hồi
        var exam = Exam(name: "Thử", config: toan)
        exam.keys = [key]
        if let s = AnswerKeyIO.qrString(exam: exam), let d = AnswerKeyIO.decodeQR(s) {
            check(d.keys.first?.p1 == key.p1 && d.keys.first?.p2 == key.p2 && d.keys.first?.p3 == key.p3, "QR khứ hồi")
        } else { fails.append("QR khứ hồi") }
        // Excel .xlsx: ghi rồi đọc lại
        let xdata = AnswerKeyIO.templateXLSX(config: toan, keys: [key])
        if let rows = try? XLSX.readFirstSheet(xdata), let k = try? AnswerKeyIO.parse(XLSX.tsv(rows), config: toan).first {
            check(k.code == "0101" && k.p1 == key.p1 && k.p2 == key.p2 && k.p3 == key.p3, "Excel .xlsx khứ hồi")
        } else { fails.append("Excel .xlsx khứ hồi (lỗi đọc)") }
        check(XLSX.columnIndex("AB12") == 28 && XLSX.columnName(28) == "AB", "Tên cột Excel")
        check(XLSX.cleanNumber("2.4500000000000002") == "2.45" && XLSX.cleanNumber("101.0") == "101", "Số Excel")
        // Phiếu in từ app: các ô không chồng lên nhau và nằm trong 6 ô định vị
        let lay = AppSheetLayout(p1: 40, p2: 8, p3: 6)
        check(lay.fits && !AppSheetLayout(p1: 100, p2: 10, p3: 12).fits, "Giới hạn phiếu in từ app")
        let t = SheetKind.app(p1: 40, p2: 8, p3: 6).template
        var pts: [CGPoint] = []
        for q in 1...40 { for k in 0..<4 { pts.append(t.p1(q, k)) } }
        for q in 1...8 { for i in 0..<4 { for d in 0..<2 { pts.append(t.p2(q, i, d)) } } }
        for q in 1...6 { for c in SheetTemplate.p3Cells { pts.append(t.p3(q, c.row, c.col)) } }
        let inside = pts.allSatisfy { $0.x > 0.02 && $0.x < 0.98 && $0.y > 0.02 && $0.y < t.aspect - 0.02 }
        var minD = Double.infinity
        for i in 0..<pts.count { for j in (i + 1)..<pts.count { minD = min(minD, Double(hypot(pts[i].x - pts[j].x, pts[i].y - pts[j].y))) } }
        check(inside && minD > 2 * t.bubbleRadius, "Bố cục phiếu in từ app")

        // Đồng bộ: hợp nhất hai máy
        let t0 = Date(timeIntervalSince1970: 1_000_000)
        var r1 = ScanRecord(sbd: "1", code: "0101", p1: [], p2: [], p3: []); r1.updatedAt = t0
        var r2 = ScanRecord(sbd: "2", code: "0101", p1: [], p2: [], p3: []); r2.updatedAt = t0
        var eA = Exam(name: "A", config: toan); eA.records = [r1]; eA.updatedAt = t0.addingTimeInterval(20)
        var eB = eA; eB.name = "B"; eB.records = [r1, r2]; eB.updatedAt = t0.addingTimeInterval(10)
        var m = SyncMerge.merge(SyncSnapshot(exams: [eA], classes: []), SyncSnapshot(exams: [eB], classes: []), now: t0)
        check(m.exams.count == 1 && m.exams[0].name == "A" && m.exams[0].records.count == 2, "Đồng bộ: hợp bài làm, giữ bản sửa sau")
        m = SyncMerge.merge(SyncSnapshot(exams: [eB], classes: []),
                            SyncSnapshot(exams: [eA], classes: [], deleted: ["record:\(r2.id)": t0.addingTimeInterval(5)]), now: t0)
        check(m.exams.first?.records.count == 1, "Đồng bộ: bài đã xoá ở máy kia")
        m = SyncMerge.merge(SyncSnapshot(exams: [eA], classes: []),
                            SyncSnapshot(exams: [], classes: [], deleted: ["exam:\(eA.id)": t0.addingTimeInterval(30)]), now: t0)
        check(m.exams.isEmpty, "Đồng bộ: bài chấm đã xoá")
        m = SyncMerge.merge(SyncSnapshot(exams: [eA], classes: []),
                            SyncSnapshot(exams: [], classes: [], deleted: ["exam:\(eA.id)": t0]), now: t0)
        check(m.exams.count == 1, "Đồng bộ: sửa sau khi xoá thì giữ lại")

        // Mẫu phiếu TNMaker (12) + QM (10) có sẵn
        let expect: [String: (Int, Int, Int)] = ["tnmaker-20": (20, 6, 3), "tnmaker-40": (40, 6, 3), "tnmaker-50": (50, 6, 3),
                                                 "tnmaker-60": (60, 6, 3), "tnmaker-100": (100, 6, 3), "tnmaker-120": (120, 6, 3), "tnmaker-ngang": (40, 6, 3)]
        let expect5: [String: Int] = ["tnmaker-20-5": 20, "tnmaker-40-5": 40, "tnmaker-60-5": 60, "tnmaker-100-5": 100]
        check(BuiltinTemplates.all.count == 22 && BuiltinTemplates.tnmaker.count == 12 && BuiltinTemplates.qm.count == 10, "Đủ 12 mẫu TNMaker + 10 mẫu QM (có \(BuiltinTemplates.all.count))")
        for t in BuiltinTemplates.all {
            let c = t.caps
            if let e = expect[t.id] {
                check(c.p1 == e.0 && c.sbd == e.1 && c.code == e.2 && t.cells().count == e.0 * 4 + (e.1 + e.2) * 10, "Mẫu \(t.name)")
            } else if let e5 = expect5[t.id] {
                check(c.p1 == e5 && t.p1Choices == 5 && c.sbd == 6 && c.code == 3 && t.cells().count == e5 * 5 + 90, "Mẫu \(t.name)")
            } else if t.id == OMREngine.officialCornerSpec {
                check(c.p1 == 40 && c.p2 == 8 && c.p3 == 6 && c.sbd == 8 && c.code == 4 && t.cells().count == 160 + 64 + 6 * 43 + 120, "Mẫu \(t.name)")
            } else {
                check(c.sbd == 8 && c.code == 4 && (c.p1 + c.p2 + c.p3) > 0, "Mẫu \(t.name)")
            }
            check(Set(t.cornerIndices).count == 4, "4 góc của \(t.name)")
        }
        // Bình phương tối thiểu khớp đúng khi có 6 điểm
        let s6 = [CGPoint(x: 0, y: 0), CGPoint(x: 1, y: 0), CGPoint(x: 1, y: 1.4), CGPoint(x: 0, y: 1.4), CGPoint(x: 0.5, y: 0.7), CGPoint(x: 0, y: 0.7)]
        if let H0 = Homography.from(Array(s6.prefix(4)), to: [CGPoint(x: 120, y: 80), CGPoint(x: 900, y: 120), CGPoint(x: 880, y: 1200), CGPoint(x: 90, y: 1150)]),
           let H1 = Homography.fit(s6, to: s6.map { H0.apply($0) }) {
            check(s6.allSatisfy { let a = H0.apply($0), b = H1.apply($0); return hypot(a.x - b.x, a.y - b.y) < 1e-6 }, "Phép biến đổi bình phương tối thiểu")
        } else { fails.append("Phép biến đổi bình phương tối thiểu") }
        // Khớp lưới khi thiếu ô tròn
        let marks = (0..<10).flatMap { r in (0..<4).compactMap { c -> TemplateBuilder.Mark? in
            (r + c) % 7 == 3 ? nil : TemplateBuilder.Mark(x: 100 + Double(c) * 30, y: 200 + Double(r) * 25, size: 18) } }
        let g = TemplateBuilder.fitGrid(marks, rect: CGRect(x: 104, y: 196, width: 86, height: 230), rows: 10, cols: 4, snap: true)
        check(zip(g.xs, [100, 130, 160, 190]).allSatisfy { abs($0 - $1) < 0.5 } && abs(g.ys[9] - 425) < 0.5, "Khớp lưới ô tròn")

        // Tìm mã đề "101" khớp "0101"
        check(exam.key(for: "101") != nil, "Mã đề 101 = 0101")
        // Biểu điểm mặc định đủ 10 điểm
        for s in [Subject.toan, .tuNhien, .xaHoi, .ngoaiNgu] {
            check(abs(s.preset.maxScore - 10) < 1e-9, "Tổng điểm \(s.title) = 10")
        }
        // Ma trận nắn phối cảnh
        let src = [CGPoint(x: 0, y: 0), CGPoint(x: 1, y: 0), CGPoint(x: 1, y: 0.57), CGPoint(x: 0, y: 0.57)]
        let dst = [CGPoint(x: 100, y: 200), CGPoint(x: 900, y: 180), CGPoint(x: 950, y: 700), CGPoint(x: 80, y: 690)]
        if let H = Homography.from(src, to: dst) {
            let ok = zip(src, dst).allSatisfy { a, b in let p = H.apply(a); return hypot(p.x - b.x, p.y - b.y) < 1e-6 }
            check(ok, "Phép biến đổi phối cảnh")
        } else { fails.append("Phép biến đổi phối cảnh") }

        // Danh mục mẫu phiếu (12 TNMaker + 10 QM) & 5 đáp án A–E
        check(BuiltinTemplates.tnmaker.count == 12 && BuiltinTemplates.qm.count == 10, "Danh mục 12 TNMaker + 10 QM")
        let t5 = TemplateRegistry.shared.spec("tnmaker-40-5")
        check(t5 != nil && t5?.p1Choices == 5 && t5?.caps.p1 == 40, "Mẫu TNMaker 40 câu 5 đáp án")

        // Tự luận + làm tròn + phân tích đề + Excel 3 sheet
        let hybridCfg = ExamConfig(subject: .tuyChinh, p1Count: 4, p2Count: 0, p3Count: 0, p1Point: 1.75, p3Point: 0, essayMaxScore: 3.0, roundMode: .r025)
        let hybridKey = AnswerKey(code: "101", p1: ["A", "B", "C", "E"], p2: [], p3: [])
        let hg = Grader.grade(p1: ["A", "B", "C", "E"], p2: [], p3: [], key: hybridKey, config: hybridCfg, essayScore: 2.6)
        check(abs(hg.score10 - 9.5) < 1e-6 && abs(hg.essayScore - 2.6) < 1e-6, "Chấm kết hợp Tự luận + làm tròn 0,25 + đáp án E")
        let demoExam = Exam(name: "Test", config: hybridCfg, keys: [hybridKey], records: [ScanRecord(sbd: "001", code: "101", p1: ["A", "B", "D", "E"], p2: [], p3: [], essayScore: 2.0)])
        let demoCls = ClassRoom(name: "12A", students: [Student(sbd: "001", name: "An"), Student(sbd: "002", name: "Bình")])
        let an = ExamAnalytics.compute(exam: demoExam, classRoom: demoCls)
        check(an.gradedCount == 1 && an.missingStudents.count == 1 && an.hardestItems.first?.label == "I.3", "Thống kê phân tích câu & HS chưa chấm")
        if let url = ExportService.xlsx(exam: demoExam, classRoom: demoCls),
           let data = try? Data(contentsOf: url),
           let rows = try? XLSX.readFirstSheet(data) {
            check(rows.count == 2 && rows[0].contains("Điểm TL"), "Xuất Excel 3 sheet đọc lại được")
        } else { fails.append("Xuất Excel 3 sheet") }

        return fails.isEmpty ? "✅ Tất cả kiểm tra đều đạt." : "❌ Lỗi:\n" + fails.joined(separator: "\n")
    }
}

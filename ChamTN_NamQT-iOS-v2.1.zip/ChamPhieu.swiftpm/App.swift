import SwiftUI

@main
struct ChamPhieuApp: App {
    @StateObject private var store = Store()
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .onChange(of: phase) { _, newPhase in
                    if newPhase == .background { store.saveNow() }
                    if newPhase == .active || newPhase == .background { SyncManager.shared.syncIfAuto(store) }
                }
        }
    }
}

struct RootView: View {
    var body: some View {
        TabView {
            NavigationStack { ExamListView() }
                .tabItem { Label("Bài chấm", systemImage: "doc.text.viewfinder") }
            NavigationStack { ClassListView() }
                .tabItem { Label("Lớp học", systemImage: "person.3") }
            NavigationStack { SettingsView() }
                .tabItem { Label("Cài đặt", systemImage: "gearshape") }
        }
    }
}

// swift-tools-version: 5.9

// Gói ứng dụng iOS (định dạng .swiftpm): mở bằng Xcode trên Mac hoặc Swift Playgrounds trên iPad.
import PackageDescription
import AppleProductTypes

let package = Package(
    name: "ChamTN_NamQT",
    platforms: [
        .iOS("17.0")
    ],
    products: [
        .iOSApplication(
            name: "ChamTN_NamQT",
            targets: ["AppModule"],
            bundleIdentifier: "vn.namqt.chamtn",
            teamIdentifier: "",
            displayVersion: "2.1",
            bundleVersion: "6",
            appIcon: .placeholder(icon: .pencil),
            accentColor: .presetColor(.blue),
            supportedDeviceFamilies: [
                .pad,
                .phone
            ],
            supportedInterfaceOrientations: [
                .portrait
            ],
            capabilities: [
                .camera(purposeString: "Ứng dụng dùng camera để quét phiếu trả lời trắc nghiệm và mã QR đáp án.")
            ]
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: "."
        )
    ]
)

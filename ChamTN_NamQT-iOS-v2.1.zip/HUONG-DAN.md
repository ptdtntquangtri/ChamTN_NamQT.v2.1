# ChamTN_NamQT – app chấm trắc nghiệm trên iPhone (phiên bản 1.2)

App iOS (SwiftUI) chấm phiếu trắc nghiệm bằng camera. Đọc được các loại phiếu:

| Mẫu phiếu | Số câu | SBD / mã đề | Lấy ở đâu |
| --- | --- | --- | --- |
| **Phiếu Bộ GD&ĐT 2025** (CV 1239) | tối đa 40 – 8 – 6 | 8 số / 4 số | phiếu in sẵn của Bộ / Sở |
| **Phiếu in từ app** (A4) | đúng số câu của bài chấm: tối đa 100 câu Phần I, 10 câu Phần II, 12 câu Phần III (miễn vừa một trang A4) | 6 số / 3 số | in ngay trong app |
| **TNMaker** – phiếu 20, 40, 50 (mẫu Bộ), 60, 100, 120 (mẫu Bộ), phiếu ngang 40 | đúng số câu của phiếu, chỉ phần ABCD | 6 số / 3 số | tải miễn phí tại tnmaker.net/phieu-trac-nghiem |
| **Azota** và phiếu khác có ô vuông đen ở 4 góc | tuỳ phiếu (cả Phần I, II, III) | tuỳ phiếu | tạo mẫu một lần từ file PDF phiếu trắng |

## Có gì mới trong 1.2: phiếu TNMaker và Azota
- **7 mẫu phiếu mặc định của TNMaker có sẵn trong app.**
  - Mình đo toạ độ từ chính các file phiếu gốc mà TNMaker công bố trên trang tnmaker.net.
  - Khi tạo bài chấm, chọn đúng loại phiếu ở mục *Mẫu phiếu* (ví dụ "TNMaker – Phiếu 40 câu").
  - Số câu của bài có thể ít hơn số câu in trên phiếu.
- **Phiếu Azota: tạo mẫu từ phiếu trắng.**
  - Azota sinh phiếu riêng cho từng đề, chỉ tải được sau khi đăng nhập; mã mẫu in ở cuối phiếu (ví dụ v15.0). Vì vậy không có sẵn một bộ toạ độ cố định để đưa vào app.
  - Cách làm:
    1. Trên Azota: mở đề → *In đề – có phiếu trả lời riêng* → tải *File phiếu trả lời* (PDF), không cần tô.
    2. Trong app: *Cài đặt → Mẫu phiếu → Tạo mẫu từ phiếu trắng* → chọn file PDF. App tự tìm các ô vuông đen (khung xanh dương, 4 góc đánh số đỏ 1–4) và các ô tròn (chấm xanh lá).
    3. Bấm *Thêm vùng*, chọn loại (Số báo danh, Mã đề, Phần I, Phần II, Phần III) và số câu. Sau đó **kéo từ tâm ô tròn đầu tiên (trên–trái) tới tâm ô tròn cuối cùng (dưới–phải)** của vùng; nên phóng to để kéo cho chính xác. App tự khớp lưới vào các ô tròn đã tìm thấy và vẽ vòng cam để bạn kiểm tra.
    4. Lặp lại cho từng cột câu hỏi, đặt tên mẫu (ví dụ "Azota v15 – 40 câu") rồi *Lưu*.
  - Mỗi loại phiếu chỉ cần tạo mẫu một lần. Mẫu tự tạo được đồng bộ sang máy khác cùng với dữ liệu.
  - Cách này dùng được cho **mọi phiếu có ô vuông đen ở 4 góc**: phiếu TNMaker mở rộng hay đã sửa, phiếu của trường…
- **Bộ đọc mẫu phiếu mới:**
  - Tìm phiếu bằng cách so toàn bộ ô vuông định vị của mẫu, không chỉ 4 góc.
  - Nhận ra khi phiếu bị xoay ngược hoặc khi chọn nhầm mẫu (phiếu 40 câu không bị đọc như phiếu 20 câu).
  - Nắn ảnh bằng tất cả ô định vị khớp được, nên ô tô ở giữa phiếu chính xác hơn.

## Có gì mới trong 1.1

Với phiếu in từ app, phiếu 1 phần chỉ cần đặt Phần II và Phần III bằng 0. Phiếu ôn tập chỉ có trả lời ngắn thì đặt 0 – 0 – 12.

## Có gì mới trong 1.1
- **Tên app hiển thị: ChamTN_NamQT.** Mã định danh: `vn.namqt.chamtn`.
- **In phiếu từ app:**
  - Mở bài chấm → *In phiếu trả lời (PDF)* → xem trước, chọn số bản → *In* (qua AirPrint) hoặc *Lưu / gửi file PDF*.
  - In co giãn vừa trang vẫn chấm được. Chỉ cần không cắt mất 6 ô vuông đen.
  - Đổi số câu sau khi đã in thì phải in lại phiếu.
- **Đọc trực tiếp file Excel .xlsx:**
  - Đáp án: *Thêm đáp án → Mở file Excel (.xlsx) / CSV*.
  - Danh sách học sinh: trong màn hình lớp, *+ → Mở file Excel*.
  - Bấm *File đáp án Excel mẫu* để lấy file .xlsx có sẵn các cột.
- **Xuất bảng điểm ra .xlsx:** mở được bằng Excel, Numbers và Google Sheets. Dòng tiêu đề in đậm và cố định khi cuộn. Vẫn xuất CSV được.
- **Đồng bộ đám mây:**
  1. Vào *Cài đặt → Đồng bộ đám mây → Chọn thư mục*, chọn một thư mục trong iCloud Drive, Google Drive, OneDrive hoặc Dropbox (thông qua app Tệp).
  2. App lưu bài chấm, đáp án, lớp học và ảnh phiếu vào thư mục con `ChamTN_NamQT`.
  3. Trên máy khác, cài app và chọn đúng thư mục đó.

  App tự đồng bộ khi mở app, khi thoát app và sau mỗi lượt chấm; cũng có nút *Đồng bộ ngay*. Nếu hai máy cùng sửa một bài, bản sửa sau cùng được giữ. Bài đã xoá ở một máy cũng bị xoá ở máy kia.

## Cài lên iPhone
**Cách 1 – Mac có Xcode 15 trở lên (khuyên dùng)**
1. Giải nén, mở `ChamPhieu.swiftpm` bằng Xcode.
2. Chọn target *ChamTN_NamQT* → *Signing & Capabilities* → chọn Team (Apple ID miễn phí cũng được).
3. Cắm iPhone, chọn iPhone làm đích chạy, bấm ▶︎.
4. Lần đầu: trên iPhone vào *Cài đặt → Cài đặt chung → Quản lý VPN & thiết bị* → tin cậy nhà phát triển.
5. Nên chạy bản **Release** cho nhanh: *Product → Scheme → Edit Scheme → Run → Build Configuration = Release*.

**Cách 2 – chỉ có iPad:** mở `ChamPhieu.swiftpm` bằng app *Swift Playgrounds*.

## Cách dùng
1. **Bài chấm → +**:
   - Đặt tên, chọn môn (số câu và biểu điểm theo QĐ 764).
   - Chọn **Mẫu phiếu**: Phiếu Bộ GD&ĐT 2025 hoặc Phiếu in từ app.
2. **Thêm đáp án** bằng một trong các cách:
   - nhập tay;
   - dán từ Excel;
   - mở file .xlsx hoặc CSV (mỗi dòng một mã đề: cột A là mã đề, sau đó mỗi câu một ô);
   - quét mã QR do giáo viên khác chia sẻ.
3. Nếu dùng phiếu của app thì **in phiếu** cho học sinh làm bài.
4. **Chấm bằng camera:**
   - Đặt phiếu trên mặt phẳng, đủ sáng, rồi đưa máy sao cho thấy đủ **6 ô vuông đen**.
   - Khi khung xanh hiện ra, giữ yên khoảng 1 giây. App kêu "tít", hiện điểm rồi chờ phiếu tiếp theo.
5. **Bảng điểm:**
   - Mỗi bài có ảnh phiếu kèm vòng màu: xanh là tô đúng, đỏ là tô sai, cam là phạm quy.
   - Bấm *Sửa* để chữa bài máy đọc nhầm.
   - Xuất file .xlsx hoặc CSV.
6. **Lớp học:** nhập danh sách SBD và họ tên (dán từ Excel hoặc mở file .xlsx) để bảng điểm hiện họ tên.

*Cài đặt → Chạy kiểm tra chấm điểm* chạy bộ tự kiểm tra trong app. Bộ này kiểm tra:
- cách tính điểm;
- đọc đáp án;
- Excel ghi rồi đọc lại;
- bố cục phiếu in;
- hợp nhất dữ liệu khi đồng bộ;
- mã QR.

## Đã kiểm tra gì, chưa kiểm tra gì
Thuật toán nhận dạng được kiểm tra trên bản Python giống hệt (`omr_ref.py`, `templates_ref.py`):
- ✅ **Phiếu Bộ 2025:** 18/20 ảnh mô phỏng (xoay, nghiêng, ánh sáng lệch, mờ) đọc đúng toàn bộ ô. 2 ảnh còn lại có phiếu bị cắt khỏi khung nên app báo "không nhận ra", không đọc sai.
- ✅ **Phiếu in từ app:** 35/35 ảnh mô phỏng (7 cấu hình, kể cả 40 câu 1 phần, 60 câu, 100 câu, 0 – 0 – 12) đọc đúng. Thêm 20/20 ảnh lấy từ bản dựng lại phiếu PDF (bằng Python, cùng toạ độ và chữ như app), có tô và chụp nghiêng, cũng đọc đúng.
- ✅ **Phần đọc và ghi .xlsx:** bản Python cùng thuật toán đọc đúng file do openpyxl tạo (có nén, có chuỗi dùng chung, có số thập phân). File .xlsx do nó ghi ra mở được bằng openpyxl, dòng tiêu đề đậm và cố định đúng.
- ⚠️ **Mã Swift chưa được biên dịch** (máy làm việc không có Xcode). Nếu Xcode báo lỗi, gửi lại nguyên văn để sửa.
- ⚠️ **Chưa thử camera thật, máy in thật và đồng bộ thật** giữa hai iPhone. Hãy chấm thử 5–10 phiếu đã biết điểm trước khi dùng cho bài thật.

## Kiểm tra phiếu TNMaker và Azota (1.2)
Các kết quả dưới đây chạy trên bản Python giống hệt thuật toán Swift (`kiem-thu/spec_ref.py`, `builder_ref.py`):
- ✅ **Phiếu TNMaker:** 28/28 ảnh mô phỏng của 7 mẫu đọc đúng toàn bộ ô (SBD, mã đề, mọi câu, cả câu tô 2 ô bị tính phạm quy). Ảnh mô phỏng tạo từ phiếu gốc, có tô, chụp nghiêng, lệch sáng, mờ; 21 ảnh bị xoay ngược phiếu.
- ✅ **Chọn nhầm mẫu thì từ chối:** 5/5 trường hợp dùng mẫu sai (ví dụ phiếu 40 với mẫu 20) đều bị từ chối, không đọc sai.
- ✅ **Tạo mẫu từ phiếu trắng:**
  - Lưới do app khớp lệch tối đa khoảng 2 px so với số đo chuẩn, trong khi bán kính ô tròn là 7–10 px (trên ảnh rộng 922 px).
  - Dựng mẫu từ PDF phiếu trắng gồm đủ 3 phần (dùng phiếu in từ app thay Azota), rồi đọc 8 phiếu đã tô: 8/8 đúng.
- ⚠️ **Chưa thử với file PDF Azota thật.** Phiếu Azota chỉ tải được sau khi đăng nhập, mình không có. Lần đầu dùng, hãy tạo mẫu rồi chấm thử vài phiếu đã biết điểm.
- ⚠️ Mã Swift vẫn **chưa được biên dịch**; chưa thử camera và phiếu in thật.

## Vì sao đồng bộ dùng thư mục chứ không dùng iCloud của app?
Đồng bộ CloudKit riêng của app cần tài khoản Apple Developer trả phí và cấu hình iCloud container, mà định dạng `.swiftpm` không khai báo được. Đồng bộ qua thư mục trong app Tệp chạy được ngay với Apple ID miễn phí, và dùng được cả Google Drive hay OneDrive.

Nếu sau này bạn có tài khoản trả phí, có thể chuyển sang CloudKit.

## Bản 1.3 (26/11/2026)
- Nhận phiếu Bộ 2025 bản có 4 ô vuông lớn ở 4 góc (bản in phổ biến với QM 2025); bài chấm chọn "Phiếu Bộ GD&ĐT 2025" tự nhận cả hai kiểu.
- Chấm được ảnh ngang, dọc, lộn ngược, chụp nghiêng; không còn đọc nhầm phiếu khác thành phiếu Bộ.

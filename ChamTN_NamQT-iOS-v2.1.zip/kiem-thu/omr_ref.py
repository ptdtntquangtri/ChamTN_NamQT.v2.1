"""Reference implementation of the OMR engine (mirrors Swift OMREngine). Pure numpy, no cv2 in the engine."""
import numpy as np
A = 505.65/888.0  # height/width of marker rectangle (I-L..III-R)
R = 0.00788       # bubble radius in X units
L = dict(p1x0=0.143826, p1bdx=0.240391, p1odx=0.042562, p1y0=0.118186, p1dy=0.047158,
         p2y0=0.781474, p2dy=0.046690,
         p3x0=0.112822, p3bdx=0.153422, p3cdx=0.025605, p3y0=1.134908, p3dy=0.052316,
         sx0=0.710425, sdx=0.020540, mx0=0.895344, mdx=0.020647, hy0=-0.590794, hdy=0.055312)
def p1(q,k):
    b,r=(q-1)//10,(q-1)%10; return (L['p1x0']+b*L['p1bdx']+(k-1.5)*L['p1odx'], (L['p1y0']+r*L['p1dy'])*A)
def p2(q,i,ds):  # ds 0=Dung 1=Sai
    b,s=(q-1)//2,(q-1)%2; k=2*s+ds
    return (L['p1x0']+b*L['p1bdx']+(k-1.5)*L['p1odx'], (L['p2y0']+i*L['p2dy'])*A)
def p3(q,row,c):  # row 0 '-',1 ',',2..11 digits
    b=q-1; return (L['p3x0']+b*L['p3bdx']+(c-1.5)*L['p3cdx'], (L['p3y0']+row*L['p3dy'])*A)
def sbd(c,d): return (L['sx0']+c*L['sdx'], (L['hy0']+d*L['hdy'])*A)
def md(c,d): return (L['mx0']+c*L['mdx'], (L['hy0']+d*L['hdy'])*A)
P3CELLS=[(0,0,'-'),(1,1,','),(1,2,',')]+[(2+d,c,str(d)) for d in range(10) for c in range(4)]

def homography(src,dst):
    M=[];b=[]
    for (x,y),(u,v) in zip(src,dst):
        M.append([x,y,1,0,0,0,-u*x,-u*y]); b.append(u)
        M.append([0,0,0,x,y,1,-v*x,-v*y]); b.append(v)
    h=np.linalg.solve(np.array(M,float),np.array(b,float)); return np.append(h,1).reshape(3,3)
def apply(H,x,y):
    p=H@[x,y,1]; return p[0]/p[2],p[1]/p[2]

def components(mask):
    h,w=mask.shape; lab=-np.ones((h,w),int); comps=[]
    for y in range(h):
        for x in range(w):
            if mask[y,x] and lab[y,x]<0:
                st=[(y,x)]; lab[y,x]=len(comps); pts=[]
                while st:
                    cy,cx=st.pop(); pts.append((cx,cy))
                    for ny,nx in ((cy+1,cx),(cy-1,cx),(cy,cx+1),(cy,cx-1)):
                        if 0<=ny<h and 0<=nx<w and mask[ny,nx] and lab[ny,nx]<0:
                            lab[ny,nx]=len(comps); st.append((ny,nx))
                comps.append(np.array(pts,float))
    return comps

def integral_mean(g,rad):
    h,w=g.shape; I=np.zeros((h+1,w+1)); I[1:,1:]=g.cumsum(0).cumsum(1)
    y0=np.clip(np.arange(h)-rad,0,h); y1=np.clip(np.arange(h)+rad+1,0,h)
    x0=np.clip(np.arange(w)-rad,0,w); x1=np.clip(np.arange(w)+rad+1,0,w)
    S=I[y1][:,x1]-I[y0][:,x1]-I[y1][:,x0]+I[y0][:,x0]
    return S/((y1-y0)[:,None]*(x1-x0)[None,:])

def find_markers(g):
    h,w=g.shape; s=max(1,int(max(h,w)//1400))  # detection scale
    gs=g[:h//s*s,:w//s*s].reshape(h//s,s,w//s,s).mean((1,3))
    H2,W2=gs.shape; rad=max(8,min(H2,W2)//16)
    mean=integral_mean(gs,rad); mask=gs<mean*0.6
    cands=[]
    minA=(min(H2,W2)*0.008)**2; maxA=(min(H2,W2)*0.05)**2
    for pts in components(mask):
        n=len(pts)
        if n<max(12,minA) or n>maxA: continue
        c=pts.mean(0); d=pts-c; cov=d.T@d/n; ev=np.linalg.eigvalsh(cov)
        if ev[0]/ev[1]<0.45: continue
        md2=(d**2).sum(1).max()+0.5
        ratio=n/md2
        if ratio>2.65: continue
        cands.append(((c[0]+0.5)*s-0.5,(c[1]+0.5)*s-0.5,n*s*s))
    return cands

FR=0.6096
MSIDE=0.017446  # marker side in X units
def pick_quad(c,t):
    A=t.A; FR=t.FR; MSIDE=t.MSIDE
    """Find the 6 section markers: two collinear triples (left/right) with the middle one at FR along the line."""
    n=len(c)
    if n<6: return None
    P=np.array([t[:2] for t in c]); S=np.array([t[2] for t in c])
    triples=[]
    for i in range(n):
        for j in range(n):
            if i==j: continue
            a,b=P[i],P[j]; L=np.linalg.norm(b-a)
            if L<20: continue
            for f in (FR,1-FR):
                m=a+(b-a)*f
                d=np.linalg.norm(P-m,axis=1); k=int(np.argmin(d))
                if k in (i,j) or d[k]>0.06*L: continue
                sz=S[[i,j,k]]
                if sz.max()>2.2*sz.min(): continue
                exp=(MSIDE/A*L)**2
                if not (0.85*exp < sz.mean() < 2.6*exp): continue
                if f==FR: triples.append((d[k]/L,i,k,j,L))   # top=i (closer to middle at 0.61 means i is Phan I)
    best=None
    for t1 in triples:
        for t2 in triples:
            if len({t1[1],t1[2],t1[3],t2[1],t2[2],t2[3]})<6: continue
            # t1 left, t2 right: vector from left top to right top should be ~perpendicular to the column vector
            lt,lb,rt,rb=P[t1[1]],P[t1[3]],P[t2[1]],P[t2[3]]
            col=(lb-lt+rb-rt)/2; row=(rt-lt+rb-lb)/2
            hl=np.linalg.norm(col); wl=np.linalg.norm(row)
            if not (A*0.7<hl/wl<A*1.4): continue
            cross=col[0]*row[1]-col[1]*row[0]   # orientation: row x col should be negative (clockwise in image coords)
            if cross>=0: continue
            if abs(t1[4]-t2[4])>0.35*max(t1[4],t2[4]): continue
            aL=S[[t1[1],t1[2],t1[3]]].mean(); aR=S[[t2[1],t2[2],t2[3]]].mean(); er=(t2[4]/t1[4])**2
            if aR/aL>er*1.8 or aR/aL<er/1.8: continue
            def ang(u,v): return np.degrees(np.arccos(np.clip(np.dot(u,v)/np.linalg.norm(u)/np.linalg.norm(v),-1,1)))
            if ang(rt-lt,rb-lb)>20 or ang(lb-lt,rb-rt)>20: continue
            if abs(90-ang(row,col))>25: continue
            Hh=homography([(0,0),(1,0),(1,A),(0,A)],[lt,rt,rb,lb])
            e=0
            for u,k in ((0,t1[2]),(1,t2[2])):
                x,y=apply(Hh,u,FR*A); e+=np.hypot(x-P[k][0],y-P[k][1])/wl
            score=e+0.2*(t1[0]+t2[0])
            if best is None or score<best[0]: best=(score,[lt,rt,rb,lb])
    if best is None or best[0]>=0.05: return None
    return best[1], c

def decode(g, t=None):
    import templates_ref as T
    t=t or T.Official()
    A=t.A; R=t.R
    m=find_markers(g)
    r=pick_quad(m,t)
    if r is None: return None
    (TL,TR,BR,BL),cands=r
    # long side must be horizontal in sheet frame: width/height ~ 1/A
    wid=(np.linalg.norm(TR-TL)+np.linalg.norm(BR-BL))/2; hei=(np.linalg.norm(BL-TL)+np.linalg.norm(BR-TR))/2
    ratio=hei/wid
    if not (A*0.75<ratio<A*1.3): return None
    Hm=homography([TL,TR,BR,BL],[(0,0),(1,0),(1,A),(0,A)])
    Hi=np.linalg.inv(Hm)
    # orientation check via Phan II markers at y=0.6096*A
    hgt,wdt=g.shape
    def sample(X,Y):
        rr=R*0.55; vals=[]
        for dx in np.linspace(-rr,rr,5):
            for dy in np.linspace(-rr,rr,5):
                if dx*dx+dy*dy<=rr*rr*1.05:
                    x,y=apply(Hi,X+dx,Y+dy); xi=int(round(x)); yi=int(round(y))
                    vals.append(g[min(max(yi,0),hgt-1),min(max(xi,0),wdt-1)])
        return float(np.mean(vals))
    # dark reference: marker interiors
    dark=np.mean([sample(u,v) for u,v in [(0,0),(1,0),(0,A),(1,A)]])
    def block(vals):
        paper=np.percentile(vals,75)
        return [(paper-v)/max(paper-dark,20) for v in vals]
    # global fill threshold via 2-means over every bubble on the sheet
    allf=[]
    P1G=[list(range(b*10+1,min(b*10+11,t.p1Cap+1))) for b in range((t.p1Cap+9)//10)]
    P2G=[list(range(b*2+1,min(b*2+3,t.p2Cap+1))) for b in range((t.p2Cap+1)//2)]
    for qs in P1G: allf+=block([sample(*t.p1(q,k)) for q in qs for k in range(4)])
    for qs in P2G: allf+=block([sample(*t.p2(q,i,ds)) for q in qs for i in range(4) for ds in range(2)])
    for q in range(1,t.p3Cap+1): allf+=block([sample(*t.p3(q,row,c)) for row,c,_ in P3CELLS])
    allf=np.array(allf); c0,c1=np.quantile(allf,0.3),allf.max()
    for _ in range(10):
        T=(c0+c1)/2; lo=allf[allf<T]; hi=allf[allf>=T]
        if len(lo)==0 or len(hi)==0: break
        c0,c1=lo.mean(),hi.mean()
    T=0.5 if c1-c0<0.15 else min(max((c0+c1)/2,0.18),0.5)
    out_T=T
    out={}
    # header
    def digits(fn,ncol):
        cells=[[fn(c,d) for d in range(10)] for c in range(ncol)]
        f=block([sample(*p) for col in cells for p in col]); s=''
        for c in range(ncol):
            fc=f[c*10:(c+1)*10]; on=[d for d in range(10) if fc[d]>T]
            s+= str(on[0]) if len(on)==1 else ('' if not on else '?')
        return s
    out['sbd']=digits(t.sbd,t.sbdDigits); out['made']=digits(t.code,t.codeDigits)
    p1v=[]
    for qs in P1G:
        cells=[(q,k) for q in qs for k in range(4)]
        f=block([sample(*t.p1(q,k)) for q,k in cells])
        for i in range(len(qs)):
            on=[k for k in range(4) if f[i*4+k]>T]
            p1v.append('' if not on else ('ABCD'[on[0]] if len(on)==1 else '*'))
    out['p1']=p1v
    p2v=[]
    for qs in P2G:
        cells=[(q,i,ds) for q in qs for i in range(4) for ds in range(2)]
        f=block([sample(*t.p2(*c)) for c in cells])
        for qi in range(len(qs)):
            s=''
            for i in range(4):
                dv,sv=f[qi*8+i*2],f[qi*8+i*2+1]
                s+= ('*' if dv>T and sv>T else 'D' if dv>T else 'S' if sv>T else '_')
            p2v.append(s)
    out['p2']=p2v
    p3v=[]
    for q in range(1,t.p3Cap+1):
        f=block([sample(*t.p3(q,row,c)) for row,c,_ in P3CELLS])
        cols=[[] for _ in range(4)]
        for (row,c,sym),fv in zip(P3CELLS,f):
            if fv>T: cols[c].append(sym)
        s=''.join(('*' if len(x)>1 else x[0]) for x in cols if x)
        p3v.append(s)
    out['p3']=p3v
    if sum(x=='*' for x in p1v)+sum('*' in x for x in p2v)>12: return None
    out['quad']=(TL,TR,BR,BL); out['T']=out_T
    return out

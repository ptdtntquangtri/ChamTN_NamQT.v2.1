"""Sheet templates (mirror of Swift SheetTemplate)."""
import math
class Official:
    id='official2025'
    A=505.65/888.0; FR=0.6096; MSIDE=0.017446; R=0.00788
    sbdDigits=8; codeDigits=4; p1Cap=40; p2Cap=8; p3Cap=6
    L=dict(p1x0=0.143826, p1bdx=0.240391, p1odx=0.042562, p1y0=0.118186, p1dy=0.047158,
         p2y0=0.781474, p2dy=0.046690, p3x0=0.112822, p3bdx=0.153422, p3cdx=0.025605, p3y0=1.134908, p3dy=0.052316,
         sx0=0.710425, sdx=0.020540, mx0=0.895344, mdx=0.020647, hy0=-0.590794, hdy=0.055312)
    def p1(s,q,k):
        L=s.L;b,r=(q-1)//10,(q-1)%10; return (L['p1x0']+b*L['p1bdx']+(k-1.5)*L['p1odx'], (L['p1y0']+r*L['p1dy'])*s.A)
    def p2(s,q,i,ds):
        L=s.L;b,t=(q-1)//2,(q-1)%2; k=2*t+ds
        return (L['p1x0']+b*L['p1bdx']+(k-1.5)*L['p1odx'], (L['p2y0']+i*L['p2dy'])*s.A)
    def p3(s,q,row,c):
        L=s.L; return (L['p3x0']+(q-1)*L['p3bdx']+(c-1.5)*L['p3cdx'], (L['p3y0']+row*L['p3dy'])*s.A)
    def sbd(s,c,d): L=s.L; return (L['sx0']+c*L['sdx'], (L['hy0']+d*L['hdy'])*s.A)
    def code(s,c,d): L=s.L; return (L['mx0']+c*L['mdx'], (L['hy0']+d*L['hdy'])*s.A)

# ---- App-printed template, all in millimetres on an A4 page ----
MXL,MXR,MYT,MYB=12.0,198.0,14.0,283.0
UNIT=MXR-MXL
class AppSheet:
    FR=0.4
    def __init__(s,p1,p2,p3,sbdDigits=6,codeDigits=3):
        s.p1Cap,s.p2Cap,s.p3Cap=p1,p2,p3; s.sbdDigits,s.codeDigits=sbdDigits,codeDigits
        s.id=f'app-{p1}-{p2}-{p3}'
        s.A=(MYB-MYT)/UNIT; s.MSIDE=6.0/UNIT; s.R=1.9/UNIT
        y=86.0; s.p1Y=y; s.p1Bands=math.ceil(p1/50) if p1 else 0; y+=s.p1Bands*60+(3 if p1 else 0)
        s.p2Y=y; s.p2Bands=math.ceil(p2/5) if p2 else 0; y+=s.p2Bands*29+(3 if p2 else 0)
        s.p3Y=y; s.p3Bands=math.ceil(p3/6) if p3 else 0; y+=s.p3Bands*62
        s.bottom=y
    @property
    def fits(s): return s.bottom<=279 and s.p1Cap<=100 and s.p2Cap<=10 and s.p3Cap<=12
    @staticmethod
    def U(xmm,ymm): return ((xmm-MXL)/UNIT,(ymm-MYT)/UNIT)
    # mm positions (also used by the PDF renderer)
    def p1mm(s,q,k):
        i=q-1; blk=i//10; band=blk//5; col=blk%5; r=i%10
        return (20+col*34+10+k*6, s.p1Y+band*60+9+r*5.2)
    def p2mm(s,q,i,ds):
        j=q-1; band=j//5; col=j%5
        return (20+col*34+14+ds*8, s.p2Y+band*29+9+i*5.2)
    def p3mm(s,q,row,c):
        j=q-1; band=j//6; col=j%6
        return (20+col*28+8+c*5, s.p3Y+band*62+9+row*4.4)
    def sbdmm(s,c,d): return (120+c*5.2, 37+d*4.6)
    def codemm(s,c,d): return (160+c*5.2, 37+d*4.6)
    def p1(s,q,k): return s.U(*s.p1mm(q,k))
    def p2(s,q,i,ds): return s.U(*s.p2mm(q,i,ds))
    def p3(s,q,row,c): return s.U(*s.p3mm(q,row,c))
    def sbd(s,c,d): return s.U(*s.sbdmm(c,d))
    def code(s,c,d): return s.U(*s.codemm(c,d))

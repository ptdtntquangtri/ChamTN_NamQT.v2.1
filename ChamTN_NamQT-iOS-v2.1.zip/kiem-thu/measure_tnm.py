import cv2, numpy as np, json, builder_ref as Bd, omr_ref as O
SHEETS={
 'tnm20':dict(name='TNMaker – Phiếu 20 câu',blocks=[('sbd',(290,440,460,760),10,6,1),('code',(485,440,565,760),10,3,1),('p1',(315,795,430,1115),10,4,1),('p1',(485,795,600,1115),10,4,11)]),
 'tnm40':dict(name='TNMaker – Phiếu 40 câu',blocks=[('sbd',(205,440,375,760),10,6,1),('code',(400,440,485,760),10,3,1),('p1',(570,440,685,760),10,4,1),('p1',(230,795,345,1115),10,4,11),('p1',(400,795,515,1115),10,4,21),('p1',(570,795,685,1115),10,4,31)]),
 'tnm50':dict(name='TNMaker – Phiếu 50 câu (mẫu Bộ)',blocks=[('sbd',(660,155,765,395),10,6,1),('code',(785,155,845,395),10,3,1),('p1',(200,510,410,1200),25,4,1),('p1',(560,510,770,1200),25,4,26)]),
 'tnm60':dict(name='TNMaker – Phiếu 60 câu',blocks=[('sbd',(155,515,310,800),10,6,1),('code',(335,515,410,800),10,3,1),('p1',(480,515,585,800),10,4,1),('p1',(630,515,735,800),10,4,11),
     ('p1',(185,830,285,1115),10,4,21),('p1',(335,830,435,1115),10,4,31),('p1',(480,830,585,1115),10,4,41),('p1',(630,830,735,1115),10,4,51)]),
 'tnm100':dict(name='TNMaker – Phiếu 100 câu',blocks=[('sbd',(190,315,325,560),10,6,1),('code',(345,315,415,560),10,3,1),('p1',(480,315,570,560),10,4,1),('p1',(615,315,700,560),10,4,11)]
     +[('p1',(x0,y0,x1,y1),10,4,f) for (y0,y1,base) in [(590,840,21),(865,1115,61)] for (x0,x1),f in zip([(185,305),(335,435),(460,570),(615,700)],[base,base+10,base+20,base+30])]),
 'tnm120':dict(name='TNMaker – Phiếu 120 câu (mẫu Bộ)',blocks=[('sbd',(660,135,775,380),10,6,1),('code',(795,135,850,380),10,3,1)]+[('p1',(x0,445,x1,1215),30,4,f) for (x0,x1),f in zip([(120,245),(315,440),(510,635),(705,830)],[1,31,61,91])]),
 'tnmngang':dict(name='TNMaker – Phiếu ngang 40 câu',blocks=[('sbd',(935,120,1085,450),10,6,1),('code',(1110,120,1185,450),10,3,1)]+[('p1',(x0,505,x1,845),10,4,f) for (x0,x1),f in zip([(200,370),(460,630),(720,890),(980,1150)],[1,11,21,31])]),
}
def circles(g,rect,rows,cols):
    x0,y0,x1,y1=rect; sub=g[y0:y1,x0:x1].astype(np.uint8)
    best=None
    for p2 in (14,12,10,9,8,7):
        for rr in ((5,9),(6,11),(7,13),(8,16)):
            c=cv2.HoughCircles(cv2.GaussianBlur(sub,(3,3),0),cv2.HOUGH_GRADIENT,dp=1,minDist=rr[0]*1.5,param1=60,param2=p2,minRadius=rr[0],maxRadius=rr[1])
            if c is None: continue
            c=c[0]
            if len(c)<rows*cols*0.7: continue
            xs=Bd.cluster1d(c[:,0],rr[0]*0.7); ys=Bd.cluster1d(c[:,1],rr[0]*0.7)
            xs=[g_ for g_ in xs if len(g_)>=rows*0.5]; ys=[g_ for g_ in ys if len(g_)>=cols*0.5]
            if len(xs)==cols and len(ys)==rows:
                cx=np.array(sorted(np.mean(c[g_,0]) for g_ in xs))+x0; cy=np.array(sorted(np.mean(c[g_,1]) for g_ in ys))+y0
                r=np.median(c[:,2])
                return cx,cy,r
    return None
def fit(v):
    i=np.arange(len(v)); p=np.polyfit(i,v,1); return p[1],p[0],np.abs(np.polyval(p,i)-v).max()
out={}
for key,cfg in SHEETS.items():
    img=cv2.imread(f'tnm/{key}.png'); g=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY).astype(float)
    m,_=Bd.detect(g); TL,TR,BR,BL=Bd.corners(m)
    W=np.linalg.norm(TR[:2]-TL[:2]); A=np.linalg.norm(BL[:2]-TL[:2])/W
    H=O.homography([TL[:2],TR[:2],BR[:2],BL[:2]],[(0,0),(1,0),(1,A),(0,A)])
    S=lambda x,y:O.apply(H,x,y)
    blocks=[]; radii=[]; vis=img.copy()
    for kind,rect,rows,cols,first in cfg['blocks']:
        r=circles(g,rect,rows,cols)
        if r is None: print(key,'FAIL',kind,rect); continue
        cx,cy,rad=r; radii.append(rad)
        ax,adx,ex=fit(cx); ay,ady,ey=fit(cy)
        if ex>2.5 or ey>2.5: print(key,'nonuniform',kind,first,round(ex,1),round(ey,1))
        print('   ',key,kind,first,'maxdev px',round(ex,2),round(ey,2))
        ymid=np.mean(cy); xmid=np.mean(cx)
        blocks.append(dict(kind=kind,first=first,xs=[round(S(x,ymid)[0],5) for x in cx],ys=[round(S(xmid,y)[1],5) for y in cy]))
        for xx in cx:
            for yy in cy: cv2.circle(vis,(int(xx),int(yy)),int(rad),(0,0,255),1)
    cv2.imwrite(f'tnm/vis_{key}.png',vis)
    mk=[dict(x=round(S(x,y)[0],5),y=round(S(x,y)[1],5),side=round(s/W,5)) for x,y,s in m]
    out[key]=dict(id=key,name=cfg['name'],aspect=round(A,5),bubbleR=round(float(np.median(radii))/W,5),markers=mk,blocks=blocks)
    print(key,'A',round(A,4),'R',round(np.median(radii),1),'blocks',len(blocks),'/',len(cfg['blocks']),'markers',len(mk))
json.dump(out,open('tnm/tnm_specs.json','w'),ensure_ascii=False,indent=1)

"""Generic data-driven template decoding (mirror of Swift SpecEngine)."""
import numpy as np, omr_ref as O

P3CELLS=O.P3CELLS
def cells(spec):
    """Yield (kind, question/col, item, x, y) for every bubble in the spec."""
    out=[]
    for b in spec['blocks']:
        xs,ys,k,f=b['xs'],b['ys'],b['kind'],b['first']
        if k=='p1':
            for r,y in enumerate(ys):
                for c,x in enumerate(xs[:4]): out.append(('p1',f+r,c,x,y))
        elif k in ('sbd','code'):
            for c,x in enumerate(xs):
                for d,y in enumerate(ys[:10]): out.append((k,f+c,d,x,y))
        elif k=='p2':   # rows = a..d, cols = Dung,Sai ; several questions side by side: every 2 cols one question
            for q in range(len(xs)//2):
                for i,y in enumerate(ys[:4]):
                    for ds in range(2): out.append(('p2',f+q,i*2+ds,xs[q*2+ds],y))
        elif k=='p3':
            for idx,(row,col,sym) in enumerate(P3CELLS):
                out.append(('p3',f,idx,xs[col],ys[row]))
    return out

def caps(spec):
    c=cells(spec); g=lambda k:max([q for kk,q,*_ in c if kk==k],default=0)
    return dict(p1=g('p1'),p2=g('p2'),p3=g('p3'),sbd=g('sbd'),code=g('code'))

def lsq_homography(src,dst):
    M=[];b=[]
    for (x,y),(u,v) in zip(src,dst):
        M.append([x,y,1,0,0,0,-u*x,-u*y]); b.append(u)
        M.append([0,0,0,x,y,1,-v*x,-v*y]); b.append(v)
    M=np.array(M,float); b=np.array(b,float)
    h=np.linalg.solve(M.T@M, M.T@b); return np.append(h,1).reshape(3,3)

def corner_ids(spec):
    A=spec['aspect']; mk=spec['markers']
    return [int(np.argmin([np.hypot(m['x']-u,m['y']-v) for m in mk])) for u,v in [(0,0),(1,0),(1,A),(0,A)]]

def locate(cands, spec, minDim=0):
    """Find sheet->image homography from marker candidates."""
    n=len(cands)
    if n<4: return None
    A=spec['aspect']; mk=spec['markers']; ci=corner_ids(spec)
    side=np.mean([mk[i]['side'] for i in ci])
    P=np.array([c[:2] for c in cands]); S=np.array([c[2] for c in cands])
    MS=np.array([[m['x'],m['y']] for m in mk]); MSide=np.array([m['side'] for m in mk])
    sheetC=[(0,0),(1,0),(1,A),(0,A)]
    best=None
    for i in range(n):
        for j in range(n):
            if i==j: continue
            v=P[j]-P[i]; L=np.hypot(*v)
            if L<40 or L<0.25*minDim: continue
            exp=(side*L)**2
            if not (0.35*exp<S[i]<2.8*exp and 0.35*exp<S[j]<2.8*exp): continue
            down=np.array([-v[1],v[0]])*A
            opts=[]
            for p in (P[j]+down, P[i]+down):
                d=np.hypot(*(P-p).T)
                ok=[k for k in range(n) if d[k]<0.5*L and 0.3*exp<S[k]<3.2*exp and k not in (i,j)]
                ok.sort(key=lambda k:abs(np.log(S[k]/exp)))
                opts.append(ok[:4])
            for k0 in opts[0]:
              for k1 in opts[1]:
                if k0==k1: continue
                quad=[P[i],P[j],P[k0],P[k1]]
                H=O.homography(sheetC,quad)
                proj=np.array([O.apply(H,x,y) for x,y in MS])
                matched=[];err=0
                for mi,(px,py) in enumerate(proj):
                    d=np.hypot(P[:,0]-px,P[:,1]-py); k=int(np.argmin(d))
                    es=(MSide[mi]*L)**2
                    if d[k]<0.025*L and 0.3*es<S[k]<3.2*es: matched.append((mi,k)); err+=d[k]/L
                score=len(matched)/len(MS)
                Hi=np.linalg.inv(H); out=0
                for k in range(n):
                    if S[k]<0.5*exp: continue
                    u,w=O.apply(Hi,P[k][0],P[k][1])
                    if (u<-0.03 or u>1.03 or w<-0.03 or w>A+0.03) and (-0.5<u<1.5 and -0.5<w<A+0.5): out+=1
                key=(score-0.1*out,-err/max(len(matched),1))
                if best is None or key>best[0]: best=(key,matched,H,L)
    if best is None: return None
    (_,_),matched,H,L=best
    score=len(matched)/len(MS)
    if score<0.6 or len(matched)<4: return None
    mids=[m for m,_ in matched]
    if not all(c in mids for c in ci): return None
    disc=[i for i,m in enumerate(mk) if not any(np.hypot(o['x']-(1-m['x']),o['y']-(A-m['y']))<0.025 for o in mk)]
    if disc and 2*sum(d in mids for d in disc)<len(disc): return None
    Hs=lsq_homography([MS[m] for m,_ in matched],[P[k] for _,k in matched])
    return Hs, score

def decode(g, spec):
    cands=O.find_markers(g)
    r=locate(cands,spec,min(g.shape))
    if r is None: return None
    H,score=r
    R=spec['bubbleR']; hgt,wdt=g.shape
    rr=R*0.55; offs=[(dx,dy) for dx in np.linspace(-rr,rr,5) for dy in np.linspace(-rr,rr,5) if dx*dx+dy*dy<=rr*rr*1.05]
    def sample(X,Y):
        v=[]
        for dx,dy in offs:
            x,y=O.apply(H,X+dx,Y+dy); v.append(g[min(max(int(round(y)),0),hgt-1),min(max(int(round(x)),0),wdt-1)])
        return float(np.mean(v))
    A=spec['aspect']; mk=spec['markers']; ci=corner_ids(spec)
    dark=np.mean([sample(mk[i]['x'],mk[i]['y']) for i in ci])
    allc=cells(spec); vals=np.array([sample(x,y) for *_,x,y in allc])
    # per-block normalisation: blocks = consecutive runs from same spec block; recompute by grouping on (kind, first-of-block)
    f=np.zeros(len(allc)); idx=0
    for b in spec['blocks']:
        n=len(cells(dict(blocks=[b])))
        v=vals[idx:idx+n]; paper=np.percentile(v,75); f[idx:idx+n]=(paper-v)/max(paper-dark,20); idx+=n
    ans=np.array([k in ('p1','p2','p3') for k,*_ in allc])
    a=f[ans] if ans.any() else f
    c0,c1=np.quantile(a,0.3),a.max()
    for _ in range(10):
        T=(c0+c1)/2; lo=a[a<T]; hi=a[a>=T]
        if len(lo)==0 or len(hi)==0: break
        c0,c1=lo.mean(),hi.mean()
    T=0.5 if c1-c0<0.15 else min(max((c0+c1)/2,0.18),0.5)
    cp=caps(spec)
    out=dict(sbd='',made='',p1=['']*cp['p1'],p2=['____']*cp['p2'],p3=['']*cp['p3'],T=T,score=score)
    dig={'sbd':{},'code':{}}; p1={}; p2={}; p3={}
    for (k,q,item,_,_),fv in zip(allc,f):
        on=fv>T
        if k in dig: dig[k].setdefault(q,[]).append((item,on))
        elif k=='p1': p1.setdefault(q,[]).append((item,on))
        elif k=='p2': p2.setdefault(q,{})[item]=on
        elif k=='p3': p3.setdefault(q,[]).append((item,on))
    for k,key in (('sbd','sbd'),('code','made')):
        s=''
        for q in sorted(dig[k]):
            on=[d for d,o in dig[k][q] if o]
            s+= str(on[0]) if len(on)==1 else ('' if not on else '?')
        out[key]=s
    for q,lst in p1.items():
        on=[i for i,o in lst if o]; out['p1'][q-1]='' if not on else ('ABCD'[on[0]] if len(on)==1 else '*')
    for q,d in p2.items():
        s=''
        for i in range(4):
            dv,sv=d.get(2*i,False),d.get(2*i+1,False); s+='*' if dv and sv else 'D' if dv else 'S' if sv else '_'
        out['p2'][q-1]=s
    for q,lst in p3.items():
        cols=[[] for _ in range(4)]
        for idx,o in lst:
            if o: row,col,sym=P3CELLS[idx]; cols[col].append(sym)
        out['p3'][q-1]=''.join('*' if len(x)>1 else x[0] for x in cols if x)
    if sum(x=='*' for x in out['p1'])+sum('*' in x for x in out['p2'])>max(12,cp['p1']//4): return None
    return out

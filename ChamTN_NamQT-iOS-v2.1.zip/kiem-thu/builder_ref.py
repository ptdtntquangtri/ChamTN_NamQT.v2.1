"""Template builder (mirror of Swift TemplateBuilder): blank sheet image -> markers + bubble blocks."""
import numpy as np, omr_ref as O

def label(mask):
    """4-connected components -> list of (pts array Nx2 (x,y))"""
    return O.components(mask)

def detect(g):
    h,w=g.shape
    rad=max(8,min(h,w)//40)
    mean=O.integral_mean(g,rad)
    dark=g<mean*0.85
    # --- markers: dark, solid, square
    markers=[]
    comps=label(dark)
    for pts in comps:
        n=len(pts)
        x0,y0=pts.min(0); x1,y1=pts.max(0); bw=x1-x0+1; bh=y1-y0+1
        if bw<0.006*w or bw>0.06*w or bh<0.006*w or bh>0.06*w: continue
        if max(bw,bh)>1.3*min(bw,bh): continue
        if n<0.85*bw*bh: continue
        markers.append(((x0+x1)/2,(y0+y1)/2,(bw+bh)/2))
    # --- bubble interiors: light components enclosed by dark ring
    holes=[]
    for pts in label(~dark):
        n=len(pts)
        x0,y0=pts.min(0); x1,y1=pts.max(0); bw=x1-x0+1; bh=y1-y0+1
        if x0==0 or y0==0 or x1==w-1 or y1==h-1: continue
        if bw<0.004*w or bw>0.04*w: continue
        if max(bw,bh)>1.35*min(bw,bh): continue
        fr=n/(bw*bh)
        if fr<0.45 or fr>0.86: continue
        cx,cy=pts.mean(0)
        if abs(cx-(x0+x1)/2)>0.15*bw or abs(cy-(y0+y1)/2)>0.15*bh: continue
        holes.append(((x0+x1)/2,(y0+y1)/2,(bw+bh)/2))
    holes=np.array(holes) if holes else np.zeros((0,3))
    if len(holes):
        # dominant size: weighted mode in log space
        s=np.log(holes[:,2]); best=None
        for c in s:
            k=np.sum(np.abs(s-c)<0.2)
            if best is None or k>best[0]: best=(k,c)
        med=np.exp(np.median(s[np.abs(s-best[1])<0.2]))
        holes=holes[(holes[:,2]>med*0.6)&(holes[:,2]<med*1.45)]
    return np.array(markers) if markers else np.zeros((0,3)), holes

def corners(markers):
    if len(markers)<4: return None
    big=markers[markers[:,2]>=0.6*np.median(sorted(markers[:,2])[-4:])]
    x,y=big[:,0],big[:,1]
    TL=big[np.argmin(x+y)]; BR=big[np.argmax(x+y)]; TR=big[np.argmax(x-y)]; BL=big[np.argmin(x-y)]
    return TL,TR,BR,BL

def cluster1d(vals,tol):
    order=np.argsort(vals); groups=[]; cur=[order[0]]
    for a,b in zip(order[:-1],order[1:]):
        if vals[b]-vals[a]<=tol: cur.append(b)
        else: groups.append(cur); cur=[b]
    groups.append(cur); return groups

def blocks(holes):
    n=len(holes)
    if n==0: return []
    P=holes[:,:2]; r=np.median(holes[:,2])/2
    # nearest neighbour spacings per axis
    dx=[];dy=[]
    for i in range(n):
        d=P-P[i]
        hm=(np.abs(d[:,1])<0.6*r)&(d[:,0]>0.5*r)
        vm=(np.abs(d[:,0])<0.6*r)&(d[:,1]>0.5*r)
        if hm.any(): dx.append(d[hm,0].min())
        if vm.any(): dy.append(d[vm,1].min())
    mx=np.median(dx); my=np.median(dy)
    parent=list(range(n))
    def find(a):
        while parent[a]!=a: parent[a]=parent[parent[a]]; a=parent[a]
        return a
    for i in range(n):
        d=P-P[i]
        hm=(np.abs(d[:,1])<0.6*r)&(d[:,0]>0)&(d[:,0]<1.6*mx)
        vm=(np.abs(d[:,0])<0.6*r)&(d[:,1]>0)&(d[:,1]<1.6*my)
        for j in np.where(hm|vm)[0]: parent[find(i)]=find(j)
    groups={}
    for i in range(n): groups.setdefault(find(i),[]).append(i)
    out=[]
    for idx in groups.values():
        if len(idx)<3: continue
        Q=P[idx]
        cols=cluster1d(Q[:,0],0.5*r); rows=cluster1d(Q[:,1],0.5*r)
        cx=sorted(np.mean(Q[g,0]) for g in cols); cy=sorted(np.mean(Q[g,1]) for g in rows)
        occ=np.zeros((len(cy),len(cx)),bool)
        for q in Q:
            occ[int(np.argmin(np.abs(np.array(cy)-q[1]))),int(np.argmin(np.abs(np.array(cx)-q[0])))]=True
        out.append(dict(xs=cx,ys=cy,occ=occ,n=len(idx)))
    out.sort(key=lambda b:(b['ys'][0],b['xs'][0]))
    return out,r,mx,my

def build(g, name):
    """Returns a spec dict in sheet coordinates (TL corner marker = (0,0), TR = (1,0))."""
    m,h=detect(g)
    c=corners(m)
    if c is None: raise ValueError('no corners')
    TL,TR,BR,BL=c
    W=np.linalg.norm(TR[:2]-TL[:2]); A=np.linalg.norm(BL[:2]-TL[:2])/W
    H=O.homography([TL[:2],TR[:2],BR[:2],BL[:2]],[(0,0),(1,0),(1,A),(0,A)])
    def S(x,y): return O.apply(H,x,y)
    bl,r,mx,my=blocks(h)
    markers=[dict(x=S(x,y)[0],y=S(x,y)[1],side=s/W) for x,y,s in m]
    corner_idx=[int(np.argmin([np.hypot(mm['x']-u,mm['y']-v) for mm in markers])) for u,v in [(0,0),(1,0),(1,A),(0,A)]]
    B=[]
    for b in bl:
        x0,y0=S(b['xs'][0],b['ys'][0]); x1,_=S(b['xs'][-1],b['ys'][0]); _,y1=S(b['xs'][0],b['ys'][-1])
        nc,nr=len(b['xs']),len(b['ys'])
        B.append(dict(rows=nr,cols=nc,x0=x0,y0=y0,dx=(x1-x0)/max(nc-1,1),dy=(y1-y0)/max(nr-1,1),
                      occ=b['occ'].astype(int).tolist(),kind='skip'))
    return dict(name=name,aspect=A,bubbleR=r/W,markers=markers,corners=corner_idx,blocks=B)

def autolabel(spec):
    """Guess block meaning like the app does; returns spec with kinds."""
    B=spec['blocks']
    digit=[b for b in B if b['rows']==10 and b['cols']>=2 and b['cols']<=10 and all(all(r) for r in b['occ'])]
    # digit blocks: top region and not 4 columns answer style? answer blocks have 4 cols and rows<=?; ambiguity when cols==4 & rows==10
    # prefer: the two leftmost-topmost 10-row blocks whose col spacing ~ row spacing (square grid)
    cand=[b for b in digit if abs(b['dx']-b['dy'])<0.35*max(b['dx'],b['dy'])]
    cand.sort(key=lambda b:(b['y0'],b['x0']))
    if cand:
        top=[b for b in cand if abs(b['y0']-cand[0]['y0'])<0.03]
        top.sort(key=lambda b:b['x0'])
        if len(top)>=2: top[0]['kind']='sbd'; top[1]['kind']='code'
        elif len(top)==1: top[0]['kind']='sbd'
    for b in B:
        if b['kind']!='skip': continue
        if b['cols']==4 and b['rows']==12: b['kind']='p3'
        elif b['cols']==2 and b['rows']==4: b['kind']='p2'
        elif b['cols']==4: b['kind']='p1'
    # number p1 blocks: band by y0 then x
    p1=[b for b in B if b['kind']=='p1']
    p1.sort(key=lambda b:(round(b['y0']/0.04),b['x0']))
    # robust banding
    bands=[]
    for b in sorted(p1,key=lambda b:b['y0']):
        if bands and abs(b['y0']-bands[-1][0]['y0'])<0.5*b['dy']*3: bands[-1].append(b)
        else: bands.append([b])
    q=1
    for band in bands:
        for b in sorted(band,key=lambda b:b['x0']):
            b['first']=q; q+=b['rows']
    q=1
    for b in sorted([b for b in B if b['kind']=='p2'],key=lambda b:(round(b['y0'],2),b['x0'])): b['first']=q; q+=1
    q=1
    for b in sorted([b for b in B if b['kind']=='p3'],key=lambda b:(round(b['y0'],2),b['x0'])): b['first']=q; q+=1
    return spec

def kmeans1d(vals, k, lo, hi):
    """Known-k 1D clustering seeded uniformly on [lo,hi]; empty clusters filled by linear fit."""
    c=np.linspace(lo,hi,k)
    vals=np.asarray(vals,float)
    for _ in range(15):
        if len(vals)==0: break
        a=np.argmin(np.abs(vals[:,None]-c[None,:]),axis=1)
        new=c.copy()
        for i in range(k):
            if (a==i).any(): new[i]=vals[a==i].mean()
        if np.allclose(new,c): break
        c=new
    a=np.argmin(np.abs(vals[:,None]-c[None,:]),axis=1) if len(vals) else np.array([],int)
    have=np.array([(a==i).any() for i in range(k)])
    if have.sum()>=2 and not have.all():
        idx=np.arange(k); p=np.polyfit(idx[have],c[have],1); c[~have]=np.polyval(p,idx[~have])
    elif have.sum()<2:
        c=np.linspace(lo,hi,k)
    return np.sort(c)

def fit_grid(holes, rect, rows, cols):
    """rect in pixels (x0,y0,x1,y1): edges pass roughly through first/last bubble centres."""
    x0,y0,x1,y1=rect
    pad=0.6*max((x1-x0)/max(cols-1,1),(y1-y0)/max(rows-1,1))
    m=(holes[:,0]>x0-pad)&(holes[:,0]<x1+pad)&(holes[:,1]>y0-pad)&(holes[:,1]<y1+pad)
    H=holes[m]
    if len(H):
        med=np.median(H[:,2]); H=H[(H[:,2]>0.75*med)&(H[:,2]<1.33*med)]
    return robust(kmeans1d(H[:,0],cols,x0,x1),x0,x1), robust(kmeans1d(H[:,1],rows,y0,y1),y0,y1)

def robust(c,lo,hi):
    """Replace cluster centres that stray from the best line (index -> centre) by the line value."""
    k=len(c)
    if k<3: return c
    idx=np.arange(k); step=(hi-lo)/(k-1) if k>1 else 1
    best=None
    for i in range(k):
        for j in range(i+1,k):
            s=(c[j]-c[i])/(j-i); b=c[i]-s*i
            inl=np.abs(c-(s*idx+b))<0.2*abs(step)
            if best is None or inl.sum()>best[0].sum(): best=(inl,)
    inl=best[0]
    p=np.polyfit(idx[inl],c[inl],1) if inl.sum()>=2 else np.polyfit(idx,c,1)
    out=c.copy()
    bad=np.abs(c-np.polyval(p,idx))>0.2*abs(step)
    out[bad]=np.polyval(p,idx[bad])
    return out
